# PALKA 1.1.3 — forest UI and chat interaction update

## Included in this source package
- Four locally bundled forest wallpaper backgrounds for private chats; the chat settings menu cycles through them and remembers the selected wallpaper per conversation.
- Typing status now expires automatically after inactivity; the client stops advertising typing when leaving the chat.
- Long-pressing a message opens the message action dialog directly; tapping a message keeps the compact reaction/action menu.
- Existing exact reply preview, local message time display, read receipt indicator, photo/video attachments, profile/avatar, username search, notes and block list are retained.
- No Calls tab and no push notifications (push notifications are intentionally deferred).

## Important
This is Android source for GitHub Actions, not an APK. The project has not been compiled in this environment because Gradle/Android SDK are not installed here. Build it in GitHub Actions before installing. The existing Supabase database must already have the v2/v3 schema updates from `supabase/schema.sql`; do not rerun the full schema blindly on a live database.
