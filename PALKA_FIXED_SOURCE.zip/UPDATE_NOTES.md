# PALKA update v2

Implemented in this source package:
- Separate display name and @username fields in profile editor.
- Forest launcher icon.
- Chat wallpaper presets.
- Image/video document picker and upload to Supabase Storage.
- Reply-to-message reference, own-message editing and deletion.
- Read receipt field and chat read-marking call.
- Typing indicator using `chat_typing` table.
- Block action and a basic blocked-users screen.
- Personal notes saved locally on the device.

Before building, run `supabase/update_v2.sql` once in Supabase SQL Editor. Keep your existing `secrets.properties` values when replacing source files; never upload service-role keys.

Voice/video calling is intentionally not included in this update.

Build has not been verified in this environment. Run GitHub Actions and inspect any Kotlin/Gradle errors before installing.
