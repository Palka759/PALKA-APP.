PALKA source package update

- Corrected launcher icon resource reference to @mipmap/palka_forest_icon.
- Added launcher icon PNG under app/src/main/res/mipmap-nodpi.
- Removed duplicated nested project copy to keep one unambiguous Gradle project at archive root.
- Did not include local secrets.properties; use secrets.properties.example and configure Supabase values securely in GitHub Actions.

Build status: not verified in this environment. Run the GitHub Actions workflow to confirm compilation.
