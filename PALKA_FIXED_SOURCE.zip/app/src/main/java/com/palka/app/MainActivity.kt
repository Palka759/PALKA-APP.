package com.palka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import coil.compose.AsyncImage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Night = Color(0xFF101710)
private val Panel = Color(0xFF1B281D)
private val Green = Color(0xFF9BE564)
private val Wood = Color(0xFFB9824B)
private val Cream = Color(0xFFF1E8D8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PalkaApp() } }
}

@Composable fun PalkaApp() {
    var signedIn by remember { mutableStateOf(Backend.userId != null) }
    var profile by remember { mutableStateOf<Profile?>(null) }
    var selected by remember { mutableStateOf<Profile?>(null) }
    var conversationId by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(signedIn) {
        if (signedIn) runCatching { profile = Backend.myProfile() }.onFailure { error = it.message ?: "Ошибка профиля" }
    }
    LaunchedEffect(signedIn) {
        while (signedIn) { runCatching { Backend.touchPresence() }; delay(30_000) }
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Green, onPrimary = Night, onBackground = Cream, onSurface = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            when {
                !signedIn -> AuthScreen(busy, error, onClear = { error = "" }, onAuth = { email, pass, register ->
                    scope.launch { busy = true; error = ""; runCatching { if (register) Backend.signUp(email, pass) else Backend.signIn(email, pass); signedIn = Backend.userId != null
                        if (register && !signedIn) error = "Проверь почту и подтверди регистрацию" }.onFailure { error = it.message ?: "Не удалось войти" }; busy = false }
                })
                profile == null -> ProfileSetup(error) { nick -> scope.launch { busy = true; runCatching { Backend.saveProfile(nick); profile = Backend.myProfile() }.onFailure { error = it.message ?: "Не удалось сохранить ник" }; busy = false } }
                screen == "chat" && selected != null && conversationId != null -> ChatScreen(selected!!, conversationId!!, onBack = { screen = "home" })
                else -> HomeScreen(profile!!, onOpen = { p -> scope.launch { busy = true; runCatching { conversationId = Backend.openConversation(p.id); selected = p; screen = "chat" }.onFailure { error = it.message ?: "Ошибка чата" }; busy = false } }, onSignOut = { scope.launch { Backend.signOut(); signedIn = false; profile = null } }, onSaveProfile = { nick, avatar -> scope.launch { busy = true; runCatching { Backend.saveProfile(nick, avatar); profile = Backend.myProfile() }.onFailure { error = it.message ?: "Не удалось сохранить профиль" }; busy = false } }, error = error)
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
        }
    }
}

@Composable private fun AuthScreen(busy: Boolean, error: String, onClear: () -> Unit, onAuth: (String, String, Boolean) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var register by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(28.dp))
        Text(if (register) "Создать аккаунт" else "С возвращением!", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("Только email и пароль. Номер не нужен.", color = Green, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        PalkaField(email, { email = it }, "Email", keyboard = KeyboardType.Email)
        Spacer(Modifier.height(12.dp)); PalkaField(password, { password = it }, "Пароль", secret = true)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp)); Button(onClick = { onClear(); onAuth(email.trim(), password, register) }, enabled = !busy && email.contains("@") && password.length >= 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (register) "Зарегистрироваться" else "Войти", color = Night, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { register = !register }) { Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Регистрация", color = Cream) }
    }
}

@Composable private fun ProfileSetup(error: String, save: (String) -> Unit) {
    var nick by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(24.dp)); Text("Придумай свой ник", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("По нему тебя смогут найти друзья", color = Green, modifier = Modifier.padding(vertical = 12.dp))
        PalkaField(nick, { nick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "Например: lesnoy_palka")
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86))
        Button(onClick = { save(nick.lowercase()) }, enabled = nick.length in 3..20, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Продолжить", color = Night) }
    }
}

@Composable private fun HomeScreen(me: Profile, onOpen: (Profile) -> Unit, onSignOut: () -> Unit, onSaveProfile: (String, String?) -> Unit, error: String) {
    var editProfile by remember { mutableStateOf(false) }
    var editNick by remember(me.username) { mutableStateOf(me.username) }
    var avatarUrl by remember(me.avatarUrl) { mutableStateOf(me.avatarUrl ?: "") }
    var query by remember { mutableStateOf("") }; var results by remember { mutableStateOf<List<Profile>>(emptyList()) }; var chats by remember { mutableStateOf<List<Profile>>(emptyList()) }; var searching by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(me.id) { runCatching { chats = Backend.chatPartners() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("PALKA", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Green); Text("Привет, @${me.username}", color = Cream) }
            Column(horizontalAlignment = Alignment.End) { TextButton(onClick = { editProfile = true }) { Text("Профиль", color = Green) }; TextButton(onClick = onSignOut) { Text("Выйти", color = Green) } }
        }
        Text("Найти палку-друга", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cream)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ник пользователя") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = fieldColors())
            IconButton(enabled = query.trim().length >= 3, onClick = { scope.launch { searching = true; runCatching { results = Backend.findUsers(query.trim()) }; searching = false } }) { Icon(Icons.Default.Search, null, tint = Green) }
        }
        if (searching) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86))
        if (results.isNotEmpty()) {
            Text("Результаты поиска", color = Green, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            LazyColumn(Modifier.heightIn(max = 220.dp)) { items(results, key = { it.id }) { person -> UserRow(person, onClick = { onOpen(person) }) } }
        }
        Text("Твои чаты", color = Green, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
        if (chats.isEmpty()) Text("Пока пусто — найди друга по нику", color = Color.Gray, fontSize = 13.sp)
        LazyColumn { items(chats, key = { it.id }) { person -> UserRow(person, onClick = { onOpen(person) }) } }
        Spacer(Modifier.weight(1f))
        Text("🪵 PALKA · меньше шума, больше общения", color = Wood, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 18.dp))
    }
    if (editProfile) AlertDialog(
        onDismissRequest = { editProfile = false },
        containerColor = Panel,
        title = { Text("Твой профиль", color = Cream) },
        text = { Column { PalkaField(editNick, { editNick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "Ник (3–20 символов)"); Spacer(Modifier.height(10.dp)); PalkaField(avatarUrl, { avatarUrl = it }, "Ссылка на аватар (необязательно)") } },
        confirmButton = { TextButton(onClick = { onSaveProfile(editNick.lowercase(), avatarUrl.takeIf { it.startsWith("https://") }); editProfile = false }) { Text("Сохранить", color = Green) } },
        dismissButton = { TextButton(onClick = { editProfile = false }) { Text("Отмена", color = Cream) } }
    )
}

@Composable private fun UserRow(person: Profile, onClick: () -> Unit) {
    val online = remember(person.lastSeen) { try { person.lastSeen?.let { java.time.Duration.between(java.time.Instant.parse(it), java.time.Instant.now()).seconds < 75 } ?: false } catch (_: Exception) { false } }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(person.username, person.avatarUrl); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("@${person.username}", fontWeight = FontWeight.Bold, color = Cream); if (online) Row(verticalAlignment = Alignment.CenterVertically) { Text("🪵", fontSize = 12.sp); Text("Палка тут", color = Green, fontSize = 12.sp) } else Text("Не в сети", color = Color.Gray, fontSize = 12.sp) } }
        Text("Написать  ›", color = Green, fontSize = 13.sp)
    }
}

@Composable private fun ChatScreen(friend: Profile, conversationId: String, onBack: () -> Unit) {
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }; var text by remember { mutableStateOf("") }; var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope(); val uid = Backend.userId
    LaunchedEffect(conversationId) {
        runCatching { messages = Backend.messages(conversationId) }
        loading = false
        Backend.watchMessages { messages = Backend.messages(conversationId) }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Green) }
            Avatar(friend.username, friend.avatarUrl); Spacer(Modifier.width(10.dp)); Column { Text("@${friend.username}", color = Cream, fontWeight = FontWeight.Bold); Text("Личный чат PALKA", color = Green, fontSize = 12.sp) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), reverseLayout = false, contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages, key = { it.id ?: it.hashCode().toString() }) { msg ->
                val mine = msg.senderId == uid
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Box(Modifier.padding(vertical = 4.dp).widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp)).background(if (mine) Color(0xFF345333) else Panel).padding(12.dp)) { Text(msg.body, color = Cream) }
                    if (msg.id != null) Row { listOf("❤️", "😂", "🪵", "👍").forEach { emoji -> Text(emoji, Modifier.clickable { scope.launch { runCatching { Backend.react(msg.id, emoji) } } }.padding(horizontal = 5.dp), fontSize = 15.sp) } }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Panel).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Сообщение...") }, shape = RoundedCornerShape(18.dp), colors = fieldColors(), maxLines = 4)
            IconButton(onClick = { val body = text.trim(); if (body.isNotEmpty()) scope.launch { runCatching { Backend.sendMessage(conversationId, body); text = "" } } }, enabled = text.isNotBlank()) { Icon(Icons.Default.Send, null, tint = Green) }
        }
    }
}

@Composable private fun Logo() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("🪵", fontSize = 54.sp); Text("PALKA", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Green, letterSpacing = 3.sp)
        Text("деревянный чат для своих", color = Wood, fontSize = 13.sp)
    }
}
@Composable private fun Avatar(nick: String, url: String? = null) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF59412C)), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = "Аватар $nick", modifier = Modifier.fillMaxSize())
        else Text(nick.take(1).uppercase(), color = Cream, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}
@Composable private fun PalkaField(value: String, onChange: (String) -> Unit, hint: String, keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false) {
    OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(keyboardType = keyboard), visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, colors = fieldColors())
}
@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF52624F), focusedTextColor = Cream, unfocusedTextColor = Cream, focusedPlaceholderColor = Color.Gray, unfocusedPlaceholderColor = Color.Gray, cursorColor = Green)
