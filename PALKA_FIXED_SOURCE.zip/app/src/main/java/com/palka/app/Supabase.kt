package com.palka.app

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.result.decodeList
import io.github.jan.supabase.postgrest.result.decodeSingle
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.channel
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

@Serializable data class Profile(
    val id: String,
    val username: String,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("last_seen") val lastSeen: String? = null
)
@Serializable data class ChatMessage(
    val id: String? = null,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String,
    @SerialName("created_at") val createdAt: String? = null
)
@Serializable data class Conversation(
    val id: String,
    @SerialName("member_one") val memberOne: String,
    @SerialName("member_two") val memberTwo: String
)
@Serializable data class Reaction(
    val id: String? = null,
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    val emoji: String
)

object Backend {
    private val configured get() = BuildConfig.SUPABASE_URL.startsWith("https://") && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()
    val client = if (configured) createSupabaseClient(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY) {
        install(Auth); install(Postgrest); install(Realtime)
    } else null
    val userId get() = client?.auth?.currentUserOrNull()?.id

    suspend fun signUp(email: String, password: String) {
        requireReady(); client!!.auth.signUpWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signIn(email: String, password: String) {
        requireReady(); client!!.auth.signInWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signOut() { client?.auth?.signOut() }
    private fun requireReady() { check(client != null) { "Сначала добавь SUPABASE_URL и SUPABASE_ANON_KEY в secrets.properties" } }

    suspend fun saveProfile(username: String, avatarUrl: String? = null) {
        val uid = userId ?: error("Сначала войди в аккаунт")
        client!!.from("profiles").upsert(buildJsonObject { put("id", uid); put("username", username); put("avatar_url", avatarUrl) })
    }
    suspend fun myProfile(): Profile? {
        val uid = userId ?: return null
        return client!!.from("profiles").select { filter { eq("id", uid) } }.decodeList<Profile>().firstOrNull()
    }
    suspend fun findUsers(query: String): List<Profile> {
        if (query.trim().length < 3) return emptyList()
        return client!!.from("profiles").select {
            filter { ilike("username", "%${query.trim().replace("%", "")}%"); neq("id", userId ?: "") }
            limit(30)
        }.decodeList()
    }
    suspend fun conversations(): List<Conversation> {
        val uid = userId ?: return emptyList()
        return client!!.from("conversations").select {
            filter { or { eq("member_one", uid); eq("member_two", uid) } }
        }.decodeList()
    }
    suspend fun chatPartners(): List<Profile> {
        val uid = userId ?: return emptyList()
        return conversations().mapNotNull { conversation ->
            val peerId = if (conversation.memberOne == uid) conversation.memberTwo else conversation.memberOne
            client!!.from("profiles").select { filter { eq("id", peerId) } }.decodeList<Profile>().firstOrNull()
        }
    }
    suspend fun openConversation(otherId: String): String {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("conversations").select {
            filter { or {
                and { eq("member_one", uid); eq("member_two", otherId) }
                and { eq("member_one", otherId); eq("member_two", uid) }
            } }
        }.decodeList<Conversation>().firstOrNull()
        if (existing != null) return existing.id
        val created = client!!.from("conversations").insert(buildJsonObject {
            put("member_one", uid); put("member_two", otherId)
        }) { select() }.decodeSingle<Conversation>()
        return created.id
    }
    suspend fun messages(conversationId: String): List<ChatMessage> = client!!.from("messages").select {
        filter { eq("conversation_id", conversationId) }
        order("created_at")
        limit(200)
    }.decodeList()
    suspend fun sendMessage(conversationId: String, body: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("messages").insert(buildJsonObject {
            put("conversation_id", conversationId); put("sender_id", uid); put("body", body)
        })
    }
    suspend fun react(messageId: String, emoji: String) {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("message_reactions").select {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }.decodeList<Reaction>().firstOrNull()
        val values = buildJsonObject { put("emoji", emoji) }
        if (existing == null) client!!.from("message_reactions").insert(buildJsonObject {
            put("message_id", messageId); put("user_id", uid); put("emoji", emoji)
        }) else client!!.from("message_reactions").update(values) {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }
    }
    suspend fun watchMessages(onChange: suspend () -> Unit) {
        val channel = client!!.channel("palka-messages-${userId}")
        val changes = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") { table = "messages" }
        val collector = CoroutineScope(Dispatchers.Main.immediate).launch { changes.collect { onChange() } }
        try { channel.subscribe(blockUntilSubscribed = true); awaitCancellation() }
        finally { collector.cancel() }
    }
    suspend fun touchPresence() {
        val uid = userId ?: return
        client!!.from("profiles").update(buildJsonObject { put("last_seen", java.time.Instant.now().toString()) }) {
            filter { eq("id", uid) }
        }
    }
}
