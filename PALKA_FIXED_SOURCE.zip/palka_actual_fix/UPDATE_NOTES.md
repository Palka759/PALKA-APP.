# PALKA update — work in progress

Changes made in this source package:
- Added local display of message send time (HH:mm).
- Added one check for sent messages and two checks when `read_at` is populated.
- Reply bubbles now show the referenced message text when it is available in the loaded chat.
- Added tap menu with reactions, reply, copy, forward placeholder, pin placeholder, edit and delete.
- Added long-press selection strip with reply and actions.
- Expanded built-in dark forest/wood wallpaper color presets.
- Set the launcher icon to the supplied forest P image.

Already present in the source before this pass:
- Chat image/video upload and rendering.
- Polling/realtime refresh and typing indicator.
- Read-marking API call and `read_at` model field.

Not completed/verified:
- Push notifications are not configured. Real notifications while the app is in background require Firebase Cloud Messaging setup and server-side push delivery; this source does not contain that setup.
- Forwarding and pinning are placeholders, not functional backend features.
- Android/Gradle build has not been verified in this environment.

Do not include `secrets.properties` in shared source archives. Configure the Supabase URL and publishable/anon key locally before building. Never use a service-role key in the Android app.
