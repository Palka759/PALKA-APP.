PALKA 1.2.0 — forest UI refresh

- Refined home header with the PALKA forest mark.
- Reworked Settings into the reference-style sections: Theme, Chat wallpapers, Language, Account, Notifications, and Blacklist.
- Added selectable theme/language presentation and notification toggle UI.
- Preserved existing authentication, chats, profile/avatar, notes, media, reactions, pinning, editing, reply, typing, and message actions.
- Kept one/two read checks based on messages.read_at.

Build with the existing GitHub Actions workflow and configured SUPABASE_URL / SUPABASE_ANON_KEY secrets.
