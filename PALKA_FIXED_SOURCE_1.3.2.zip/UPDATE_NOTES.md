PALKA 1.3.1 — functional themes and language selection

- Implemented three active app color themes: Forest, Dark, and Light. Theme selection is applied immediately across the app's shared color palette and saved per account.
- Implemented Russian, Ukrainian, and English translations for the main navigation, settings, theme/language choices, and common home-screen labels. Language choice is saved per account and applies immediately in those areas.
- Light and Dark themes use solid backgrounds; Forest keeps the forest wallpaper.
- Existing chat wallpapers and other features are retained.

Limitations:
- Localization is not yet complete in every dialog, authentication screen, and chat message action. Those remaining strings need a later pass.
- Push notifications are not added.
- Build and runtime verification are still required in GitHub Actions and on the phone.
