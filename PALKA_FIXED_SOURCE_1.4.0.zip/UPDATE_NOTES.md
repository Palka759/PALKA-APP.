# PALKA 1.4.0

- Faster chat reopening: conversation messages are cached in memory and shown immediately while fresh data loads.
- Reduced fallback polling from every 2.5 seconds to every 10 seconds; Realtime remains the primary update path.
- Reaction lists are refreshed only when message/read state changes, reducing repeated per-message requests.
- Private notes now load from and save to the per-user `private_notes` table, retaining local text as an offline fallback.
- Added a safe SQL migration for read receipts and private-note grants. No `anon` access to private messages or reactions is granted.

Run `supabase/update_v4.sql` in Supabase SQL Editor once before using the updated notes/read-receipt backend. Build with the existing GitHub Actions workflow.
