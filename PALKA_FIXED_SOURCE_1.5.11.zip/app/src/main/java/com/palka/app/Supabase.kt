package com.palka.app

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.channel
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.put
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlin.time.Duration.Companion.days

@Serializable data class Profile(
    val id: String,
    val username: String,
    @SerialName("display_name") val displayName: String = "",
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("last_seen") val lastSeen: String? = null
)
@Serializable data class ChatMessage(
    val id: String? = null,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("reply_to") val replyTo: String? = null,
    @SerialName("media_url") val mediaUrl: String? = null,
    @SerialName("media_type") val mediaType: String? = null,
    @SerialName("edited_at") val editedAt: String? = null,
    @SerialName("read_at") val readAt: String? = null
)
@Serializable data class Conversation(
    val id: String,
    @SerialName("member_one") val memberOne: String,
    @SerialName("member_two") val memberTwo: String
)
@Serializable data class TypingRow(@SerialName("updated_at") val updatedAt: String)

@Serializable data class BlockRow(@SerialName("blocked_id") val blockedId: String)
@Serializable data class PinnedRow(@SerialName("message_id") val messageId: String)
@Serializable data class PrivateNote(val id: String, @SerialName("user_id") val userId: String, val body: String = "")

@Serializable data class Reaction(
    val id: String? = null,
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    val emoji: String
)

object Backend {
    private val messageCache = java.util.concurrent.ConcurrentHashMap<String, List<ChatMessage>>()
    fun cachedMessages(conversationId: String): List<ChatMessage> = messageCache[conversationId].orEmpty()
    private val configured get() = BuildConfig.SUPABASE_URL.startsWith("https://") && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()
    val client = if (configured) createSupabaseClient(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY) {
        install(Auth) {
            // Keep the local session and refresh expired access tokens automatically.
            autoLoadFromStorage = true
            autoSaveToStorage = true
            alwaysAutoRefresh = true
        }
        install(Postgrest)
        install(Realtime)
        install(Storage)
    } else null

    /** Retry idempotent reads after short DNS/network interruptions. Never retry writes here. */
    private suspend fun <T> retryRead(block: suspend () -> T): T {
        var last: Throwable? = null
        val waits = longArrayOf(350, 800, 1600)
        for (attempt in 0..waits.size) {
            try { return block() }
            catch (t: Throwable) {
                last = t
                if (attempt < waits.size) kotlinx.coroutines.delay(waits[attempt])
            }
        }
        throw (last ?: IllegalStateException("Не удалось подключиться к серверу"))
    }
    val userId get() = client?.auth?.currentUserOrNull()?.id

    suspend fun awaitAuthInitialization() { client?.auth?.awaitInitialization() }

    suspend fun signUp(email: String, password: String) {
        requireReady(); client!!.auth.signUpWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signIn(email: String, password: String) {
        requireReady(); client!!.auth.signInWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signOut() { client?.auth?.signOut() }
    private fun requireReady() { check(client != null) { "Сначала добавь SUPABASE_URL и SUPABASE_ANON_KEY в secrets.properties" } }

    suspend fun uploadAvatar(bytes: ByteArray, fileName: String): String {
        val uid = userId ?: error("Сначала войди в аккаунт")
        val path = "$uid/avatar_${System.currentTimeMillis()}_${fileName.substringAfterLast('.', "jpg")}"
        client!!.storage.from("avatars").upload(path, bytes) { upsert = true }
        return client!!.storage.from("avatars").publicUrl(path)
    }

    suspend fun saveProfile(username: String, avatarUrl: String? = null, displayName: String = "") {
        val uid = userId ?: error("Сначала войди в аккаунт")
        client!!.from("profiles").upsert(buildJsonObject { put("id", uid); put("username", username); put("avatar_url", avatarUrl); put("display_name", displayName) })
    }
    suspend fun myProfile(): Profile? {
        val uid = userId ?: return null
        return retryRead { client!!.from("profiles").select { filter { eq("id", uid) } }.decodeList<Profile>().firstOrNull() }
    }
    suspend fun findUsers(query: String): List<Profile> {
        if (query.trim().length < 3) return emptyList()
        return client!!.from("profiles").select {
            filter { ilike("username", query.trim().removePrefix("@").lowercase()); neq("id", userId ?: "") }
            limit(30)
        }.decodeList()
    }
    suspend fun conversations(): List<Conversation> {
        val uid = userId ?: return emptyList()
        return retryRead { client!!.from("conversations").select {
            filter { or { eq("member_one", uid); eq("member_two", uid) } }
        }.decodeList<Conversation>() }
    }
    suspend fun chatPartners(): List<Profile> {
        val uid = userId ?: return emptyList()
        return conversations().mapNotNull { conversation ->
            val peerId = if (conversation.memberOne == uid) conversation.memberTwo else conversation.memberOne
            client!!.from("profiles").select { filter { eq("id", peerId) } }.decodeList<Profile>().firstOrNull()
        }
    }
    suspend fun openConversation(otherId: String): String {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("conversations").select {
            filter { or {
                and { eq("member_one", uid); eq("member_two", otherId) }
                and { eq("member_one", otherId); eq("member_two", uid) }
            } }
        }.decodeList<Conversation>().firstOrNull()
        if (existing != null) return existing.id
        val created = client!!.from("conversations").insert(buildJsonObject {
            put("member_one", uid); put("member_two", otherId)
        }) { select() }.decodeSingle<Conversation>()
        return created.id
    }
    fun appendCachedMessage(conversationId: String, message: ChatMessage) {
        val current = messageCache[conversationId].orEmpty()
        if (message.id == null || current.none { it.id == message.id }) messageCache[conversationId] = (current + message).takeLast(200)
    }
    suspend fun messages(conversationId: String): List<ChatMessage> = retryRead {
        client!!.from("messages").select {
            filter { eq("conversation_id", conversationId) }
            order("created_at", Order.ASCENDING)
            limit(200)
        }.decodeList<ChatMessage>().also { messageCache[conversationId] = it }
    }
    suspend fun privateNote(): String {
        val uid = userId ?: return ""
        return retryRead { client!!.from("private_notes").select { filter { eq("user_id", uid) }; limit(1) }.decodeList<PrivateNote>().firstOrNull()?.body.orEmpty() }
    }
    suspend fun savePrivateNote(body: String) {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("private_notes").select { filter { eq("user_id", uid) }; limit(1) }.decodeList<PrivateNote>().firstOrNull()
        val values = buildJsonObject { put("title", "Мои заметки"); put("body", body); put("updated_at", java.time.Instant.now().toString()) }
        if (existing == null) client!!.from("private_notes").insert(buildJsonObject { put("user_id", uid); put("title", "Мои заметки"); put("body", body) })
        else client!!.from("private_notes").update(values) { filter { eq("id", existing.id); eq("user_id", uid) } }
    }
    suspend fun sendMessage(conversationId: String, body: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("messages").insert(buildJsonObject {
            put("conversation_id", conversationId); put("sender_id", uid); put("body", body)
        })
    }
    suspend fun sendRichMessage(conversationId: String, body: String, replyTo: String? = null, mediaUrl: String? = null, mediaType: String? = null): ChatMessage {
        val uid = userId ?: error("Не выполнен вход")
        val sent = client!!.from("messages").insert(buildJsonObject {
            put("conversation_id", conversationId); put("sender_id", uid); put("body", body)
            replyTo?.let { put("reply_to", it) }; mediaUrl?.let { put("media_url", it) }; mediaType?.let { put("media_type", it) }
        }) { select() }.decodeSingle<ChatMessage>()
        appendCachedMessage(conversationId, sent)
        return sent
    }
    suspend fun editMessage(messageId: String, body: String) {
        client!!.from("messages").update(buildJsonObject { put("body", body); put("edited_at", java.time.Instant.now().toString()) }) { filter { eq("id", messageId); eq("sender_id", userId ?: "") } }
    }
    suspend fun deleteMessage(messageId: String) {
        client!!.from("messages").delete { filter { eq("id", messageId); eq("sender_id", userId ?: "") } }
    }
    suspend fun pinMessage(conversationId: String, messageId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("pinned_messages").upsert(buildJsonObject { put("conversation_id", conversationId); put("message_id", messageId); put("pinned_by", uid) })
    }
    suspend fun pinnedMessageId(conversationId: String): String? = client!!.from("pinned_messages").select {
        filter { eq("conversation_id", conversationId) }
        limit(1)
    }.decodeList<PinnedRow>().firstOrNull()?.messageId
    suspend fun unpinMessage(conversationId: String, messageId: String) {
        client!!.from("pinned_messages").delete {
            filter { eq("conversation_id", conversationId); eq("message_id", messageId) }
        }
    }
    suspend fun markRead(conversationId: String) {
        val uid = userId ?: return
        // Update only unread incoming rows. This avoids a SELECT + redundant
        // UPDATE of every old message and prevents unnecessary Realtime events.
        client!!.from("messages").update(buildJsonObject {
            put("read_at", java.time.Instant.now().toString())
        }) {
            filter {
                eq("conversation_id", conversationId)
                neq("sender_id", uid)
                exact("read_at", null)
            }
        }
    }
    suspend fun uploadChatMedia(bytes: ByteArray, fileName: String): String {
        val uid = userId ?: error("Не выполнен вход")
        val extension = fileName.substringAfterLast('.', "jpg").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "jpg" }
        val path = "$uid/${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}.$extension"
        client!!.storage.from("chat-media").upload(path, bytes) { upsert = false }
        return client!!.storage.from("chat-media").createSignedUrl(path, 7.days)
    }
    suspend fun blockUser(otherId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("user_blocks").upsert(buildJsonObject { put("blocker_id", uid); put("blocked_id", otherId) })
    }
    suspend fun blockedUsers(): List<String> {
        val uid = userId ?: return emptyList()
        return client!!.from("user_blocks").select { filter { eq("blocker_id", uid) } }.decodeList<BlockRow>().map { it.blockedId }
    }
    suspend fun unblockUser(otherId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("user_blocks").delete { filter { eq("blocker_id", uid); eq("blocked_id", otherId) } }
    }
    suspend fun blockedProfiles(): List<Profile> = blockedUsers().mapNotNull { id ->
        client!!.from("profiles").select { filter { eq("id", id) } }.decodeList<Profile>().firstOrNull()
    }
    suspend fun isBlockedByMe(otherId: String): Boolean = blockedUsers().contains(otherId)

    suspend fun setTyping(conversationId: String, typing: Boolean) {
        val uid = userId ?: return
        if (typing) client!!.from("chat_typing").upsert(buildJsonObject { put("conversation_id", conversationId); put("user_id", uid); put("updated_at", java.time.Instant.now().toString()) })
        else client!!.from("chat_typing").delete { filter { eq("conversation_id", conversationId); eq("user_id", uid) } }
    }
    suspend fun peerTyping(conversationId: String): Boolean {
        val uid = userId ?: return false
        val rows = client!!.from("chat_typing").select { filter { eq("conversation_id", conversationId); neq("user_id", uid) } }.decodeList<TypingRow>()
        return rows.any { runCatching { java.time.Duration.between(java.time.Instant.parse(it.updatedAt), java.time.Instant.now()).seconds < 5 }.getOrDefault(false) }
    }

    suspend fun messageReactions(messageId: String): List<Reaction> = client!!.from("message_reactions").select {
        filter { eq("message_id", messageId) }
    }.decodeList<Reaction>()

    suspend fun react(messageId: String, emoji: String) {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("message_reactions").select {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }.decodeList<Reaction>().firstOrNull()
        val values = buildJsonObject { put("emoji", emoji) }
        if (existing == null) client!!.from("message_reactions").insert(buildJsonObject {
            put("message_id", messageId); put("user_id", uid); put("emoji", emoji)
        }) else client!!.from("message_reactions").update(values) {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }
    }
    suspend fun watchMessages(conversationId: String, onChange: suspend (ChatMessage, Boolean) -> Unit) {
        // Consume the actual Realtime row instead of issuing another REST SELECT
        // for every event. Boolean is true for INSERT and false for UPDATE.
        val channel = client!!.channel("palka-messages-$conversationId-${userId}")
        val inserts = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
            table = "messages"
        }
        val updates = channel.postgresChangeFlow<PostgresAction.Update>(schema = "public") {
            table = "messages"
        }
        val scope = CoroutineScope(Dispatchers.Main.immediate)
        val insertCollector = scope.launch {
            inserts.collect { action ->
                val row = runCatching { Json.decodeFromJsonElement<ChatMessage>(action.record) }.getOrNull()
                if (row?.conversationId == conversationId) onChange(row, true)
            }
        }
        val updateCollector = scope.launch {
            updates.collect { action ->
                val row = runCatching { Json.decodeFromJsonElement<ChatMessage>(action.record) }.getOrNull()
                if (row?.conversationId == conversationId) onChange(row, false)
            }
        }
        try {
            channel.subscribe(blockUntilSubscribed = true)
            awaitCancellation()
        } finally {
            insertCollector.cancel()
            updateCollector.cancel()
        }
    }
    suspend fun touchPresence() {
        val uid = userId ?: return
        client!!.from("profiles").update(buildJsonObject { put("last_seen", java.time.Instant.now().toString()) }) {
            filter { eq("id", uid) }
        }
    }
}
