# PALKA 1.5.8

Fix Kotlin compilation: remove invalid kotlinx.serialization.json.content import. The JsonPrimitive content property remains used.


## 1.5.9 — continuous chat updates
- Keep the Realtime listener running and retry its subscription with exponential backoff when it exits.
- Use a 15-second safety refresh only as fallback; Realtime remains the primary delivery path.
- Keep optimistic local messages visible while their server insert is still pending.
- Render fetched messages before starting read-receipt writes; mark only when unread incoming messages exist.
- Move typing and pinned-message checks out of every message refresh; typing is checked separately.


## 1.5.10 — faster read acknowledgements
- Start marking incoming messages as read immediately after the message list is refreshed.
- Move reaction lookups to background work so slow reaction queries cannot delay read receipts or subsequent message refreshes.
- Keep text-message optimistic sending, Realtime reconnect, photo/video upload, and existing chat features unchanged.

- Apply INSERT/UPDATE rows from Supabase Realtime directly to the visible chat, avoiding a full message-list download after every event.
- Update read checkmarks from the incoming UPDATE event; immediately mark newly received messages as read while the chat is open.

## 1.5.11 — queued read acknowledgements
- Queue read acknowledgements that arrive while an earlier mark-read request is in flight, so a newly received message is not left unread until the next safety refresh.
- Keep the 1.5.10 direct Realtime row updates and optimistic text sending path unchanged.
