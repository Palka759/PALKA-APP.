PALKA 1.5.14 — fast text message sending

Focused change based on 1.5.13:
- Text messages use a PostgREST INSERT with the minimal response (no follow-up representation SELECT).
- The UI keeps its optimistic local bubble immediately and reconciles it with the authoritative Realtime INSERT, avoiding an extra REST read after send.
- Reply-to is included in the INSERT and used when matching the pending local bubble.
- Photo/video sending and rich-message flows are unchanged.
- Android versionCode 15 / versionName 1.5.14.

Validation:
- Source ZIP integrity checked after packaging.
- Static checks confirmed the fast-send call, Realtime reconciliation, and version/workflow labels.
- A full Android Gradle build was not run in this environment (Gradle executable is unavailable).
