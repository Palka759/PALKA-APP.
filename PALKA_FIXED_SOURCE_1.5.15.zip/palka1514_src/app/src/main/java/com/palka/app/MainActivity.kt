package com.palka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.widget.VideoView
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import android.widget.MediaController
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import coil.compose.AsyncImage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive

private var activeTheme by mutableStateOf("Лесная")
private val Night: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF080A0F)
    "Светлая" -> Color(0xFFF2F4EF)
    else -> Color(0xFF101710)
}
private val Panel: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF171B24)
    "Светлая" -> Color(0xFFFFFFFF)
    else -> Color(0xFF1B281D)
}
private val Green: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF80B7FF)
    "Светлая" -> Color(0xFF287A42)
    else -> Color(0xFF9BE564)
}
private val Wood: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF9AA8BC)
    "Светлая" -> Color(0xFF93602E)
    else -> Color(0xFFB9824B)
}
private val Cream: Color get() = if (activeTheme == "Светлая") Color(0xFF172019) else Color(0xFFF1E8D8)

private fun tr(language: String, text: String): String {
    if (language == "Русский") return text
    val uk = mapOf(
        "Настройки" to "Налаштування", "Тема" to "Тема", "Обои чата" to "Шпалери чату", "Язык" to "Мова", "Аккаунт" to "Обліковий запис", "Уведомления" to "Сповіщення", "Чёрный список" to "Чорний список", "Выйти" to "Вийти", "Главное" to "Головне", "Лесная" to "Лісова", "Тёмная" to "Темна", "Светлая" to "Світла", "Русский" to "Російська", "Українська" to "Українська", "English" to "English", "Выбрана" to "Обрана", "Нажми, чтобы выбрать" to "Натисни, щоб обрати", "Назад" to "Назад", "Чаты" to "Чати", "Контакты" to "Контакти", "Заметки" to "Нотатки", "Профиль" to "Профіль", "Поиск чатов" to "Пошук чатів", "Пока нет чатов" to "Поки немає чатів", "Найди друга во вкладке Контакты" to "Знайди друга у вкладці Контакти", "Введи ник друга и нажми поиск" to "Введи нік друга та натисни пошук", "Мои заметки" to "Мої нотатки", "Сохранить" to "Зберегти", "Фото" to "Фото", "Изменить" to "Змінити", "Палка тут" to "Палка тут", "Не в сети" to "Не в мережі"
    )
    val en = mapOf(
        "Настройки" to "Settings", "Тема" to "Theme", "Обои чата" to "Chat wallpapers", "Язык" to "Language", "Аккаунт" to "Account", "Уведомления" to "Notifications", "Чёрный список" to "Blocked users", "Выйти" to "Sign out", "Главное" to "Main", "Лесная" to "Forest", "Тёмная" to "Dark", "Светлая" to "Light", "Русский" to "Russian", "Українська" to "Ukrainian", "Выбрана" to "Selected", "Нажми, чтобы выбрать" to "Tap to select", "Выбрать язык" to "Select language", "Назад" to "Back", "Чаты" to "Chats", "Контакты" to "Contacts", "Заметки" to "Notes", "Профиль" to "Profile", "Поиск чатов" to "Search chats", "Пока нет чатов" to "No chats yet", "Найди друга во вкладке Контакты" to "Find a friend in Contacts", "Введи ник друга и нажми поиск" to "Enter a username and search", "Мои заметки" to "My notes", "Сохранить" to "Save", "Фото" to "Photo", "Изменить" to "Edit", "Палка тут" to "Stick is here", "Не в сети" to "Offline"
    )
    return if (language == "Українська") uk[text] ?: text else en[text] ?: text
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PalkaApp() } }
}

@Composable fun PalkaApp() {
    var authReady by remember { mutableStateOf(false) }
    var signedIn by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf<Profile?>(null) }
    var profileLoaded by remember { mutableStateOf(false) }
    var profileLoading by remember { mutableStateOf(false) }
    var profileLoadAttempt by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Profile?>(null) }
    var conversationId by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val applicationContextForPalka = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        runCatching { Backend.awaitAuthInitialization() }
        signedIn = Backend.userId != null
        authReady = true
    }
    LaunchedEffect(signedIn, profileLoadAttempt) {
        if (signedIn) {
            profileLoading = true
            profileLoaded = false
            var lastError: Throwable? = null
            for (attempt in 0..3) {
                try {
                    profile = Backend.myProfile()
                    profileLoaded = true
                    error = ""
                    break
                } catch (t: Throwable) {
                    lastError = t
                    if (attempt < 3) delay(900L * (attempt + 1))
                }
            }
            if (!profileLoaded) error = lastError?.message ?: "Не удалось загрузить профиль"
            profileLoading = false
        } else { profile = null; profileLoaded = false; profileLoading = false }
    }
    LaunchedEffect(signedIn) {
        while (signedIn) { runCatching { Backend.touchPresence() }; delay(60_000) }
    }
    MaterialTheme(colorScheme = if (activeTheme == "Светлая") lightColorScheme(background = Night, surface = Panel, primary = Green, onPrimary = Color.White, onBackground = Cream, onSurface = Cream) else darkColorScheme(background = Night, surface = Panel, primary = Green, onPrimary = Night, onBackground = Cream, onSurface = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            when {
                !authReady -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
                !signedIn -> AuthScreen(busy, error, onClear = { error = "" }, onAuth = { email, pass, register ->
                    scope.launch { busy = true; error = ""; runCatching { if (register) Backend.signUp(email, pass) else Backend.signIn(email, pass); signedIn = Backend.userId != null
                        if (register && !signedIn) error = "Проверь почту и подтверди регистрацию" }.onFailure { error = it.message ?: "Не удалось войти" }; busy = false }
                })
                signedIn && !profileLoaded && profileLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(color = Green); Text("Подключаемся к PALKA…", color = Cream, modifier = Modifier.padding(16.dp)) } }
                signedIn && !profileLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Не удалось загрузить профиль", color = Cream); Text(error.take(180), color = Color(0xFFFF9B86), modifier = Modifier.padding(12.dp)); Button(onClick = { profileLoadAttempt++ }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Повторить", color = Night) } } }
                profile == null -> ProfileSetup(error) { nick -> scope.launch { busy = true; runCatching { Backend.saveProfile(nick); profile = Backend.myProfile(); profileLoaded = true }.onFailure { error = it.message ?: "Не удалось сохранить ник" }; busy = false } }
                screen == "chat" && selected != null && conversationId != null -> ChatScreen(selected!!, conversationId!!, onBack = { screen = "home" })
                else -> HomeScreen(profile!!, onOpen = { p -> scope.launch { busy = true; runCatching { conversationId = Backend.openConversation(p.id); selected = p; screen = "chat" }.onFailure { error = it.message ?: "Ошибка чата" }; busy = false } }, onSignOut = { scope.launch { Backend.signOut(); signedIn = false; profile = null } }, onSaveProfile = { displayName, nick, photoUri -> scope.launch { busy = true; runCatching { val avatar = photoUri?.let { uri -> val bytes = applicationContextForPalka.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать фото"); Backend.uploadAvatar(bytes, uri.lastPathSegment ?: "avatar.jpg") }; Backend.saveProfile(nick, avatar ?: profile?.avatarUrl, displayName); profile = Backend.myProfile() }.onFailure { error = it.message ?: "Не удалось сохранить профиль" }; busy = false } }, error = error)
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
        }
    }
}

@Composable private fun AuthScreen(busy: Boolean, error: String, onClear: () -> Unit, onAuth: (String, String, Boolean) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var register by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(28.dp))
        Text(if (register) "Создать аккаунт" else "С возвращением!", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("Только email и пароль. Номер не нужен.", color = Green, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        PalkaField(email, { email = it }, "Email", keyboard = KeyboardType.Email)
        Spacer(Modifier.height(12.dp)); PalkaField(password, { password = it }, "Пароль", secret = true)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp)); Button(onClick = { onClear(); onAuth(email.trim(), password, register) }, enabled = !busy && email.contains("@") && password.length >= 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (register) "Зарегистрироваться" else "Войти", color = Night, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { register = !register }) { Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Регистрация", color = Cream) }
    }
}

@Composable private fun ProfileSetup(error: String, save: (String) -> Unit) {
    var nick by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(24.dp)); Text("Придумай свой ник", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("По нему тебя смогут найти друзья", color = Green, modifier = Modifier.padding(vertical = 12.dp))
        PalkaField(nick, { nick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "Например: lesnoy_palka")
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86))
        Button(onClick = { save(nick.lowercase()) }, enabled = nick.length in 3..20, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Продолжить", color = Night) }
    }
}

@Composable private fun HomeScreen(me: Profile, onOpen: (Profile) -> Unit, onSignOut: () -> Unit, onSaveProfile: (String, String, Uri?) -> Unit, error: String) {
    var tab by remember { mutableStateOf("Чаты") }
    var editProfile by remember { mutableStateOf(false) }
    var settingsSection by remember { mutableStateOf("Главное") }
    val context = LocalContext.current
    val settingsPrefs = remember(me.id) { context.getSharedPreferences("palka_settings_${me.id}", android.content.Context.MODE_PRIVATE) }
    var appTheme by remember(me.id) { mutableStateOf(settingsPrefs.getString("theme", "Лесная") ?: "Лесная") }
    LaunchedEffect(appTheme) { activeTheme = appTheme }
    var appLanguage by remember(me.id) { mutableStateOf(settingsPrefs.getString("language", "Русский") ?: "Русский") }
    var notificationsEnabled by remember(me.id) { mutableStateOf(settingsPrefs.getBoolean("notifications", true)) }
    var editNick by remember(me.username) { mutableStateOf(me.username) }
    var editName by remember(me.displayName) { mutableStateOf(me.displayName) }
    var selectedPhoto by remember { mutableStateOf<Uri?>(null) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedPhoto = uri }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var chats by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    val notesPrefs = remember(me.id) { context.getSharedPreferences("palka_notes_${me.id}", android.content.Context.MODE_PRIVATE) }
    var notesText by remember(me.id) { mutableStateOf(notesPrefs.getString("body", "") ?: "") }
    var notesSaved by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(me.id) {
        runCatching { chats = Backend.chatPartners() }
        runCatching { val remote = Backend.privateNote(); if (remote.isNotEmpty()) { notesText = remote; notesPrefs.edit().putString("body", remote).apply() } }
    }
    Column(Modifier.fillMaxSize().imePadding().background(Night).then(if (appTheme == "Лесная") Modifier.paint(painterResource(R.drawable.palka_forest_wallpaper_1), contentScale = ContentScale.Crop) else Modifier)) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) { Text("🌲", fontSize = 26.sp); Spacer(Modifier.width(8.dp)); Text("PALKA", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Green) }
            IconButton(onClick = onSignOut) { Icon(Icons.Default.Logout, "Выйти", tint = Color.Gray) }
        }
        when (tab) {
            "Чаты" -> {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), placeholder = { Text(tr(appLanguage, "Поиск чатов")) }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.Gray) }, shape = RoundedCornerShape(28.dp), colors = fieldColors())
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), modifier = Modifier.padding(16.dp))
                if (chats.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("🪵", fontSize = 48.sp); Text(tr(appLanguage, "Пока нет чатов"), color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(tr(appLanguage, "Найди друга во вкладке Контакты"), color = Color.Gray, modifier = Modifier.padding(top = 6.dp)) }
                } else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                    items(chats.filter { it.username.contains(query, ignoreCase = true) }, key = { it.id }) { person -> UserRow(person, onClick = { onOpen(person) }) }
                }
                Box(Modifier.fillMaxWidth().padding(end = 20.dp, bottom = 10.dp), contentAlignment = Alignment.CenterEnd) {
                    FloatingActionButton(onClick = { tab = "Контакты" }, containerColor = Green, contentColor = Night) { Icon(Icons.Default.Add, "Новый чат") }
                }
            }
            "Контакты" -> {
                Text(tr(appLanguage, "Контакты"), color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 18.dp)) {
                    OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), placeholder = { Text("@username") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null, tint = Color.Gray) }, shape = RoundedCornerShape(24.dp), colors = fieldColors())
                    IconButton(enabled = query.trim().length >= 3 && !searching, onClick = { scope.launch { searching = true; runCatching { results = Backend.findUsers(query.trim().removePrefix("@")) }.onFailure { /* shown in empty state */ }; searching = false } }) { Icon(Icons.Default.Search, null, tint = Green) }
                }
                if (searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 18.dp), color = Green)
                if (results.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(tr(appLanguage, "Введи ник друга и нажми поиск"), color = Color.Gray) }
                else LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) { items(results, key = { it.id }) { person -> UserRow(person, onClick = { onOpen(person) }) } }
            }
            "Блокировки" -> {
                Text("Чёрный список", color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
                if (results.isEmpty()) Text("Здесь пока никого нет", color = Color.Gray, modifier = Modifier.padding(20.dp))
                else LazyColumn(Modifier.weight(1f)) { items(results, key = { it.id }) { person ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        UserRow(person) { }
                        TextButton(onClick = { scope.launch { runCatching { Backend.unblockUser(person.id); results = Backend.blockedProfiles() }.onFailure { /* keep list */ } } }) { Text("Разблокировать", color = Green) }
                    }
                } }
                Spacer(Modifier.weight(1f))
            }
            "Заметки" -> {
                Text(tr(appLanguage, "Мои заметки"), color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it; notesSaved = false; notesPrefs.edit().putString("body", it).apply() },
                    modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
                    placeholder = { Text("Запиши сюда свои мысли...") },
                    shape = RoundedCornerShape(18.dp), colors = fieldColors(), minLines = 8
                )
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (notesSaved) "Сохранено на этом устройстве" else "Личные заметки", color = Color.Gray, modifier = Modifier.weight(1f), fontSize = 12.sp)
                    Button(onClick = { scope.launch { runCatching { Backend.savePrivateNote(notesText); notesPrefs.edit().putString("body", notesText).apply(); notesSaved = true }.onFailure { notesSaved = false } } }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr(appLanguage, "Сохранить"), color = Night) }
                }
            }
            "Настройки" -> {
                Text(if (settingsSection == "Главное") tr(appLanguage, "Настройки") else tr(appLanguage, settingsSection), color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp))
                Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (settingsSection == "Главное") {
                        SettingsRow(tr(appLanguage, "Тема"), tr(appLanguage, "Лесная"), Icons.Default.Home) { settingsSection = "Тема" }
                        SettingsRow(tr(appLanguage, "Обои чата"), if (appLanguage == "English") "Forest backgrounds" else if (appLanguage == "Українська") "Лісові фони" else "Лесные фоны", Icons.Default.Image) { settingsSection = "Обои чата" }
                        SettingsRow(tr(appLanguage, "Язык"), tr(appLanguage, appLanguage), Icons.Default.Contacts) { settingsSection = "Язык" }
                        SettingsRow(tr(appLanguage, "Аккаунт"), if (appLanguage == "English") "Profile and personal details" else if (appLanguage == "Українська") "Профіль та особисті дані" else "Профиль и личные данные", Icons.Default.Person) { settingsSection = "Аккаунт" }
                        SettingsRow(tr(appLanguage, "Уведомления"), if (notificationsEnabled) "Включены" else "Выключены", Icons.Default.Settings) { settingsSection = "Уведомления" }
                        SettingsRow(tr(appLanguage, "Чёрный список"), if (appLanguage == "English") "Blocked users" else if (appLanguage == "Українська") "Заблоковані користувачі" else "Заблокированные пользователи", Icons.Default.Block) { scope.launch { runCatching { results = Backend.blockedProfiles() }; tab = "Блокировки" } }
                        SettingsRow(tr(appLanguage, "Выйти"), if (appLanguage == "English") "End current session" else if (appLanguage == "Українська") "Завершити поточний сеанс" else "Завершить текущий сеанс", Icons.Default.Logout, onSignOut)
                    } else {
                        SettingsRow("‹ ${tr(appLanguage, "Назад")}", tr(appLanguage, "Настройки"), Icons.Default.ArrowBack) { settingsSection = "Главное" }
                        when (settingsSection) {
                            "Тема" -> listOf("Лесная", "Тёмная", "Светлая").forEach { choice -> SettingsRow(tr(appLanguage, choice), if (appTheme == choice) "✓ ${tr(appLanguage, "Выбрана")}" else tr(appLanguage, "Нажми, чтобы выбрать"), Icons.Default.Home) { appTheme = choice; activeTheme = choice; settingsPrefs.edit().putString("theme", choice).apply() } }
                            "Обои чата" -> listOf("Лес · хвоя", "Лес · луна", "Горы и озеро", "Листья").forEachIndexed { index, choice -> SettingsRow(choice, "Обои для личных чатов", Icons.Default.Image) { context.getSharedPreferences("palka_wallpaper_default", android.content.Context.MODE_PRIVATE).edit().putInt("wallpaper", index).apply() } }
                            "Язык" -> listOf("Русский", "Українська", "English").forEach { choice -> SettingsRow(tr(appLanguage, choice), if (appLanguage == choice) "✓ ${tr(appLanguage, "Выбрана")}" else tr(appLanguage, "Выбрать язык"), Icons.Default.Contacts) { appLanguage = choice; settingsPrefs.edit().putString("language", choice).apply() } }
                            "Аккаунт" -> SettingsRow(if (appLanguage == "English") "Edit profile" else if (appLanguage == "Українська") "Змінити профіль" else "Изменить профиль", if (appLanguage == "English") "Name, @username and avatar" else if (appLanguage == "Українська") "Ім’я, @username та аватар" else "Имя, @username и аватар", Icons.Default.Edit) { editProfile = true }
                            "Уведомления" -> SettingsRow(if (appLanguage == "English") "Message notifications" else if (appLanguage == "Українська") "Сповіщення про повідомлення" else "Уведомления о сообщениях", if (notificationsEnabled) (if (appLanguage == "English") "On" else if (appLanguage == "Українська") "Увімкнені" else "Включены") else (if (appLanguage == "English") "Off" else if (appLanguage == "Українська") "Вимкнені" else "Выключены"), Icons.Default.Settings) { notificationsEnabled = !notificationsEnabled; settingsPrefs.edit().putBoolean("notifications", notificationsEnabled).apply() }
                        }
                    }
                    Text("PALKA · лесной стиль", color = Wood, modifier = Modifier.padding(8.dp))
                }
            }
            else -> {
                Column(Modifier.weight(1f).fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(28.dp)); Avatar(me.username, me.avatarUrl)
                    Text(me.displayName.ifBlank { me.username }, color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                    Text("@${me.username}", color = Green)
                    Row(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { editProfile = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel)) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(5.dp)); Text(tr(appLanguage, "Фото")) }
                        Button(onClick = { editProfile = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Panel)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(5.dp)); Text("Изменить") }
                    }
                }
            }
        }
        NavigationBar(containerColor = Panel, contentColor = Cream) {
            listOf(Triple("Чаты", Icons.Default.ChatBubble, "Чаты"), Triple("Контакты", Icons.Default.Contacts, "Контакты"), Triple("Заметки", Icons.Default.StickyNote2, "Заметки"), Triple("Настройки", Icons.Default.Settings, "Настройки"), Triple("Профиль", Icons.Default.Person, "Профиль")).forEach { (label, icon, target) ->
                NavigationBarItem(selected = tab == target, onClick = { tab = target }, icon = { Icon(icon, contentDescription = label) }, label = { Text(tr(appLanguage, label), fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Color(0xFF23452B), unselectedIconColor = Cream, unselectedTextColor = Cream))
            }
        }
    }
    if (editProfile) AlertDialog(
        onDismissRequest = { editProfile = false }, containerColor = Panel,
        title = { Text("Твой профиль", color = Cream) },
        text = { Column { PalkaField(editName, { editName = it.take(40) }, "Имя"); Spacer(Modifier.height(10.dp)); PalkaField(editNick, { editNick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "@username (3–20 символов)"); Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Avatar(editNick, selectedPhoto?.toString() ?: me.avatarUrl); Spacer(Modifier.width(12.dp)); Button(onClick = { photoPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Icon(Icons.Default.CameraAlt, null, tint = Night); Spacer(Modifier.width(6.dp)); Text("Выбрать из галереи", color = Night) } } } },
        confirmButton = { TextButton(onClick = { onSaveProfile(editName.trim(), editNick.lowercase(), selectedPhoto); editProfile = false }) { Text("Сохранить", color = Green) } },
        dismissButton = { TextButton(onClick = { editProfile = false }) { Text("Отмена", color = Cream) } }
    )
}

@Composable private fun SettingsRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green); Spacer(Modifier.width(14.dp)); Column { Text(title, color = Cream, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable private fun UserRow(person: Profile, onClick: () -> Unit) {
    val online = remember(person.lastSeen) { try { person.lastSeen?.let { java.time.Duration.between(java.time.Instant.parse(it), java.time.Instant.now()).seconds < 75 } ?: false } catch (_: Exception) { false } }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(person.username, person.avatarUrl); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("@${person.username}", fontWeight = FontWeight.Bold, color = Cream); if (online) Row(verticalAlignment = Alignment.CenterVertically) { Text("🪵", fontSize = 12.sp); Text("Палка тут", color = Green, fontSize = 12.sp) } else Text("Не в сети", color = Color.Gray, fontSize = 12.sp) }
        Text("Написать  ›", color = Green, fontSize = 13.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun ChatScreen(friend: Profile, conversationId: String, onBack: () -> Unit) {
    var messages by remember(conversationId) { mutableStateOf(Backend.cachedMessages(conversationId)) }
    var reactionsByMessage by remember { mutableStateOf<Map<String, List<Reaction>>>(emptyMap()) }
    var pinnedMessageId by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var chatError by remember { mutableStateOf("") }
    var peerTyping by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf<ChatMessage?>(null) }
    var editTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var menuMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var selectedMessage by remember { mutableStateOf<ChatMessage?>(null) }
    val context = LocalContext.current
    val wallpaperPrefs = remember(conversationId) { context.getSharedPreferences("palka_wallpaper_$conversationId", android.content.Context.MODE_PRIVATE) }
    var wallpaper by remember(conversationId) { mutableIntStateOf(wallpaperPrefs.getInt("wallpaper", context.getSharedPreferences("palka_wallpaper_default", android.content.Context.MODE_PRIVATE).getInt("wallpaper", 0))) }
    val scope = rememberCoroutineScope()
    var typingJob by remember { mutableStateOf<Job?>(null) }
    var typingRemoteActive by remember(conversationId) { mutableStateOf(false) }
    val uid = Backend.userId
    val listState = rememberLazyListState()
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            sending = true
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать файл")
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val video = mime.startsWith("video/")
                val isGif = mime.equals("image/gif", true)
                val bytes = if (!video && !isGif) compressChatImage(raw) else raw
                val name = if (video) "video.mp4" else if (isGif) "image.gif" else "image.jpg"
                val url = Backend.uploadChatMedia(bytes, name)
                val sent = Backend.sendRichMessage(conversationId, if (video) "🎥 Видео" else "📷 Фото", reply?.id, url, if (video) "video" else "image")
                messages = (messages + sent).distinctBy { it.id }.takeLast(200)
                reply = null
            }.onFailure { chatError = it.message ?: "Не удалось отправить файл" }
            sending = false
        }
    }
    LaunchedEffect(conversationId) {
        var refreshRunning = false
        var refreshPending = false
        var extrasLoaded = false
        var markReadRunning = false
        var markReadPending = false
        val reactionLoadsInFlight = mutableSetOf<String>()

        // Coalesce read acknowledgements without losing a new incoming message
        // that arrives while the previous UPDATE request is still in flight.
        fun requestMarkRead() {
            markReadPending = true
            if (markReadRunning) return
            markReadRunning = true
            launch {
                try {
                    while (markReadPending && isActive) {
                        markReadPending = false
                        runCatching { Backend.markRead(conversationId) }
                    }
                } finally {
                    markReadRunning = false
                    // Close the tiny race where a request was queued as the loop ended.
                    if (markReadPending && isActive) requestMarkRead()
                }
            }
        }

        suspend fun refreshMessages(fromRealtime: Boolean = false) {
            if (refreshRunning) {
                refreshPending = true
                return
            }
            refreshRunning = true
            try {
                val before = messages
                val previousIds = before.mapNotNull { it.id }.toSet()
                val loaded = Backend.messages(conversationId)
                // Keep optimistic local messages while a slow insert request is still in flight.
                val pendingLocal = before.filter { local ->
                    local.id?.startsWith("local-") == true && loaded.none { server ->
                        server.senderId == local.senderId && server.body == local.body &&
                            server.replyTo == local.replyTo
                    }
                }
                messages = (loaded + pendingLocal).distinctBy { it.id }.takeLast(200)

                // Start read-receipt writes immediately. Previously reaction lookups
                // ran sequentially before this block, delaying the recipient's read
                // acknowledgement when several messages arrived together.
                val hasUnreadIncoming = loaded.any { it.senderId != uid && it.readAt == null }
                if (hasUnreadIncoming) requestMarkRead()

                // Reaction lookups are secondary UI data. Fetch them in the background
                // so they never hold up message refreshes or read receipts.
                val newIds = loaded.mapNotNull { it.id }
                    .filter { it !in previousIds && it !in reactionsByMessage && it !in reactionLoadsInFlight }
                    .takeLast(40)
                if (newIds.isNotEmpty()) {
                    reactionLoadsInFlight.addAll(newIds)
                    launch {
                        try {
                            val additions = buildMap<String, List<Reaction>> {
                                newIds.forEach { id -> put(id, runCatching { Backend.messageReactions(id) }.getOrDefault(emptyList())) }
                            }
                            reactionsByMessage = reactionsByMessage + additions
                        } finally {
                            reactionLoadsInFlight.removeAll(newIds.toSet())
                        }
                    }
                }

                if (!extrasLoaded) {
                    extrasLoaded = true
                    launch { runCatching { peerTyping = Backend.peerTyping(conversationId) } }
                    launch { runCatching { pinnedMessageId = Backend.pinnedMessageId(conversationId) } }
                }
                chatError = ""
            } catch (t: Throwable) {
                chatError = t.message ?: "Не удалось обновить чат"
            } finally {
                loading = false
                refreshRunning = false
                if (refreshPending) {
                    refreshPending = false
                    launch { refreshMessages(fromRealtime = true) }
                }
            }
        }

        refreshMessages()
        coroutineScope {
            // Keep the Realtime subscription alive and reconnect with backoff if it exits.
            launch {
                var retryDelay = 1000L
                while (isActive) {
                    val result = runCatching {
                        Backend.watchMessages(conversationId) { changed, inserted ->
                            val changedId = changed.id
                            if (changedId != null) {
                                val index = messages.indexOfFirst { it.id == changedId }
                                if (index >= 0) {
                                    val updated = messages.toMutableList()
                                    updated[index] = changed
                                    messages = updated
                                } else if (inserted) {
                                    // Reconcile the instant local bubble with the authoritative
                                    // Realtime row. Match only this user's pending text/reply.
                                    val pendingIndex = if (changed.senderId == uid) messages.indexOfLast {
                                        it.id?.startsWith("local-") == true &&
                                            it.senderId == changed.senderId && it.body == changed.body &&
                                            it.replyTo == changed.replyTo
                                    } else -1
                                    messages = if (pendingIndex >= 0) {
                                        messages.toMutableList().also { it[pendingIndex] = changed }
                                            .distinctBy { it.id }.sortedBy { it.createdAt.orEmpty() }.takeLast(200)
                                    } else {
                                        (messages + changed).distinctBy { it.id }
                                            .sortedBy { it.createdAt.orEmpty() }.takeLast(200)
                                    }
                                }

                                if (inserted && changed.senderId != uid && changed.readAt == null) {
                                    requestMarkRead()
                                }

                                if (inserted && changedId !in reactionsByMessage && changedId !in reactionLoadsInFlight) {
                                    reactionLoadsInFlight.add(changedId)
                                    launch {
                                        try {
                                            val found = runCatching { Backend.messageReactions(changedId) }.getOrDefault(emptyList())
                                            reactionsByMessage = reactionsByMessage + (changedId to found)
                                        } finally { reactionLoadsInFlight.remove(changedId) }
                                    }
                                }
                            }
                        }
                    }
                    if (isActive) {
                        result.exceptionOrNull()?.let { chatError = it.message ?: "Переподключение к чату..." }
                        delay(retryDelay)
                        retryDelay = (retryDelay * 2).coerceAtMost(15000L)
                    }
                }
            }
            // Lightweight safety refresh if Realtime is temporarily disconnected.
            launch {
                while (isActive) { delay(15000); refreshMessages() }
            }
            // Typing is not a messages-table event, so refresh it separately.
            launch {
                while (isActive) {
                    delay(3500)
                    runCatching { peerTyping = Backend.peerTyping(conversationId) }
                }
            }
        }
    }
    DisposableEffect(conversationId) {
        onDispose {
            typingJob?.cancel()
            if (typingRemoteActive) {
                scope.launch { runCatching { Backend.setTyping(conversationId, false) } }
            }
        }
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    val wallpapers = listOf(R.drawable.palka_forest_wallpaper_1, R.drawable.palka_forest_wallpaper_2, R.drawable.palka_forest_wallpaper_3, R.drawable.palka_forest_wallpaper_4)
    Column(Modifier.fillMaxSize().imePadding().background(Night).paint(painterResource(wallpapers[wallpaper % wallpapers.size]), contentScale = ContentScale.Crop)) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Green) }
            Avatar(friend.username, friend.avatarUrl)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(friend.displayName.ifBlank { "@${friend.username}" }, color = Cream, fontWeight = FontWeight.Bold); Text("@${friend.username}", color = Green, fontSize = 12.sp) }
            var menu by remember { mutableStateOf(false) }
            Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.Settings, null, tint = Cream) }; DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Следующие обои") }, onClick = { wallpaper = (wallpaper + 1) % wallpapers.size; wallpaperPrefs.edit().putInt("wallpaper", wallpaper).apply(); menu = false })
                DropdownMenuItem(text = { Text("Заблокировать") }, onClick = { menu = false; scope.launch { runCatching { Backend.blockUser(friend.id); onBack() }.onFailure { chatError = it.message ?: "Ошибка блокировки" } } })
            } }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        if (peerTyping) Text("печатает...", color = Green, fontSize = 12.sp, modifier = Modifier.padding(start = 18.dp, top = 4.dp))
        if (chatError.isNotBlank()) Text(if (chatError.contains("JWT expired", true) || chatError.contains("Unable to resolve host", true) || chatError.contains("No address associated with hostname", true) || chatError.contains("UnknownHostException", true)) "Нет связи с сервером. Повторяем подключение…" else chatError, color = Color(0xFFFF9B86), modifier = Modifier.fillMaxWidth().background(Panel).padding(8.dp), fontSize = 12.sp)
        val pinnedMessage = messages.firstOrNull { it.id == pinnedMessageId }
        if (pinnedMessage != null) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF203A2A)).clickable {
                val index = messages.indexOfFirst { it.id == pinnedMessageId }
                if (index >= 0) scope.launch { listState.animateScrollToItem(index) }
            }.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📌", fontSize = 18.sp)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("Закреплённое сообщение", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(pinnedMessage.body.ifBlank { if (pinnedMessage.mediaType == "video") "🎥 Видео" else "📷 Фото" }.take(75), color = Cream, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                TextButton(onClick = { scope.launch { runCatching { Backend.unpinMessage(conversationId, pinnedMessage.id!!); pinnedMessageId = null; chatError = "Сообщение откреплено" }.onFailure { chatError = it.message ?: "Не удалось открепить" } } }) { Text("Открепить", color = Green, fontSize = 11.sp) }
            }
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages, key = { it.id ?: it.hashCode().toString() }) { msg ->
                val mine = msg.senderId == uid
                val repliedMessage = messages.firstOrNull { it.id == msg.replyTo }
                var showMenu by remember(msg.id) { mutableStateOf(false) }
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Box {
                        Column(Modifier.padding(vertical = 4.dp).widthIn(max = 310.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (mine) Color(0xFF345333) else Panel)
                            .combinedClickable(onClick = { showMenu = true }, onLongClick = { menuMessage = msg })
                            .padding(10.dp)) {
                            if (msg.replyTo != null) {
                                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = .18f)).padding(7.dp)) {
                                    Text("↳ Ответ на сообщение", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(repliedMessage?.body?.take(100) ?: "Сообщение недоступно", color = Cream, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                                Spacer(Modifier.height(5.dp))
                            }
                            if (!msg.body.isBlank()) Text(msg.body, color = Cream)
                            if (!msg.mediaUrl.isNullOrBlank()) { if (msg.mediaType == "image") AsyncImage(model = msg.mediaUrl, contentDescription = "Открыть фото", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(12.dp)).clickable { selectedMessage = msg }) else if (msg.mediaType == "video") {
                                AndroidView(factory = { viewContext -> VideoView(viewContext).apply {
                                    setMediaController(MediaController(viewContext).also { it.setAnchorView(this) })
                                    setVideoURI(Uri.parse(msg.mediaUrl)); setOnPreparedListener { it.isLooping = false; start() }
                                } }, modifier = Modifier.fillMaxWidth().height(210.dp))
                            } }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                                if (msg.editedAt != null) Text("изменено · ", color = Color.LightGray, fontSize = 9.sp)
                                Text(msg.createdAt?.let { runCatching { java.time.Instant.parse(it).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) }.getOrDefault("") } ?: "", color = Color.LightGray, fontSize = 10.sp)
                                if (mine) { Spacer(Modifier.width(4.dp)); Text(if (msg.readAt != null) "✓✓" else "✓", color = if (msg.readAt != null) Green else Color.LightGray, fontSize = 11.sp) }
                            }
                            val messageReactions = msg.id?.let { reactionsByMessage[it] }.orEmpty().groupingBy { it.emoji }.eachCount()
                            if (messageReactions.isNotEmpty()) {
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 5.dp)) {
                                    messageReactions.forEach { (emoji, count) ->
                                        Text("$emoji $count", color = Cream, fontSize = 11.sp,
                                            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .22f)).clickable {
                                                scope.launch {
                                                    runCatching { Backend.react(msg.id ?: error("Нет ID"), emoji); reactionsByMessage = reactionsByMessage + ((msg.id ?: "") to Backend.messageReactions(msg.id!!)) }
                                                        .onFailure { chatError = it.message ?: "Не удалось поставить реакцию" }
                                                }
                                            }.padding(horizontal = 7.dp, vertical = 3.dp))
                                    }
                                }
                            }
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                listOf("❤️", "😂", "🪵", "👍").forEach { emoji ->
                                    Text(emoji, modifier = Modifier.clickable { scope.launch { runCatching { Backend.react(msg.id ?: error("Нет ID"), emoji); reactionsByMessage = reactionsByMessage + ((msg.id ?: "") to Backend.messageReactions(msg.id!!)) }.onFailure { chatError = it.message ?: "Не удалось поставить реакцию" }; showMenu = false } }.padding(4.dp), fontSize = 20.sp)
                                }
                            }
                            DropdownMenuItem(text = { Text("Ответить") }, onClick = { reply = msg; editTarget = null; showMenu = false })
                            DropdownMenuItem(text = { Text("Копировать") }, onClick = { val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; clipboard.setPrimaryClip(android.content.ClipData.newPlainText("PALKA", msg.body)); showMenu = false })
                            DropdownMenuItem(text = { Text("Переслать в этот чат") }, onClick = { scope.launch { runCatching { Backend.sendRichMessage(conversationId, msg.body, null, msg.mediaUrl, msg.mediaType); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Не удалось переслать" } }; showMenu = false })
                            if (pinnedMessageId == msg.id) DropdownMenuItem(text = { Text("Открепить") }, onClick = { scope.launch { runCatching { Backend.unpinMessage(conversationId, msg.id ?: error("Нет ID")); pinnedMessageId = null; chatError = "Сообщение откреплено" }.onFailure { chatError = it.message ?: "Не удалось открепить" } }; showMenu = false })
                            else DropdownMenuItem(text = { Text("Закрепить") }, onClick = { scope.launch { runCatching { Backend.pinMessage(conversationId, msg.id ?: error("Нет ID")); pinnedMessageId = msg.id; chatError = "Сообщение закреплено" }.onFailure { chatError = it.message ?: "Не удалось закрепить" } }; showMenu = false })
                            if (mine) {
                                DropdownMenuItem(text = { Text("Изменить") }, onClick = { editTarget = msg; text = msg.body; showMenu = false })
                                DropdownMenuItem(text = { Text("Удалить") }, onClick = { scope.launch { runCatching { Backend.deleteMessage(msg.id ?: return@launch); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Ошибка удаления" } }; showMenu = false })
                            }
                        }
                    }
                }
            }
        }
        selectedMessage?.let { photo ->
            Dialog(onDismissRequest = { selectedMessage = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black).clickable { selectedMessage = null }, contentAlignment = Alignment.Center) {
                    AsyncImage(model = photo.mediaUrl, contentDescription = "Фото", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().fillMaxHeight(.92f))
                    Text("Нажмите, чтобы закрыть", color = Color.White.copy(alpha = .8f), modifier = Modifier.align(Alignment.BottomCenter).padding(18.dp), fontSize = 12.sp)
                }
            }
        }
        if (menuMessage != null) {
            val target = menuMessage!!
            AlertDialog(onDismissRequest = { menuMessage = null }, title = { Text("Сообщение", color = Cream) },
                text = { Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("❤️", "😂", "🪵", "👍").forEach { emoji -> Text(emoji, modifier = Modifier.clickable { scope.launch { runCatching { Backend.react(target.id ?: error("Нет ID"), emoji); reactionsByMessage = reactionsByMessage + ((target.id ?: "") to Backend.messageReactions(target.id!!)) }.onFailure { chatError = it.message ?: "Не удалось поставить реакцию" } }; menuMessage = null }, fontSize = 19.sp) } }
                    TextButton(onClick = { reply = target; menuMessage = null }) { Text("↶  Ответить") }
                    TextButton(onClick = { val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; clipboard.setPrimaryClip(android.content.ClipData.newPlainText("PALKA", target.body)); menuMessage = null }) { Text("▢  Копировать") }
                    TextButton(onClick = { scope.launch { runCatching { Backend.sendRichMessage(conversationId, target.body, null, target.mediaUrl, target.mediaType); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Не удалось переслать" } }; menuMessage = null }) { Text("Переслать в этот чат") }
                    TextButton(onClick = { scope.launch { runCatching { if (pinnedMessageId == target.id) { Backend.unpinMessage(conversationId, target.id ?: error("Нет ID")); pinnedMessageId = null; chatError = "Сообщение откреплено" } else { Backend.pinMessage(conversationId, target.id ?: error("Нет ID")); pinnedMessageId = target.id; chatError = "Сообщение закреплено" } }.onFailure { chatError = it.message ?: "Не удалось изменить закрепление" } }; menuMessage = null }) { Text(if (pinnedMessageId == target.id) "Открепить" else "Закрепить") }
                    if (target.senderId == uid) {
                        TextButton(onClick = { editTarget = target; text = target.body; menuMessage = null }) { Text("Изменить") }
                        TextButton(onClick = { scope.launch { runCatching { Backend.deleteMessage(target.id ?: return@launch); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Ошибка удаления" } }; menuMessage = null }) { Text("Удалить") }
                    }
                } }, confirmButton = { TextButton(onClick = { menuMessage = null }) { Text("Закрыть") } })
        }
        if (reply != null) Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { Text("Ответ: ${reply!!.body.take(50)}", color = Green, modifier = Modifier.weight(1f), fontSize = 12.sp); TextButton(onClick = { reply = null }) { Text("Отмена") } }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { mediaPicker.launch(arrayOf("image/*", "video/*")) }) { Icon(Icons.Default.Image, "Фото или видео", tint = Green) }
            OutlinedTextField(text, { value ->
                text = value
                chatError = ""
                // Do not write to Supabase on every keystroke. One upsert starts
                // the typing session; only the idle timeout (or clearing the field)
                // ends it. This prevents typing traffic from queueing ahead of sends.
                typingJob?.cancel()
                if (value.isNotBlank()) {
                    if (!typingRemoteActive) {
                        typingRemoteActive = true
                        scope.launch {
                            runCatching { Backend.setTyping(conversationId, true) }
                                .onFailure { typingRemoteActive = false }
                        }
                    }
                    typingJob = scope.launch {
                        delay(3500)
                        if (typingRemoteActive) {
                            runCatching { Backend.setTyping(conversationId, false) }
                            typingRemoteActive = false
                        }
                    }
                } else if (typingRemoteActive) {
                    typingRemoteActive = false
                    scope.launch { runCatching { Backend.setTyping(conversationId, false) } }
                }
            }, modifier = Modifier.weight(1f), placeholder = { Text(if (editTarget != null) "Изменить сообщение..." else "Сообщение...") }, shape = RoundedCornerShape(18.dp), colors = fieldColors(), maxLines = 4, keyboardOptions = KeyboardOptions.Default.copy(imeAction = androidx.compose.ui.text.input.ImeAction.Send))
            IconButton(onClick = {
                val body = text.trim()
                if (body.isNotEmpty()) {
                    val editing = editTarget
                    if (editing?.id != null) {
                        if (!sending) scope.launch {
                            sending = true
                            chatError = ""
                            runCatching {
                                Backend.editMessage(editing.id!!, body)
                                messages = Backend.messages(conversationId)
                                text = ""
                                editTarget = null
                            }.onFailure { chatError = it.message ?: "Не удалось изменить сообщение" }
                            sending = false
                        }
                    } else {
                        // Render locally and clear the composer before any network request.
                        // Each send gets its own job, so a slow request cannot block the next one.
                        val replyId = reply?.id
                        val localId = "local-${java.util.UUID.randomUUID()}"
                        val optimistic = ChatMessage(
                            id = localId,
                            conversationId = conversationId,
                            senderId = uid.orEmpty(),
                            body = body,
                            createdAt = java.time.Instant.now().toString(),
                            replyTo = replyId
                        )
                        messages = (messages + optimistic).takeLast(200)
                        text = ""
                        reply = null
                        chatError = ""
                        scope.launch {
                            runCatching {
                                Backend.sendMessageFast(conversationId, body, replyId)
                                // Keep the local bubble until its matching Realtime INSERT
                                // arrives; no extra SELECT round-trip is needed after sending.
                            }.onFailure { error ->
                                messages = messages.filterNot { it.id == localId }
                                chatError = error.message ?: "Не удалось отправить сообщение"
                            }
                        }
                    }
                }
            }, enabled = text.isNotBlank() && (editTarget == null || !sending)) {
                if (editTarget != null && sending) CircularProgressIndicator(Modifier.size(22.dp), color = Green, strokeWidth = 2.dp)
                else Icon(Icons.Default.Send, null, tint = Green)
            }
        }
    }
}
private fun compressChatImage(bytes: ByteArray): ByteArray {
    return runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1920) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return bytes
        ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            bitmap.recycle()
            out.toByteArray()
        }
    }.getOrDefault(bytes)
}

@Composable private fun Logo() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("🪵", fontSize = 54.sp); Text("PALKA", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Green, letterSpacing = 3.sp)
        Text("деревянный чат для своих", color = Wood, fontSize = 13.sp)
    }
}
@Composable private fun Avatar(nick: String, url: String? = null) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF59412C)), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = "Аватар $nick", modifier = Modifier.fillMaxSize())
        else Text(nick.take(1).uppercase(), color = Cream, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}
@Composable private fun PalkaField(value: String, onChange: (String) -> Unit, hint: String, keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false) {
    OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(keyboardType = keyboard), visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, colors = fieldColors())
}
@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF52624F), focusedTextColor = Cream, unfocusedTextColor = Cream, focusedPlaceholderColor = Color.Gray, unfocusedPlaceholderColor = Color.Gray, cursorColor = Green)
