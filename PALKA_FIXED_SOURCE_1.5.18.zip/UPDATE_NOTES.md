# PALKA 1.5.15

- Reduced Supabase typing writes: one start update per typing burst instead of one write per keystroke.
- Kept optimistic local message rendering and the existing PostgREST message insert path unchanged.
- Left read receipts and media upload behavior unchanged.
- Updated Android version to 1.5.15 and CI archive selection.

Build status: source-level checks only; Android Gradle build must be verified by GitHub Actions.


## 1.5.17
- Corrected the workflow to prefer the exact 1.5.17 source archive, even when an older Android project exists at the repository root.
- Updated the Android version metadata to 1.5.17 (versionCode 17).
- Added server-side Realtime filters for the active conversation's INSERT and UPDATE events.
- Wait for the Realtime subscription before loading initial chat history (with an 8-second fallback when the network is unavailable).
