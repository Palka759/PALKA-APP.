# PALKA 1.5.2

- Text messages appear immediately in the chat while the server request completes; failed sends remove the temporary bubble and show the error.
- Realtime now listens for both new messages and message updates, so read-receipt changes can refresh without waiting for the fallback refresh.
- Incoming messages are marked read only when `read_at` is still NULL, avoiding repeated database writes.
- Fallback chat refresh interval is 15 seconds; normal new-message/read updates should arrive through Realtime.
- Photo/media upload flow is unchanged.

## Database
Run `supabase/update_v6.sql` in Supabase SQL Editor.

## Build
Source archive only. Android/Gradle build has not been run in this environment; verify with the repository's GitHub Actions workflow.
