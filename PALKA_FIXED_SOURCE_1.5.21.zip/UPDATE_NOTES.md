# PALKA 1.5.15

- Reduced Supabase typing writes: one start update per typing burst instead of one write per keystroke.
- Kept optimistic local message rendering and the existing PostgREST message insert path unchanged.
- Left read receipts and media upload behavior unchanged.
- Updated Android version to 1.5.15 and CI archive selection.

Build status: source-level checks only; Android Gradle build must be verified by GitHub Actions.


## 1.5.17
- Corrected the workflow to prefer the exact 1.5.17 source archive, even when an older Android project exists at the repository root.
- Updated the Android version metadata to 1.5.17 (versionCode 17).
- Added server-side Realtime filters for the active conversation's INSERT and UPDATE events.
- Wait for the Realtime subscription before loading initial chat history (with an 8-second fallback when the network is unavailable).

## 1.5.19
- Realtime channel is now unsubscribed/removed when the chat is left or the subscription restarts (it previously leaked forever).
- Each subscription uses a unique channel topic, so re-entering a chat cannot hit a stale channel.
- Realtime rows are decoded with ignoreUnknownKeys, so an unmodelled column can no longer silently drop message events.
- Verified: 1.5.18 source has no `.content` usage; "Unresolved reference: content" came from an older source, not this archive.
Build status: NOT compiled (no Android SDK/network in the review environment).

## 1.5.20
- Fix compile error: PostgresChangeFilter.filter is private in supabase-kt 3.2.3; use filter(column, FilterOperator.EQ, value).
Build status: NOT compiled locally.

## 1.5.21
- New UI following the design mockups: chat list (search, All/Personal/Groups tabs, last message, time, ticks, unread badge, online dot), bottom navigation (Chats / Calls / Profile), chat screen (bubbles, avatars, ticks, typing bubble, reactions + action menu on tap and long-press, pin banner, emoji bar, attach button, round send button), profile, appearance (wallpapers + themes + Apply), notifications settings.
- Groups and calls are placeholders ("coming soon"): there is no backend for them yet.
- Timestamps are parsed with OffsetDateTime first (PostgREST returns "+00:00"), which fixes blank message times / online / typing on runtimes where Instant.parse rejects offsets.
- supabase/update_v8.sql lets the "+" button in the reaction bar use any emoji. Run it once in the Supabase SQL editor.
- System push notifications are still not implemented; the toggles are stored for later.
Build status: NOT compiled locally.
