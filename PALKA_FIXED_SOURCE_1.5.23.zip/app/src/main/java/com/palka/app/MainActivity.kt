package com.palka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.widget.VideoView
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import android.widget.MediaController
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import coil.compose.AsyncImage
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Forward
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive

private var activeTheme by mutableStateOf("Лесная")
private val Night: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF07090D)
    "Светлая" -> Color(0xFFF2F4EF)
    else -> Color(0xFF080D0A)
}
private val Panel: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF171B24)
    "Светлая" -> Color(0xFFFFFFFF)
    else -> Color(0xFF131A15)
}
private val Green: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF80B7FF)
    "Светлая" -> Color(0xFF287A42)
    else -> Color(0xFF3DDC84)
}
private val Wood: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF9AA8BC)
    "Светлая" -> Color(0xFF93602E)
    else -> Color(0xFFB9824B)
}
private val Cream: Color get() = if (activeTheme == "Светлая") Color(0xFF172019) else Color(0xFFEEF2EA)
private val MineBubble: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xFF24446B)
    "Светлая" -> Color(0xFFD6F1C6)
    else -> Color(0xFF1D5733)
}
private val OtherBubble: Color get() = when (activeTheme) {
    "Тёмная" -> Color(0xE61A1F29)
    "Светлая" -> Color(0xFFFFFFFF)
    else -> Color(0xE6151C17)
}

private fun tr(language: String, text: String): String {
    if (language == "Русский") return text
    val uk = mapOf(
        "Настройки" to "Налаштування", "Тема" to "Тема", "Обои чата" to "Шпалери чату", "Язык" to "Мова", "Аккаунт" to "Обліковий запис", "Уведомления" to "Сповіщення", "Чёрный список" to "Чорний список", "Выйти" to "Вийти", "Главное" to "Головне", "Лесная" to "Лісова", "Тёмная" to "Темна", "Светлая" to "Світла", "Русский" to "Російська", "Українська" to "Українська", "English" to "English", "Выбрана" to "Обрана", "Нажми, чтобы выбрать" to "Натисни, щоб обрати", "Назад" to "Назад", "Чаты" to "Чати", "Контакты" to "Контакти", "Заметки" to "Нотатки", "Профиль" to "Профіль", "Поиск чатов" to "Пошук чатів", "Пока нет чатов" to "Поки немає чатів", "Найди друга во вкладке Контакты" to "Знайди друга у вкладці Контакти", "Введи ник друга и нажми поиск" to "Введи нік друга та натисни пошук", "Мои заметки" to "Мої нотатки", "Сохранить" to "Зберегти", "Фото" to "Фото", "Изменить" to "Змінити", "Палка тут" to "Палка тут", "Не в сети" to "Не в мережі"
    )
    val en = mapOf(
        "Настройки" to "Settings", "Тема" to "Theme", "Обои чата" to "Chat wallpapers", "Язык" to "Language", "Аккаунт" to "Account", "Уведомления" to "Notifications", "Чёрный список" to "Blocked users", "Выйти" to "Sign out", "Главное" to "Main", "Лесная" to "Forest", "Тёмная" to "Dark", "Светлая" to "Light", "Русский" to "Russian", "Українська" to "Ukrainian", "Выбрана" to "Selected", "Нажми, чтобы выбрать" to "Tap to select", "Выбрать язык" to "Select language", "Назад" to "Back", "Чаты" to "Chats", "Контакты" to "Contacts", "Заметки" to "Notes", "Профиль" to "Profile", "Поиск чатов" to "Search chats", "Пока нет чатов" to "No chats yet", "Найди друга во вкладке Контакты" to "Find a friend in Contacts", "Введи ник друга и нажми поиск" to "Enter a username and search", "Мои заметки" to "My notes", "Сохранить" to "Save", "Фото" to "Photo", "Изменить" to "Edit", "Палка тут" to "Stick is here", "Не в сети" to "Offline"
    )
    return if (language == "Українська") uk[text] ?: text else en[text] ?: text
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleNotificationIntent(intent)
        setContent { PalkaApp() }
    }
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }
    override fun onStart() {
        super.onStart()
        NotificationHelper.appVisible = true
        NotificationHelper.openConversationId?.let { NotificationHelper.cancelConversation(this, it) }
    }
    override fun onStop() { NotificationHelper.appVisible = false; super.onStop() }
    private fun handleNotificationIntent(i: android.content.Intent?) {
        val c = i?.getStringExtra("open_conversation")
        val p = i?.getStringExtra("open_peer")
        if (c != null && p != null) NotificationHelper.pendingOpen = c to p
    }
}

@Composable fun PalkaApp() {
    var authReady by remember { mutableStateOf(false) }
    var signedIn by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf<Profile?>(null) }
    var profileLoaded by remember { mutableStateOf(false) }
    var profileLoading by remember { mutableStateOf(false) }
    var profileLoadAttempt by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Profile?>(null) }
    var conversationId by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val applicationContextForPalka = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(Unit) {
        runCatching { Backend.awaitAuthInitialization() }
        signedIn = Backend.userId != null
        authReady = true
    }
    LaunchedEffect(signedIn, profileLoadAttempt) {
        if (signedIn) {
            profileLoading = true
            profileLoaded = false
            var lastError: Throwable? = null
            for (attempt in 0..3) {
                try {
                    profile = Backend.myProfile()
                    profileLoaded = true
                    error = ""
                    break
                } catch (t: Throwable) {
                    lastError = t
                    if (attempt < 3) delay(900L * (attempt + 1))
                }
            }
            if (!profileLoaded) error = lastError?.message ?: "Не удалось загрузить профиль"
            profileLoading = false
        } else { profile = null; profileLoaded = false; profileLoading = false }
    }
    LaunchedEffect(signedIn) {
        while (signedIn) { runCatching { Backend.touchPresence() }; delay(60_000) }
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    // Notifications: ask for permission once and start the background listener after sign-in.
    LaunchedEffect(signedIn, profile?.id) {
        val uid = Backend.userId
        if (signedIn && uid != null && profile != null) {
            NotificationHelper.ensureChannels(applicationContextForPalka)
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                androidx.core.content.ContextCompat.checkSelfPermission(applicationContextForPalka, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            if (NotificationHelper.settings(applicationContextForPalka, uid).getBoolean("notifications", true)) MessageService.start(applicationContextForPalka)
        }
    }
    // Tap on a notification: open that chat directly.
    val pendingOpen = NotificationHelper.pendingOpen
    LaunchedEffect(pendingOpen, profile) {
        val target = pendingOpen ?: return@LaunchedEffect
        if (profile == null) return@LaunchedEffect
        runCatching {
            val peer = Backend.profileById(target.second)
            if (peer != null) { conversationId = target.first; selected = peer; screen = "chat" }
        }
        NotificationHelper.pendingOpen = null
    }
    MaterialTheme(colorScheme = if (activeTheme == "Светлая") lightColorScheme(background = Night, surface = Panel, primary = Green, onPrimary = Color.White, onBackground = Cream, onSurface = Cream) else darkColorScheme(background = Night, surface = Panel, primary = Green, onPrimary = Night, onBackground = Cream, onSurface = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            when {
                !authReady -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
                !signedIn -> AuthScreen(busy, error, onClear = { error = "" }, onAuth = { email, pass, register ->
                    scope.launch { busy = true; error = ""; runCatching { if (register) Backend.signUp(email, pass) else Backend.signIn(email, pass); signedIn = Backend.userId != null
                        if (register && !signedIn) error = "Проверь почту и подтверди регистрацию" }.onFailure { error = it.message ?: "Не удалось войти" }; busy = false }
                })
                signedIn && !profileLoaded && profileLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(color = Green); Text("Подключаемся к PALKA…", color = Cream, modifier = Modifier.padding(16.dp)) } }
                signedIn && !profileLoaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Не удалось загрузить профиль", color = Cream); Text(error.take(180), color = Color(0xFFFF9B86), modifier = Modifier.padding(12.dp)); Button(onClick = { profileLoadAttempt++ }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Повторить", color = Night) } } }
                profile == null -> ProfileSetup(error) { nick -> scope.launch { busy = true; runCatching { Backend.saveProfile(nick); profile = Backend.myProfile(); profileLoaded = true }.onFailure { error = it.message ?: "Не удалось сохранить ник" }; busy = false } }
                screen == "chat" && selected != null && conversationId != null -> ChatScreen(selected!!, conversationId!!, onBack = { screen = "home" })
                else -> HomeScreen(profile!!, onOpen = { p -> scope.launch { busy = true; runCatching { conversationId = Backend.openConversation(p.id); selected = p; screen = "chat" }.onFailure { error = it.message ?: "Ошибка чата" }; busy = false } }, onSignOut = { scope.launch { MessageService.stop(applicationContextForPalka); NotificationHelper.cancelAll(applicationContextForPalka); Backend.signOut(); signedIn = false; profile = null } }, onSaveProfile = { displayName, nick, photoUri -> scope.launch { busy = true; runCatching { val avatar = photoUri?.let { uri -> val bytes = applicationContextForPalka.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать фото"); Backend.uploadAvatar(bytes, uri.lastPathSegment ?: "avatar.jpg") }; Backend.saveProfile(nick, avatar ?: profile?.avatarUrl, displayName); profile = Backend.myProfile() }.onFailure { error = it.message ?: "Не удалось сохранить профиль" }; busy = false } }, error = error)
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
        }
    }
}

@Composable private fun AuthScreen(busy: Boolean, error: String, onClear: () -> Unit, onAuth: (String, String, Boolean) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var register by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(28.dp))
        Text(if (register) "Создать аккаунт" else "С возвращением!", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("Только email и пароль. Номер не нужен.", color = Green, modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        PalkaField(email, { email = it }, "Email", keyboard = KeyboardType.Email)
        Spacer(Modifier.height(12.dp)); PalkaField(password, { password = it }, "Пароль", secret = true)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp)); Button(onClick = { onClear(); onAuth(email.trim(), password, register) }, enabled = !busy && email.contains("@") && password.length >= 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (register) "Зарегистрироваться" else "Войти", color = Night, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { register = !register }) { Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Регистрация", color = Cream) }
    }
}

@Composable private fun ProfileSetup(error: String, save: (String) -> Unit) {
    var nick by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Logo(); Spacer(Modifier.height(24.dp)); Text("Придумай свой ник", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Cream)
        Text("По нему тебя смогут найти друзья", color = Green, modifier = Modifier.padding(vertical = 12.dp))
        PalkaField(nick, { nick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "Например: lesnoy_palka")
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86))
        Button(onClick = { save(nick.lowercase()) }, enabled = nick.length in 3..20, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Продолжить", color = Night) }
    }
}

private val chatWallpapers get() = listOf(R.drawable.palka_forest_wallpaper_1, R.drawable.palka_forest_wallpaper_2, R.drawable.palka_forest_wallpaper_3, R.drawable.palka_forest_wallpaper_4)

private fun isOnline(lastSeen: String?): Boolean = try {
    lastSeen?.let { java.time.Duration.between(parseInstant(it), java.time.Instant.now()).seconds < 75 } ?: false
} catch (_: Exception) { false }

private fun formatBubbleTime(iso: String?): String {
    if (iso == null) return ""
    return try {
        parseInstant(iso).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
    } catch (_: Exception) { "" }
}

private fun formatListTime(iso: String?): String {
    if (iso == null) return ""
    return try {
        val z = parseInstant(iso).atZone(java.time.ZoneId.systemDefault())
        if (z.toLocalDate() == java.time.LocalDate.now(z.zone)) z.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
        else z.format(java.time.format.DateTimeFormatter.ofPattern("dd.MM"))
    } catch (_: Exception) { "" }
}

@Composable private fun HomeScreen(me: Profile, onOpen: (Profile) -> Unit, onSignOut: () -> Unit, onSaveProfile: (String, String, Uri?) -> Unit, error: String) {
    var tab by remember { mutableStateOf("Чаты") }
    var returnTab by remember { mutableStateOf("Чаты") }
    var chatFilter by remember { mutableStateOf("Все") }
    var editProfile by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val settingsPrefs = remember(me.id) { context.getSharedPreferences("palka_settings_${me.id}", android.content.Context.MODE_PRIVATE) }
    val wallpaperDefaultPrefs = remember { context.getSharedPreferences("palka_wallpaper_default", android.content.Context.MODE_PRIVATE) }
    var appTheme by remember(me.id) { mutableStateOf(settingsPrefs.getString("theme", "Лесная") ?: "Лесная") }
    LaunchedEffect(appTheme) { activeTheme = appTheme }
    var appLanguage by remember(me.id) { mutableStateOf(settingsPrefs.getString("language", "Русский") ?: "Русский") }
    var notificationsEnabled by remember(me.id) { mutableStateOf(settingsPrefs.getBoolean("notifications", true)) }
    var vibrationEnabled by remember(me.id) { mutableStateOf(settingsPrefs.getBoolean("vibration", true)) }
    var showMessageText by remember(me.id) { mutableStateOf(settingsPrefs.getBoolean("show_text", true)) }
    var showUnreadBadge by remember(me.id) { mutableStateOf(settingsPrefs.getBoolean("unread_badge", true)) }
    var soundName by remember(me.id) { mutableStateOf(settingsPrefs.getString("sound", "Лесной звонок") ?: "Лесной звонок") }
    var editNick by remember(me.username) { mutableStateOf(me.username) }
    var editName by remember(me.displayName) { mutableStateOf(me.displayName) }
    var selectedPhoto by remember { mutableStateOf<Uri?>(null) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedPhoto = uri }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var summaries by remember { mutableStateOf<List<ChatSummary>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var blockedCount by remember { mutableIntStateOf(0) }
    var sentCount by remember { mutableIntStateOf(0) }
    val notesPrefs = remember(me.id) { context.getSharedPreferences("palka_notes_${me.id}", android.content.Context.MODE_PRIVATE) }
    var notesText by remember(me.id) { mutableStateOf(notesPrefs.getString("body", "") ?: "") }
    var notesSaved by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun openSub(target: String) {
        query = ""
        if (target == "Контакты") results = emptyList()
        returnTab = tab
        tab = target
    }
    fun goBack() { query = ""; tab = returnTab }

    BackHandler(enabled = tab != "Чаты" && tab != "Звонки" && tab != "Профиль") { goBack() }

    LaunchedEffect(me.id) {
        runCatching { val remote = Backend.privateNote(); if (remote.isNotEmpty()) { notesText = remote; notesPrefs.edit().putString("body", remote).apply() } }
        runCatching { blockedCount = Backend.blockedUsers().size }
        runCatching { sentCount = Backend.sentMessageCount() }
    }
    // Chat list: last message, unread counters and presence. Refreshed while this screen is visible.
    LaunchedEffect(me.id) {
        while (true) {
            runCatching { summaries = Backend.chatSummaries() }
            delay(10_000)
        }
    }

    Column(Modifier.fillMaxSize().imePadding().background(Night).then(if (appTheme == "Лесная") Modifier.paint(painterResource(R.drawable.palka_forest_wallpaper_1), contentScale = ContentScale.Crop, alpha = .22f) else Modifier)) {
        if (tab == "Чаты" || tab == "Звонки") Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Park, null, tint = Green, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Text("PALKA", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Cream, modifier = Modifier.weight(1f))
            IconButton(onClick = { openSub("Уведомления") }) { Icon(Icons.Default.Notifications, "Уведомления", tint = Green) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                "Чаты" -> Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize()) {
                        PalkaSearch(query, { query = it }, "Поиск", Modifier.padding(horizontal = 16.dp))
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.padding(horizontal = 12.dp)) {
                            listOf("Все", "Личные", "Группы").forEach { f ->
                                Column(Modifier.clickable { chatFilter = f }.padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(f, color = if (chatFilter == f) Green else Cream.copy(alpha = .75f), fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 8.dp))
                                    Box(Modifier.height(2.dp).width(36.dp).background(if (chatFilter == f) Green else Color.Transparent))
                                }
                            }
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Cream.copy(alpha = .08f)))
                        val q = query.trim()
                        val shown = summaries.filter { s -> q.isEmpty() || s.peer.username.contains(q, true) || s.peer.displayName.contains(q, true) || s.last?.body.orEmpty().contains(q, true) }
                        if (chatFilter == "Группы") EmptyState("🌲", "Групповых чатов пока нет", "Группы появятся в одном из следующих обновлений")
                        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                            if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF9B86), modifier = Modifier.padding(16.dp)) }
                            if (shown.isEmpty()) item { Text(if (q.isEmpty()) "Пока нет чатов. Нажми + и найди друга по @username" else "Ничего не найдено", color = Color.Gray, modifier = Modifier.padding(20.dp)) }
                            items(shown, key = { it.conversationId }) { s -> ChatListRow(s, me.id, showUnreadBadge) { onOpen(s.peer) } }
                            if (chatFilter == "Все" && (q.isEmpty() || "заметки".contains(q, true))) item { NotesRow(notesText) { openSub("Заметки") } }
                        }
                    }
                    FloatingActionButton(onClick = { openSub("Контакты") }, modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp), containerColor = Green, contentColor = Night, shape = CircleShape) { Icon(Icons.Default.Add, "Новый чат") }
                }
                "Контакты" -> Column(Modifier.fillMaxSize()) {
                    SubHeader("Новый чат") { goBack() }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 16.dp)) {
                        PalkaSearch(query, { query = it }, "@username", Modifier.weight(1f))
                        IconButton(enabled = query.trim().length >= 3 && !searching, onClick = { scope.launch { searching = true; runCatching { results = Backend.findUsers(query.trim().removePrefix("@")) }; searching = false } }) { Icon(Icons.Default.Search, "Найти", tint = Green) }
                    }
                    if (searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), color = Green)
                    if (results.isEmpty()) EmptyState("🔎", "Найди друга", "Введи @username и нажми поиск")
                    else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) { items(results, key = { it.id }) { person -> UserRow(person) { onOpen(person) } } }
                }
                "Заметки" -> Column(Modifier.fillMaxSize()) {
                    SubHeader("Личные заметки") { goBack() }
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it; notesSaved = false; notesPrefs.edit().putString("body", it).apply() },
                        modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp),
                        placeholder = { Text("Запиши сюда свои мысли...") },
                        shape = RoundedCornerShape(18.dp), colors = fieldColors(), minLines = 8
                    )
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (notesSaved) "Сохранено" else "Личные заметки", color = Color.Gray, modifier = Modifier.weight(1f), fontSize = 12.sp)
                        Button(onClick = { scope.launch { runCatching { Backend.savePrivateNote(notesText); notesPrefs.edit().putString("body", notesText).apply(); notesSaved = true }.onFailure { notesSaved = false } } }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr(appLanguage, "Сохранить"), color = Night) }
                    }
                }
                "Звонки" -> EmptyState("📞", "Звонки скоро", "Голосовые звонки появятся в одном из следующих обновлений")
                "Профиль" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Box(Modifier.fillMaxWidth().height(290.dp)) {
                        Box(Modifier.matchParentSize().paint(painterResource(R.drawable.palka_forest_wallpaper_2), contentScale = ContentScale.Crop, alpha = .6f))
                        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Transparent, Night))))
                        Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box {
                                Avatar(me.username, me.avatarUrl, 120.dp)
                                Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Night).padding(3.dp).clip(CircleShape).background(Green))
                            }
                            Text(me.displayName.ifBlank { me.username }, color = Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                            Text("@${me.username}", color = Cream.copy(alpha = .85f), fontSize = 16.sp)
                            Text("В лесу… 🌲", color = Color.Gray, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        StatItem(if (sentCount >= 500) "500+" else sentCount.toString(), "Сообщения", Cream)
                        StatItem(summaries.size.toString(), "Друзей", Cream)
                        StatItem("Online", "Сейчас", Green)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { editProfile = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel, contentColor = Cream)) {
                        Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text("Изменить профиль", fontWeight = FontWeight.Medium)
                    }
                    Spacer(Modifier.height(8.dp))
                    ProfileRow(Icons.Default.Description, "Личные заметки", notesText.lineSequence().firstOrNull { it.isNotBlank() } ?: "Пока пусто") { openSub("Заметки") }
                    ProfileRow(Icons.Default.Block, "Чёрный список", "Заблокировано: $blockedCount") { scope.launch { runCatching { results = Backend.blockedProfiles(); blockedCount = results.size }; openSub("Блокировки") } }
                    ProfileRow(Icons.Default.Palette, "Оформление", "$appTheme стиль") { openSub("Оформление") }
                    ProfileRow(Icons.Default.Notifications, "Уведомления", if (notificationsEnabled) "Включены" else "Выключены") { openSub("Уведомления") }
                    ProfileRow(Icons.Default.Language, "Язык", appLanguage) { openSub("Язык") }
                    ProfileRow(Icons.Default.Logout, "Выйти", "Завершить текущий сеанс", onSignOut)
                    Spacer(Modifier.height(16.dp))
                }
                "Блокировки" -> Column(Modifier.fillMaxSize()) {
                    SubHeader("Чёрный список") { goBack() }
                    if (results.isEmpty()) EmptyState("🪵", "Здесь пока никого нет", "Заблокированные пользователи появятся тут")
                    else LazyColumn(Modifier.fillMaxSize()) {
                        items(results, key = { it.id }) { person ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f)) { UserRow(person, showWrite = false) { } }
                                TextButton(onClick = { scope.launch { runCatching { Backend.unblockUser(person.id); results = Backend.blockedProfiles(); blockedCount = results.size } } }) { Text("Разблокировать", color = Green) }
                            }
                        }
                    }
                }
                "Оформление" -> {
                    var pendingWallpaper by remember { mutableIntStateOf(wallpaperDefaultPrefs.getInt("wallpaper", 0)) }
                    var pendingTheme by remember { mutableStateOf(appTheme) }
                    Column(Modifier.fillMaxSize()) {
                        SubHeader("Оформление") { goBack() }
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                            Text("Обои для чатов", color = Cream, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                chatWallpapers.forEachIndexed { index, res ->
                                    Box(Modifier.weight(1f).aspectRatio(0.62f).clip(RoundedCornerShape(16.dp)).paint(painterResource(res), contentScale = ContentScale.Crop).then(if (pendingWallpaper == index) Modifier.border(2.dp, Green, RoundedCornerShape(16.dp)) else Modifier).clickable { pendingWallpaper = index }) {
                                        if (pendingWallpaper == index) Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(26.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Night, modifier = Modifier.size(18.dp)) }
                                    }
                                }
                            }
                            Text("Темы приложения", color = Cream, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("Лесная", "Тёмная", "Светлая").forEach { themeName ->
                                    val previewBg = when (themeName) { "Тёмная" -> Color(0xFF171B24); "Светлая" -> Color(0xFFE9EDE6); else -> Color(0xFF0F1A12) }
                                    val previewBar = when (themeName) { "Светлая" -> Color(0xFFBFC8BC); else -> Color(0xFF2A3A2E) }
                                    Column(Modifier.weight(1f).clickable { pendingTheme = themeName }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(16.dp)).background(previewBg).then(if (pendingTheme == themeName) Modifier.border(2.dp, Green, RoundedCornerShape(16.dp)) else Modifier).padding(12.dp)) {
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Box(Modifier.fillMaxWidth(.7f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(previewBar))
                                                Box(Modifier.fillMaxWidth(.5f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Green))
                                            }
                                        }
                                        Text(themeName, color = Cream, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                                        if (themeName == "Лесная") Text("(по умолчанию)", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        Button(onClick = {
                            appTheme = pendingTheme; activeTheme = pendingTheme
                            settingsPrefs.edit().putString("theme", pendingTheme).apply()
                            wallpaperDefaultPrefs.edit().putInt("wallpaper", pendingWallpaper).apply()
                            // Chats that had their own wallpaper follow the new default.
                            summaries.forEach { s -> context.getSharedPreferences("palka_wallpaper_${s.conversationId}", android.content.Context.MODE_PRIVATE).edit().remove("wallpaper").apply() }
                            goBack()
                        }, modifier = Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Night)) { Text("Применить", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 4.dp)) }
                    }
                }
                "Уведомления" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    SubHeader("Уведомления") { goBack() }
                    Column(Modifier.padding(horizontal = 12.dp).clip(RoundedCornerShape(18.dp)).background(Panel)) {
                        SwitchRow("Уведомления о сообщениях", notificationsEnabled) {
                            notificationsEnabled = it; settingsPrefs.edit().putBoolean("notifications", it).apply()
                            if (it) { NotificationHelper.ensureChannels(context); MessageService.start(context) }
                            else { MessageService.stop(context); NotificationHelper.cancelAll(context) }
                        }
                        Row(Modifier.fillMaxWidth().clickable {
                            val sounds = listOf("Лесной звонок", "Стук палки", "Тихий")
                            soundName = sounds[(sounds.indexOf(soundName) + 1) % sounds.size]
                            settingsPrefs.edit().putString("sound", soundName).apply()
                            val previewRes = when (soundName) { "Стук палки" -> R.raw.palka_knock; "Тихий" -> 0; else -> R.raw.palka_forest }
                            if (previewRes != 0) runCatching {
                                android.media.MediaPlayer.create(context, previewRes)?.apply { setOnCompletionListener { mp -> mp.release() }; start() }
                            }
                        }.padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Звук уведомлений", color = Cream, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text(soundName, color = Color.Gray, fontSize = 14.sp)
                            Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                        }
                        SwitchRow("Вибрация", vibrationEnabled) { vibrationEnabled = it; settingsPrefs.edit().putBoolean("vibration", it).apply() }
                        SwitchRow("Показывать текст сообщения", showMessageText) { showMessageText = it; settingsPrefs.edit().putBoolean("show_text", it).apply() }
                    }
                    Text("Уведомления в приложении", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp))
                    Column(Modifier.padding(horizontal = 12.dp).clip(RoundedCornerShape(18.dp)).background(Panel)) {
                        SwitchRow("Отображать счётчик непрочитанных", showUnreadBadge) { showUnreadBadge = it; settingsPrefs.edit().putBoolean("unread_badge", it).apply() }
                    }
                    Text("Система", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp))
                    Column(Modifier.padding(horizontal = 12.dp).clip(RoundedCornerShape(18.dp)).background(Panel)) {
                        ProfileRow(Icons.Default.Notifications, "Системные настройки уведомлений", "Разрешение, каналы, звук") {
                            runCatching { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)) }
                        }
                        ProfileRow(Icons.Default.Settings, "Работа в фоне", "Выбери «Не ограничивать» для PALKA") {
                            runCatching { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                        }
                    }
                    Text("Сообщения приходят, пока приложение закрыто, через фоновое соединение (в шторке висит тихое уведомление «Ожидаем новые сообщения»). Если на телефоне включена жёсткая экономия батареи, отключи её для PALKA.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(20.dp))
                }
                "Язык" -> Column(Modifier.fillMaxSize()) {
                    SubHeader("Язык") { goBack() }
                    listOf("Русский", "Українська", "English").forEach { choice ->
                        ProfileRow(Icons.Default.Language, choice, if (appLanguage == choice) "✓ Выбрана" else "Нажми, чтобы выбрать") { appLanguage = choice; settingsPrefs.edit().putString("language", choice).apply() }
                    }
                }
                else -> {}
            }
        }
        val baseTab = when (tab) { "Чаты", "Контакты", "Заметки" -> "Чаты"; "Звонки" -> "Звонки"; else -> "Профиль" }
        NavigationBar(containerColor = Panel, contentColor = Cream) {
            listOf(Triple("Чаты", Icons.Default.ChatBubble, "Чаты"), Triple("Звонки", Icons.Default.Phone, "Звонки"), Triple("Профиль", Icons.Default.Person, "Профиль")).forEach { (label, icon, target) ->
                NavigationBarItem(selected = baseTab == target, onClick = { query = ""; tab = target }, icon = { Icon(icon, contentDescription = label) }, label = { Text(tr(appLanguage, label), fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Color.Transparent, unselectedIconColor = Cream.copy(alpha = .7f), unselectedTextColor = Cream.copy(alpha = .7f)))
            }
        }
    }
    if (editProfile) AlertDialog(
        onDismissRequest = { editProfile = false }, containerColor = Panel,
        title = { Text("Твой профиль", color = Cream) },
        text = { Column { PalkaField(editName, { editName = it.take(40) }, "Имя"); Spacer(Modifier.height(10.dp)); PalkaField(editNick, { editNick = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, "@username (3–20 символов)"); Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Avatar(editNick, selectedPhoto?.toString() ?: me.avatarUrl); Spacer(Modifier.width(12.dp)); Button(onClick = { photoPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Icon(Icons.Default.CameraAlt, null, tint = Night); Spacer(Modifier.width(6.dp)); Text("Выбрать из галереи", color = Night) } } } },
        confirmButton = { TextButton(onClick = { onSaveProfile(editName.trim(), editNick.lowercase(), selectedPhoto); editProfile = false }) { Text("Сохранить", color = Green) } },
        dismissButton = { TextButton(onClick = { editProfile = false }) { Text("Отмена", color = Cream) } }
    )
}

@Composable private fun EmptyState(emoji: String, title: String, subtitle: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 48.sp)
            Text(title, color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            Text(subtitle, color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable private fun SubHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = Cream) }
        Text(title, color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun PalkaSearch(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Panel).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = Color.Gray)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = Color.Gray, fontSize = 16.sp)
            BasicTextField(value, onChange, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Cream, fontSize = 16.sp), cursorBrush = SolidColor(Green), modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable private fun StatItem(value: String, label: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Green.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Cream, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
    }
}

@Composable private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Cream, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Green, uncheckedThumbColor = Color.LightGray, uncheckedTrackColor = Color(0xFF3A423C)))
    }
}

@Composable private fun ChatListRow(s: ChatSummary, myId: String, showUnread: Boolean, onClick: () -> Unit) {
    val online = isOnline(s.peer.lastSeen)
    val last = s.last
    val mine = last != null && last.senderId == myId
    val preview = when {
        last == null -> "Нет сообщений"
        last.mediaType == "video" -> "🎥 Видео"
        last.mediaType == "image" -> "📷 Фотография"
        else -> last.body
    }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box {
            Avatar(s.peer.username, s.peer.avatarUrl, 54.dp)
            if (online) Box(Modifier.align(Alignment.BottomEnd).size(16.dp).clip(CircleShape).background(Night).padding(2.5.dp).clip(CircleShape).background(Green))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.peer.displayName.ifBlank { s.peer.username }, color = Cream, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(preview, color = Color.Gray, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (mine && last != null) {
                    val read = last.readAt != null
                    Icon(if (read) Icons.Default.DoneAll else Icons.Default.Done, null, tint = if (read) Green else Color.Gray, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(formatListTime(last?.createdAt), color = Color.Gray, fontSize = 12.sp)
            }
            if (showUnread && s.unread > 0) Box(Modifier.padding(top = 6.dp).defaultMinSize(minWidth = 22.dp, minHeight = 22.dp).clip(CircleShape).background(Green).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
                Text(if (s.unread >= 99) "99+" else s.unread.toString(), color = Night, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun NotesRow(notes: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0xFFE0A030)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Bookmark, null, tint = Color(0xFF2A1A05), modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Заметки ✏️", color = Cream, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(notes.lineSequence().firstOrNull { it.isNotBlank() } ?: "Мои заметки", color = Color.Gray, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable private fun UserRow(person: Profile, showWrite: Boolean = true, onClick: () -> Unit) {
    val online = remember(person.lastSeen) { isOnline(person.lastSeen) }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Panel).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(person.username, person.avatarUrl); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("@${person.username}", fontWeight = FontWeight.Bold, color = Cream); if (online) Row(verticalAlignment = Alignment.CenterVertically) { Text("🪵", fontSize = 12.sp); Text("Палка тут", color = Green, fontSize = 12.sp) } else Text("Не в сети", color = Color.Gray, fontSize = 12.sp) }
        if (showWrite) Text("Написать  ›", color = Green, fontSize = 13.sp)
    }
}

@Composable private fun MenuItemRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, color = tint, fontSize = 15.sp)
    }
}

/** Reactions pill + action card, shown for both tap and long-press on a message. */
@Composable private fun MessageMenu(
    mine: Boolean, pinned: Boolean, canEdit: Boolean, canServerActions: Boolean,
    onDismiss: () -> Unit, onReact: (String) -> Unit, onReply: () -> Unit, onCopy: () -> Unit,
    onForward: () -> Unit, onPin: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit
) {
    var moreEmoji by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss).padding(20.dp), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                if (canServerActions) {
                    Row(Modifier.clip(RoundedCornerShape(30.dp)).background(Panel).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("❤️", "😂", "🪵", "👍").forEach { e -> Text(e, fontSize = 26.sp, modifier = Modifier.clip(CircleShape).clickable { onReact(e) }.padding(8.dp)) }
                        Box(Modifier.padding(horizontal = 4.dp).size(34.dp).clip(CircleShape).background(Cream.copy(alpha = .12f)).clickable { moreEmoji = !moreEmoji }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Add, "Ещё", tint = Cream, modifier = Modifier.size(20.dp)) }
                    }
                    if (moreEmoji) Row(Modifier.padding(top = 8.dp).clip(RoundedCornerShape(24.dp)).background(Panel).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        listOf("🔥", "🎉", "😮", "😢", "🙏", "💚").forEach { e -> Text(e, fontSize = 24.sp, modifier = Modifier.clip(CircleShape).clickable { onReact(e) }.padding(7.dp)) }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Column(Modifier.width(240.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(vertical = 6.dp)) {
                    MenuItemRow(Icons.Default.Reply, "Ответить", Cream, onReply)
                    MenuItemRow(Icons.Default.ContentCopy, "Копировать", Cream, onCopy)
                    if (canServerActions) MenuItemRow(Icons.Default.Forward, "Переслать", Cream, onForward)
                    if (canServerActions) MenuItemRow(Icons.Default.PushPin, if (pinned) "Открепить" else "Закрепить", Cream, onPin)
                    if (canEdit) MenuItemRow(Icons.Default.Edit, "Изменить", Cream, onEdit)
                    if (mine) MenuItemRow(Icons.Default.Delete, "Удалить", Color(0xFFFF5A5A), onDelete)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun ChatScreen(friend: Profile, conversationId: String, onBack: () -> Unit) {
    var messages by remember(conversationId) { mutableStateOf(Backend.cachedMessages(conversationId)) }
    var reactionsByMessage by remember { mutableStateOf<Map<String, List<Reaction>>>(emptyMap()) }
    var pinnedMessageId by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var chatError by remember { mutableStateOf("") }
    var peerTyping by remember { mutableStateOf(false) }
    var showEmoji by remember { mutableStateOf(false) }
    var rtConnected by remember { mutableStateOf(false) }
    var typingUntil by remember { mutableLongStateOf(0L) }
    var lastTypingSent by remember { mutableLongStateOf(0L) }
    var reply by remember { mutableStateOf<ChatMessage?>(null) }
    var editTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var menuMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var selectedMessage by remember { mutableStateOf<ChatMessage?>(null) }
    val context = LocalContext.current
    val wallpaperPrefs = remember(conversationId) { context.getSharedPreferences("palka_wallpaper_$conversationId", android.content.Context.MODE_PRIVATE) }
    var wallpaper by remember(conversationId) { mutableIntStateOf(wallpaperPrefs.getInt("wallpaper", context.getSharedPreferences("palka_wallpaper_default", android.content.Context.MODE_PRIVATE).getInt("wallpaper", 0))) }
    val scope = rememberCoroutineScope()
    DisposableEffect(conversationId) {
        NotificationHelper.openConversationId = conversationId
        NotificationHelper.cancelConversation(context, conversationId)
        onDispose { if (NotificationHelper.openConversationId == conversationId) NotificationHelper.openConversationId = null }
    }
    var typingJob by remember { mutableStateOf<Job?>(null) }
    val doReact: (ChatMessage, String) -> Unit = { target, emoji ->
        scope.launch {
            runCatching {
                val targetId = target.id ?: error("Нет ID")
                Backend.react(targetId, emoji)
                reactionsByMessage = reactionsByMessage + (targetId to Backend.messageReactions(targetId))
            }.onFailure { chatError = it.message ?: "Не удалось поставить реакцию" }
        }
    }
    var typingRemoteActive by remember(conversationId) { mutableStateOf(false) }
    val uid = Backend.userId
    val listState = rememberLazyListState()
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            sending = true
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Не удалось прочитать файл")
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val video = mime.startsWith("video/")
                val isGif = mime.equals("image/gif", true)
                val bytes = if (!video && !isGif) compressChatImage(raw) else raw
                val name = if (video) "video.mp4" else if (isGif) "image.gif" else "image.jpg"
                val url = Backend.uploadChatMedia(bytes, name)
                val sent = Backend.sendRichMessage(conversationId, if (video) "🎥 Видео" else "📷 Фото", reply?.id, url, if (video) "video" else "image")
                messages = (messages + sent).distinctBy { it.id }.takeLast(200)
                reply = null
            }.onFailure { chatError = it.message ?: "Не удалось отправить файл" }
            sending = false
        }
    }
    LaunchedEffect(conversationId) {
        var refreshRunning = false
        var refreshPending = false
        var extrasLoaded = false
        var markReadRunning = false
        var markReadPending = false
        val reactionLoadsInFlight = mutableSetOf<String>()

        // Coalesce read acknowledgements without losing a new incoming message
        // that arrives while the previous UPDATE request is still in flight.
        fun requestMarkRead() {
            markReadPending = true
            if (markReadRunning) return
            markReadRunning = true
            launch {
                try {
                    while (markReadPending && isActive) {
                        markReadPending = false
                        launch { Backend.sendRead(conversationId) } // instant ticks for the sender
                        runCatching { Backend.markRead(conversationId) }
                    }
                } finally {
                    markReadRunning = false
                    // Close the tiny race where a request was queued as the loop ended.
                    if (markReadPending && isActive) requestMarkRead()
                }
            }
        }

        suspend fun refreshMessages(fromRealtime: Boolean = false) {
            if (refreshRunning) {
                refreshPending = true
                return
            }
            refreshRunning = true
            try {
                val before = messages
                val previousIds = before.mapNotNull { it.id }.toSet()
                val loaded = Backend.messages(conversationId)
                // Keep optimistic local messages while a slow insert request is still in flight.
                val pendingLocal = before.filter { local ->
                    local.id?.startsWith("local-") == true && loaded.none { server ->
                        server.senderId == local.senderId && server.body == local.body &&
                            server.replyTo == local.replyTo
                    }
                }
                val nowMs = System.currentTimeMillis()
                val recentLive = before.filter { m ->
                    val id = m.id
                    id != null && !id.startsWith("local-") && loaded.none { it.id == id } &&
                        runCatching { nowMs - parseInstant(m.createdAt ?: "").toEpochMilli() < 20_000 }.getOrDefault(false)
                }
                messages = (loaded + pendingLocal + recentLive).distinctBy { it.id }.sortedBy { it.createdAt.orEmpty() }.takeLast(200)

                // Start read-receipt writes immediately. Previously reaction lookups
                // ran sequentially before this block, delaying the recipient's read
                // acknowledgement when several messages arrived together.
                val hasUnreadIncoming = loaded.any { it.senderId != uid && it.readAt == null }
                if (hasUnreadIncoming) requestMarkRead()

                // Reaction lookups are secondary UI data. Fetch them in the background
                // so they never hold up message refreshes or read receipts.
                val newIds = loaded.mapNotNull { it.id }
                    .filter { it !in previousIds && it !in reactionsByMessage && it !in reactionLoadsInFlight }
                    .takeLast(40)
                if (newIds.isNotEmpty()) {
                    reactionLoadsInFlight.addAll(newIds)
                    launch {
                        try {
                            val additions = buildMap<String, List<Reaction>> {
                                newIds.forEach { id -> put(id, runCatching { Backend.messageReactions(id) }.getOrDefault(emptyList())) }
                            }
                            reactionsByMessage = reactionsByMessage + additions
                        } finally {
                            reactionLoadsInFlight.removeAll(newIds.toSet())
                        }
                    }
                }

                if (!extrasLoaded) {
                    extrasLoaded = true
                    launch { runCatching { pinnedMessageId = Backend.pinnedMessageId(conversationId) } }
                }
                chatError = ""
            } catch (t: Throwable) {
                chatError = t.message ?: "Не удалось обновить чат"
            } finally {
                loading = false
                refreshRunning = false
                if (refreshPending) {
                    refreshPending = false
                    launch { refreshMessages(fromRealtime = true) }
                }
            }
        }

        coroutineScope {
            // Establish Realtime first so messages arriving during the initial history
            // request are not missed. If the network is unavailable, do not block the UI.
            val realtimeReady = CompletableDeferred<Unit>()
            // Keep the Realtime subscription alive and reconnect with backoff if it exits.
            launch {
                var retryDelay = 1000L
                while (isActive) {
                    val result = runCatching {
                        Backend.watchMessages(
                            conversationId = conversationId,
                            onSubscribed = { rtConnected = true; realtimeReady.complete(Unit) },
                            onPeerRead = {
                                val readAt = java.time.Instant.now().toString()
                                messages = messages.map { if (it.senderId == uid && it.readAt == null) it.copy(readAt = readAt) else it }
                            },
                            onPeerTyping = { typingUntil = System.currentTimeMillis() + 4000; peerTyping = true }
                        ) { changed, inserted ->
                            val changedId = changed.id
                            if (changedId != null) {
                                val index = messages.indexOfFirst { it.id == changedId }
                                if (index >= 0) {
                                    val updated = messages.toMutableList()
                                    updated[index] = changed
                                    messages = updated
                                } else if (inserted) {
                                    // Reconcile the instant local bubble with the authoritative
                                    // Realtime row. Match only this user's pending text/reply.
                                    val pendingIndex = if (changed.senderId == uid) messages.indexOfLast {
                                        it.id?.startsWith("local-") == true &&
                                            it.senderId == changed.senderId && it.body == changed.body &&
                                            it.replyTo == changed.replyTo
                                    } else -1
                                    messages = if (pendingIndex >= 0) {
                                        messages.toMutableList().also { it[pendingIndex] = changed }
                                            .distinctBy { it.id }.sortedBy { it.createdAt.orEmpty() }.takeLast(200)
                                    } else {
                                        (messages + changed).distinctBy { it.id }
                                            .sortedBy { it.createdAt.orEmpty() }.takeLast(200)
                                    }
                                }

                                if (inserted && changed.senderId != uid) peerTyping = false
                                if (inserted && changed.senderId != uid && changed.readAt == null) {
                                    requestMarkRead()
                                }

                                if (inserted && changedId !in reactionsByMessage && changedId !in reactionLoadsInFlight) {
                                    reactionLoadsInFlight.add(changedId)
                                    launch {
                                        try {
                                            val found = runCatching { Backend.messageReactions(changedId) }.getOrDefault(emptyList())
                                            reactionsByMessage = reactionsByMessage + (changedId to found)
                                        } finally { reactionLoadsInFlight.remove(changedId) }
                                    }
                                }
                            }
                        }
                    }
                    rtConnected = false
                    if (isActive) {
                        result.exceptionOrNull()?.let { chatError = it.message ?: "Переподключение к чату..." }
                        delay(retryDelay)
                        retryDelay = (retryDelay * 2).coerceAtMost(15000L)
                    }
                }
            }
            // Start history loading once the subscription is active, or after a short
            // timeout so offline users still see cached/server history and reconnect later.
            withTimeoutOrNull(1500) { realtimeReady.await() }
            refreshMessages()

            // Lightweight safety refresh if Realtime is temporarily disconnected.
            launch {
                while (isActive) { delay(5000); refreshMessages() }
            }
            // Typing is not a messages-table event, so refresh it separately.
            launch {
                while (isActive) {
                    delay(1000)
                    if (peerTyping && System.currentTimeMillis() > typingUntil) peerTyping = false
                }
            }
        }
    }
    DisposableEffect(conversationId) {
        onDispose {
            typingJob?.cancel()
            if (typingRemoteActive) {
                scope.launch { runCatching { Backend.setTyping(conversationId, false) } }
            }
        }
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    val wallpapers = listOf(R.drawable.palka_forest_wallpaper_1, R.drawable.palka_forest_wallpaper_2, R.drawable.palka_forest_wallpaper_3, R.drawable.palka_forest_wallpaper_4)
    Column(Modifier.fillMaxSize().imePadding().background(Night).paint(painterResource(wallpapers[wallpaper % wallpapers.size]), contentScale = ContentScale.Crop)) {
        Row(Modifier.fillMaxWidth().background(Panel.copy(alpha = .92f)).padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Cream) }
            Avatar(friend.username, friend.avatarUrl, 42.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(friend.displayName.ifBlank { "@${friend.username}" }, color = Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val peerOnline = isOnline(friend.lastSeen)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (rtConnected) Green else Color(0xFFFFA040)))
                    Spacer(Modifier.width(6.dp))
                    Text(if (peerTyping) "печатает…" else if (peerOnline) "в сети" else "не в сети", color = if (peerTyping || peerOnline) Green else Color.Gray, fontSize = 12.sp)
                }
            }
            IconButton(onClick = { android.widget.Toast.makeText(context, "Звонки появятся в одном из следующих обновлений", android.widget.Toast.LENGTH_SHORT).show() }) { Icon(Icons.Default.Phone, "Звонок", tint = Green) }
            var menu by remember { mutableStateOf(false) }
            Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null, tint = Cream) }; DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Следующие обои") }, onClick = { wallpaper = (wallpaper + 1) % wallpapers.size; wallpaperPrefs.edit().putInt("wallpaper", wallpaper).apply(); menu = false })
                DropdownMenuItem(text = { Text("Заблокировать") }, onClick = { menu = false; scope.launch { runCatching { Backend.blockUser(friend.id); onBack() }.onFailure { chatError = it.message ?: "Ошибка блокировки" } } })
            } }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        if (chatError.isNotBlank()) Text(if (chatError.contains("JWT expired", true) || chatError.contains("Unable to resolve host", true) || chatError.contains("No address associated with hostname", true) || chatError.contains("UnknownHostException", true)) "Нет связи с сервером. Повторяем подключение…" else chatError, color = Color(0xFFFF9B86), modifier = Modifier.fillMaxWidth().background(Panel).padding(8.dp), fontSize = 12.sp)
        val pinnedMessage = messages.firstOrNull { it.id == pinnedMessageId }
        if (pinnedMessage != null) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF203A2A)).clickable {
                val index = messages.indexOfFirst { it.id == pinnedMessageId }
                if (index >= 0) scope.launch { listState.animateScrollToItem(index) }
            }.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PushPin, null, tint = Green, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("Закреплённое сообщение", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(pinnedMessage.body.ifBlank { if (pinnedMessage.mediaType == "video") "🎥 Видео" else "📷 Фото" }.take(75), color = Cream, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                TextButton(onClick = { scope.launch { runCatching { Backend.unpinMessage(conversationId, pinnedMessage.id!!); pinnedMessageId = null; chatError = "Сообщение откреплено" }.onFailure { chatError = it.message ?: "Не удалось открепить" } } }) { Text("Открепить", color = Green, fontSize = 11.sp) }
            }
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(messages, key = { it.id ?: it.hashCode().toString() }) { msg ->
                val mine = msg.senderId == uid
                val repliedMessage = messages.firstOrNull { it.id == msg.replyTo }
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
                    if (!mine) { Avatar(friend.username, friend.avatarUrl, 32.dp); Spacer(Modifier.width(6.dp)) }
                    Column(Modifier.widthIn(max = 290.dp)
                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (mine) 18.dp else 5.dp, bottomEnd = if (mine) 5.dp else 18.dp))
                        .background(if (mine) MineBubble else OtherBubble)
                        .combinedClickable(onClick = { menuMessage = msg }, onLongClick = { menuMessage = msg })
                        .padding(horizontal = 12.dp, vertical = 8.dp)) {
                        if (msg.replyTo != null) {
                            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = .22f))) {
                                Box(Modifier.width(3.dp).fillMaxHeight().background(Green))
                                Column(Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                                    Text(if (repliedMessage == null) "Ответ" else if (repliedMessage.senderId == uid) "Вы" else friend.displayName.ifBlank { friend.username }, color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(repliedMessage?.body?.ifBlank { if (repliedMessage?.mediaType == "video") "🎥 Видео" else "📷 Фото" }?.take(100) ?: "Сообщение недоступно", color = Cream, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Spacer(Modifier.height(5.dp))
                        }
                        if (!msg.body.isBlank()) Text(msg.body, color = Cream, fontSize = 16.sp)
                        if (!msg.mediaUrl.isNullOrBlank()) { if (msg.mediaType == "image") AsyncImage(model = msg.mediaUrl, contentDescription = "Открыть фото", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(12.dp)).clickable { selectedMessage = msg }) else if (msg.mediaType == "video") {
                            AndroidView(factory = { viewContext -> VideoView(viewContext).apply {
                                setMediaController(MediaController(viewContext).also { it.setAnchorView(this) })
                                setVideoURI(Uri.parse(msg.mediaUrl)); setOnPreparedListener { it.isLooping = false; start() }
                            } }, modifier = Modifier.fillMaxWidth().height(210.dp))
                        } }
                        Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                            if (msg.editedAt != null) Text("изменено · ", color = Cream.copy(alpha = .6f), fontSize = 10.sp)
                            Text(formatBubbleTime(msg.createdAt), color = Cream.copy(alpha = .6f), fontSize = 11.sp)
                            if (mine) {
                                val read = msg.readAt != null
                                Spacer(Modifier.width(4.dp))
                                Icon(if (read) Icons.Default.DoneAll else Icons.Default.Done, if (read) "Прочитано" else "Отправлено", tint = if (read) Green else Cream.copy(alpha = .6f), modifier = Modifier.size(16.dp))
                            }
                        }
                        val messageReactions = msg.id?.let { reactionsByMessage[it] }.orEmpty().groupingBy { it.emoji }.eachCount()
                        if (messageReactions.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 5.dp)) {
                                messageReactions.forEach { (emoji, count) ->
                                    Text("$emoji $count", color = Cream, fontSize = 12.sp,
                                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .25f)).clickable { doReact(msg, emoji) }.padding(horizontal = 7.dp, vertical = 3.dp))
                                }
                            }
                        }
                    }
                }
            }
            if (peerTyping) item(key = "typing-indicator") {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Bottom) {
                    Avatar(friend.username, friend.avatarUrl, 32.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("${friend.displayName.ifBlank { friend.username }} печатает…", color = Cream, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 5.dp, bottomEnd = 18.dp)).background(OtherBubble).padding(horizontal = 14.dp, vertical = 10.dp))
                }
            }
        }
        selectedMessage?.let { photo ->
            Dialog(onDismissRequest = { selectedMessage = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                Box(Modifier.fillMaxSize().background(Color.Black).clickable { selectedMessage = null }, contentAlignment = Alignment.Center) {
                    AsyncImage(model = photo.mediaUrl, contentDescription = "Фото", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().fillMaxHeight(.92f))
                    Text("Нажмите, чтобы закрыть", color = Color.White.copy(alpha = .8f), modifier = Modifier.align(Alignment.BottomCenter).padding(18.dp), fontSize = 12.sp)
                }
            }
        }
        menuMessage?.let { target ->
            val isMine = target.senderId == uid
            val isLocal = target.id?.startsWith("local-") == true
            MessageMenu(
                mine = isMine,
                pinned = pinnedMessageId == target.id,
                canEdit = isMine && !isLocal && target.mediaUrl.isNullOrBlank(),
                canServerActions = !isLocal,
                onDismiss = { menuMessage = null },
                onReact = { emoji -> menuMessage = null; doReact(target, emoji) },
                onReply = { reply = target; editTarget = null; menuMessage = null },
                onCopy = {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("PALKA", target.body))
                    menuMessage = null
                },
                onForward = {
                    menuMessage = null
                    scope.launch { runCatching { Backend.sendRichMessage(conversationId, target.body, null, target.mediaUrl, target.mediaType); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Не удалось переслать" } }
                },
                onPin = {
                    menuMessage = null
                    scope.launch { runCatching { if (pinnedMessageId == target.id) { Backend.unpinMessage(conversationId, target.id ?: error("Нет ID")); pinnedMessageId = null; chatError = "Сообщение откреплено" } else { Backend.pinMessage(conversationId, target.id ?: error("Нет ID")); pinnedMessageId = target.id; chatError = "Сообщение закреплено" } }.onFailure { chatError = it.message ?: "Не удалось изменить закрепление" } }
                },
                onEdit = { editTarget = target; reply = null; text = target.body; menuMessage = null },
                onDelete = {
                    menuMessage = null
                    if (isLocal) messages = messages.filterNot { it.id == target.id }
                    else scope.launch { runCatching { Backend.deleteMessage(target.id ?: return@launch); messages = Backend.messages(conversationId) }.onFailure { chatError = it.message ?: "Ошибка удаления" } }
                }
            )
        }
        if (reply != null) Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { Text("Ответ: ${reply!!.body.take(50)}", color = Green, modifier = Modifier.weight(1f), fontSize = 12.sp); TextButton(onClick = { reply = null }) { Text("Отмена") } }
        if (showEmoji) Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("😀", "😂", "😍", "😎", "🙏", "🔥", "👍", "🪵").forEach { e -> Text(e, fontSize = 24.sp, modifier = Modifier.clip(CircleShape).clickable { text += e }.padding(5.dp)) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
          Row(Modifier.weight(1f).clip(RoundedCornerShape(28.dp)).background(Panel), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { showEmoji = !showEmoji }) { Icon(Icons.Default.EmojiEmotions, "Эмодзи", tint = Color.Gray) }
            OutlinedTextField(text, { value ->
                text = value
                chatError = ""
                // Typing goes over Broadcast (no database writes), at most once per 2.5 s.
                if (value.isNotBlank()) {
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastTypingSent > 2500) {
                        lastTypingSent = nowMs
                        scope.launch { Backend.sendTyping(conversationId) }
                    }
                }
            }, modifier = Modifier.weight(1f), placeholder = { Text(if (editTarget != null) "Изменить сообщение..." else "Сообщение...") }, shape = RoundedCornerShape(18.dp), colors = fieldColorsFlat(), maxLines = 4, keyboardOptions = KeyboardOptions.Default.copy(imeAction = androidx.compose.ui.text.input.ImeAction.Send))
            IconButton(onClick = { mediaPicker.launch(arrayOf("image/*", "video/*")) }) { Icon(Icons.Default.AttachFile, "Фото или видео", tint = Color.Gray) }
          }
          Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                val body = text.trim()
                if (body.isNotEmpty()) {
                    val editing = editTarget
                    if (editing?.id != null) {
                        if (!sending) scope.launch {
                            sending = true
                            chatError = ""
                            runCatching {
                                Backend.editMessage(editing.id!!, body)
                                messages = Backend.messages(conversationId)
                                text = ""
                                editTarget = null
                            }.onFailure { chatError = it.message ?: "Не удалось изменить сообщение" }
                            sending = false
                        }
                    } else {
                        // Render locally and clear the composer before any network request.
                        // Each send gets its own job, so a slow request cannot block the next one.
                        val replyId = reply?.id
                        val messageId = java.util.UUID.randomUUID().toString()
                        val localId = "local-$messageId"
                        val optimistic = ChatMessage(
                            id = localId,
                            conversationId = conversationId,
                            senderId = uid.orEmpty(),
                            body = body,
                            createdAt = java.time.Instant.now().toString(),
                            replyTo = replyId
                        )
                        messages = (messages + optimistic).takeLast(200)
                        text = ""
                        reply = null
                        chatError = ""
                        scope.launch {
                            // Fast path: tell the peer immediately over the open socket, while the
                            // durable INSERT runs in parallel. Both carry the same message id.
                            launch { Backend.broadcastMessage(ChatMessage(id = messageId, conversationId = conversationId, senderId = uid.orEmpty(), body = body, createdAt = optimistic.createdAt, replyTo = replyId)) }
                            runCatching {
                                Backend.sendMessageFast(conversationId, body, replyId, messageId)
                                // Keep the local bubble until its matching Realtime INSERT
                                // arrives; no extra SELECT round-trip is needed after sending.
                            }.onFailure { error ->
                                messages = messages.filterNot { it.id == localId }
                                chatError = error.message ?: "Не удалось отправить сообщение"
                            }
                        }
                    }
                }
            }, modifier = Modifier.size(50.dp).clip(CircleShape).background(if (text.isNotBlank()) Green else Panel), enabled = text.isNotBlank() && (editTarget == null || !sending)) {
                if (editTarget != null && sending) CircularProgressIndicator(Modifier.size(22.dp), color = Green, strokeWidth = 2.dp)
                else Icon(Icons.Default.Send, null, tint = if (text.isNotBlank()) Night else Color.Gray)
            }
        }
    }
}
private fun compressChatImage(bytes: ByteArray): ByteArray {
    return runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1920 || bounds.outHeight / sample > 1920) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return bytes
        ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            bitmap.recycle()
            out.toByteArray()
        }
    }.getOrDefault(bytes)
}

@Composable private fun Logo() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("🪵", fontSize = 54.sp); Text("PALKA", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Green, letterSpacing = 3.sp)
        Text("деревянный чат для своих", color = Wood, fontSize = 13.sp)
    }
}
@Composable private fun Avatar(nick: String, url: String? = null, size: androidx.compose.ui.unit.Dp = 46.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Color(0xFF59412C)), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) AsyncImage(model = url, contentDescription = "Аватар $nick", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Text(nick.take(1).uppercase(), color = Cream, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
    }
}
@Composable private fun PalkaField(value: String, onChange: (String) -> Unit, hint: String, keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false) {
    OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(keyboardType = keyboard), visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, colors = fieldColors())
}
@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF52624F), focusedTextColor = Cream, unfocusedTextColor = Cream, focusedPlaceholderColor = Color.Gray, unfocusedPlaceholderColor = Color.Gray, cursorColor = Green)
@Composable private fun fieldColorsFlat() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent, focusedTextColor = Cream, unfocusedTextColor = Cream, focusedPlaceholderColor = Color.Gray, unfocusedPlaceholderColor = Color.Gray, cursorColor = Green)
