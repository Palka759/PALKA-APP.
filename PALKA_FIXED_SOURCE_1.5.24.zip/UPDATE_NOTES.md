# PALKA 1.5.15

- Reduced Supabase typing writes: one start update per typing burst instead of one write per keystroke.
- Kept optimistic local message rendering and the existing PostgREST message insert path unchanged.
- Left read receipts and media upload behavior unchanged.
- Updated Android version to 1.5.15 and CI archive selection.

Build status: source-level checks only; Android Gradle build must be verified by GitHub Actions.


## 1.5.17
- Corrected the workflow to prefer the exact 1.5.17 source archive, even when an older Android project exists at the repository root.
- Updated the Android version metadata to 1.5.17 (versionCode 17).
- Added server-side Realtime filters for the active conversation's INSERT and UPDATE events.
- Wait for the Realtime subscription before loading initial chat history (with an 8-second fallback when the network is unavailable).

## 1.5.19
- Realtime channel is now unsubscribed/removed when the chat is left or the subscription restarts (it previously leaked forever).
- Each subscription uses a unique channel topic, so re-entering a chat cannot hit a stale channel.
- Realtime rows are decoded with ignoreUnknownKeys, so an unmodelled column can no longer silently drop message events.
- Verified: 1.5.18 source has no `.content` usage; "Unresolved reference: content" came from an older source, not this archive.
Build status: NOT compiled (no Android SDK/network in the review environment).

## 1.5.20
- Fix compile error: PostgresChangeFilter.filter is private in supabase-kt 3.2.3; use filter(column, FilterOperator.EQ, value).
Build status: NOT compiled locally.

## 1.5.21
- New UI following the design mockups: chat list (search, All/Personal/Groups tabs, last message, time, ticks, unread badge, online dot), bottom navigation (Chats / Calls / Profile), chat screen (bubbles, avatars, ticks, typing bubble, reactions + action menu on tap and long-press, pin banner, emoji bar, attach button, round send button), profile, appearance (wallpapers + themes + Apply), notifications settings.
- Groups and calls are placeholders ("coming soon"): there is no backend for them yet.
- Timestamps are parsed with OffsetDateTime first (PostgREST returns "+00:00"), which fixes blank message times / online / typing on runtimes where Instant.parse rejects offsets.
- supabase/update_v8.sql lets the "+" button in the reaction bar use any emoji. Run it once in the Supabase SQL editor.
- System push notifications are still not implemented; the toggles are stored for later.
Build status: NOT compiled locally.

## 1.5.22
- Messenger-style delivery: the sender broadcasts the message over the open Realtime socket (Broadcast) while the INSERT runs in parallel. Message id is generated on the phone, so both copies are deduplicated.
- Read receipts and typing indicator also go over Broadcast (typing no longer writes to the database).
- Realtime status dot in the chat header: green = subscribed, orange = not connected (messages then arrive via the 5 s fallback refresh instead of 15 s).
- Chat history no longer waits up to 8 s for the Realtime subscription (1.5 s).
- Note: Broadcast topics are public to anyone who knows the (random UUID) channel name; the database copy remains protected by RLS.
Build status: NOT compiled locally.

## 1.5.23
- System notifications with sound for new messages, also when the app is closed (no Firebase needed): a foreground service (`MessageService`) keeps one Realtime subscription to all incoming messages; unread messages from the last 30 min are shown silently after a reconnect.
- Sounds: `palka_forest` (Лесной звонок), `palka_knock` (Стук палки), «Тихий». One notification channel per sound/vibration combination. The sound is previewed when you switch it in Settings.
- No notification for the chat that is currently open; notifications of a chat are cleared when it is opened. Tap on a notification opens that chat.
- Settings: notifications toggle starts/stops the service; shortcuts to system notification settings and battery optimisation.
- Restarts after reboot/update (BootReceiver). Stops on sign-out.
- Workflow now picks the newest PALKA_FIXED_SOURCE_<version>.zip and checks its version against build.gradle.kts.
Build status: NOT compiled locally (no Android SDK/network here); verify with GitHub Actions.

## 1.5.24
- Groups and channels. Create via the green "+" button (New chat / New group / New channel). Members are picked from people you already chat with; the owner can add more later via the chat header (members dialog).
- Group: everyone writes. Channel: only the owner writes, subscribers can only react (input is replaced by a banner; reply/forward/pin hidden for them).
- Groups show sender names and avatars in bubbles; unread counters use a per-member read marker (conversation_members.last_read_at). Direct chats are unchanged (read_at ticks).
- Notifications show the group title and "sender: text".
- Chat-list filter "Личные" now shows direct chats only, "Группы" shows groups and channels.
- REQUIRED: run supabase/update_v9.sql once in the Supabase SQL Editor. Without it the app works as before, but creating groups fails.
- Calls: not part of this release.
Build status: NOT compiled locally.
