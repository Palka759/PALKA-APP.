package com.palka.app

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.query.filter.FilterOperator
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.RealtimeChannel
import io.github.jan.supabase.realtime.broadcastFlow
import kotlinx.serialization.json.JsonObject
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.channel
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.put
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import io.github.jan.supabase.realtime.realtime
import kotlin.time.Duration.Companion.days

@Serializable data class Profile(
    val id: String,
    val username: String,
    @SerialName("display_name") val displayName: String = "",
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("last_seen") val lastSeen: String? = null
)
@Serializable data class ChatMessage(
    val id: String? = null,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("reply_to") val replyTo: String? = null,
    @SerialName("media_url") val mediaUrl: String? = null,
    @SerialName("media_type") val mediaType: String? = null,
    @SerialName("edited_at") val editedAt: String? = null,
    @SerialName("read_at") val readAt: String? = null
)
@Serializable data class Conversation(
    val id: String,
    @SerialName("member_one") val memberOne: String? = null,
    @SerialName("member_two") val memberTwo: String? = null,
    val kind: String = "direct",
    val title: String = "",
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("owner_id") val ownerId: String? = null
)
@Serializable data class MemberRow(
    @SerialName("conversation_id") val conversationId: String = "",
    @SerialName("user_id") val userId: String,
    val role: String = "member",
    @SerialName("last_read_at") val lastReadAt: String? = null
)
/** A group/channel member with profile. */
data class GroupMember(val profile: Profile, val role: String)
/** One row of the chat list: partner, newest message and unread incoming count. */
data class ChatSummary(
    val peer: Profile, val conversationId: String, val last: ChatMessage?, val unread: Int,
    /** "direct", "group" or "channel". For groups/channels [peer] is a synthetic profile carrying the title. */
    val kind: String = "direct", val ownerId: String? = null, val memberCount: Int = 0
)

/** PostgREST returns timestamptz as "...+00:00"; older Android runtimes reject that in Instant.parse. */
fun parseInstant(value: String): java.time.Instant =
    try { java.time.OffsetDateTime.parse(value).toInstant() } catch (_: Exception) { java.time.Instant.parse(value) }

@Serializable data class TypingRow(@SerialName("updated_at") val updatedAt: String)

@Serializable data class BlockRow(@SerialName("blocked_id") val blockedId: String)
@Serializable data class PinnedRow(@SerialName("message_id") val messageId: String)
@Serializable data class PrivateNote(val id: String, @SerialName("user_id") val userId: String, val body: String = "")

@Serializable data class Reaction(
    val id: String? = null,
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    val emoji: String
)

object Backend {
    // Realtime rows may carry columns this client does not model; never drop a
    // message event because of an unknown key.
    private val rtJson = Json { ignoreUnknownKeys = true; isLenient = true }
    private val messageCache = java.util.concurrent.ConcurrentHashMap<String, List<ChatMessage>>()
    fun cachedMessages(conversationId: String): List<ChatMessage> = messageCache[conversationId].orEmpty()
    private val configured get() = BuildConfig.SUPABASE_URL.startsWith("https://") && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()
    val client = if (configured) createSupabaseClient(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY) {
        install(Auth) {
            // Keep the local session and refresh expired access tokens automatically.
            autoLoadFromStorage = true
            autoSaveToStorage = true
            alwaysAutoRefresh = true
        }
        install(Postgrest)
        install(Realtime)
        install(Storage)
    } else null

    /** Retry idempotent reads after short DNS/network interruptions. Never retry writes here. */
    private suspend fun <T> retryRead(block: suspend () -> T): T {
        var last: Throwable? = null
        var refreshedExpiredSession = false
        val waits = longArrayOf(350, 800, 1600)
        for (attempt in 0..waits.size) {
            try { return block() }
            catch (t: Throwable) {
                last = t
                // PostgREST can answer PGRST303 when an access JWT expired
                // before the Auth auto-refresh worker completed. Refresh once,
                // then retry the original idempotent read with the new session.
                val errorText = generateSequence(t) { it.cause }
                    .joinToString(" ") { it.message.orEmpty() }
                val expiredJwt = errorText.contains("PGRST303", ignoreCase = true) ||
                    errorText.contains("JWT expired", ignoreCase = true) ||
                    errorText.contains("token is expired", ignoreCase = true)
                if (expiredJwt && !refreshedExpiredSession) {
                    refreshedExpiredSession = true
                    try {
                        client?.auth?.refreshCurrentSession()
                        continue
                    } catch (refreshError: Throwable) {
                        last = refreshError
                        // Keep the refresh failure visible; do not loop forever
                        // or silently sign the user out.
                        throw refreshError
                    }
                }
                if (attempt < waits.size) kotlinx.coroutines.delay(waits[attempt])
            }
        }
        throw (last ?: IllegalStateException("Не удалось подключиться к серверу"))
    }
    val userId get() = client?.auth?.currentUserOrNull()?.id

    suspend fun awaitAuthInitialization() { client?.auth?.awaitInitialization() }

    suspend fun signUp(email: String, password: String) {
        requireReady(); client!!.auth.signUpWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signIn(email: String, password: String) {
        requireReady(); client!!.auth.signInWith(Email) { this.email = email; this.password = password }
    }
    suspend fun signOut() { client?.auth?.signOut() }
    private fun requireReady() { check(client != null) { "Сначала добавь SUPABASE_URL и SUPABASE_ANON_KEY в secrets.properties" } }

    suspend fun uploadAvatar(bytes: ByteArray, fileName: String): String {
        val uid = userId ?: error("Сначала войди в аккаунт")
        val path = "$uid/avatar_${System.currentTimeMillis()}_${fileName.substringAfterLast('.', "jpg")}"
        client!!.storage.from("avatars").upload(path, bytes) { upsert = true }
        return client!!.storage.from("avatars").publicUrl(path)
    }

    suspend fun saveProfile(username: String, avatarUrl: String? = null, displayName: String = "") {
        val uid = userId ?: error("Сначала войди в аккаунт")
        client!!.from("profiles").upsert(buildJsonObject { put("id", uid); put("username", username); put("avatar_url", avatarUrl); put("display_name", displayName) })
    }
    suspend fun myProfile(): Profile? {
        val uid = userId ?: return null
        return retryRead { client!!.from("profiles").select { filter { eq("id", uid) } }.decodeList<Profile>().firstOrNull() }
    }
    suspend fun findUsers(query: String): List<Profile> {
        if (query.trim().length < 3) return emptyList()
        return client!!.from("profiles").select {
            filter { ilike("username", query.trim().removePrefix("@").lowercase()); neq("id", userId ?: "") }
            limit(30)
        }.decodeList()
    }
    suspend fun conversations(): List<Conversation> {
        val uid = userId ?: return emptyList()
        return retryRead { client!!.from("conversations").select {
            filter { or { eq("member_one", uid); eq("member_two", uid) } }
        }.decodeList<Conversation>() }
    }
    suspend fun chatPartners(): List<Profile> {
        val uid = userId ?: return emptyList()
        return conversations().mapNotNull { conversation ->
            val peerId = (if (conversation.memberOne == uid) conversation.memberTwo else conversation.memberOne) ?: return@mapNotNull null
            client!!.from("profiles").select { filter { eq("id", peerId) } }.decodeList<Profile>().firstOrNull()
        }
    }
    private suspend fun summaryFor(c: Conversation, uid: String): ChatSummary? {
        if (c.kind != "direct") return groupSummaryFor(c, uid)
        val peerId = (if (c.memberOne == uid) c.memberTwo else c.memberOne) ?: return null
        val peer = client!!.from("profiles").select { filter { eq("id", peerId) } }.decodeList<Profile>().firstOrNull() ?: return null
        val last = client!!.from("messages").select {
            filter { eq("conversation_id", c.id) }
            order("created_at", Order.DESCENDING)
            limit(1)
        }.decodeList<ChatMessage>().firstOrNull()
        val unread = client!!.from("messages").select {
            filter { eq("conversation_id", c.id); neq("sender_id", uid); exact("read_at", null) }
            limit(99)
        }.decodeList<ChatMessage>().size
        return ChatSummary(peer, c.id, last, unread)
    }
    private suspend fun groupSummaryFor(c: Conversation, uid: String): ChatSummary {
        val members = client!!.from("conversation_members").select { filter { eq("conversation_id", c.id) }; limit(500) }.decodeList<MemberRow>()
        val myRead = members.firstOrNull { it.userId == uid }?.lastReadAt
        val last = client!!.from("messages").select {
            filter { eq("conversation_id", c.id) }
            order("created_at", Order.DESCENDING)
            limit(1)
        }.decodeList<ChatMessage>().firstOrNull()
        val unread = client!!.from("messages").select {
            filter { eq("conversation_id", c.id); neq("sender_id", uid); if (myRead != null) gt("created_at", myRead) }
            limit(99)
        }.decodeList<ChatMessage>().size
        val title = c.title.ifBlank { if (c.kind == "channel") "Канал" else "Группа" }
        val peer = Profile(id = c.id, username = title, displayName = title, avatarUrl = c.avatarUrl)
        return ChatSummary(peer, c.id, last, unread, c.kind, c.ownerId, members.size)
    }
    /** Groups and channels the user belongs to. Empty (not an error) if update_v9.sql was not run yet. */
    private suspend fun groupConversations(): List<Conversation> {
        val uid = userId ?: return emptyList()
        return runCatching {
            val ids = retryRead { client!!.from("conversation_members").select { filter { eq("user_id", uid) }; limit(500) }.decodeList<MemberRow>() }.map { it.conversationId }
            if (ids.isEmpty()) emptyList() else retryRead {
                client!!.from("conversations").select { filter { isIn("id", ids); neq("kind", "direct") } }.decodeList<Conversation>()
            }
        }.getOrDefault(emptyList())
    }
    private val convInfoCache = java.util.concurrent.ConcurrentHashMap<String, Conversation>()
    /** Cached conversation row (kind/title) used by notifications. */
    suspend fun conversationInfo(conversationId: String): Conversation? {
        convInfoCache[conversationId]?.let { return it }
        val c = runCatching { retryRead { client!!.from("conversations").select { filter { eq("id", conversationId) }; limit(1) }.decodeList<Conversation>().firstOrNull() } }.getOrNull()
        if (c != null) convInfoCache[conversationId] = c
        return c
    }
    suspend fun summaryByConversation(conversationId: String): ChatSummary? {
        val uid = userId ?: return null
        val c = retryRead { client!!.from("conversations").select { filter { eq("id", conversationId) }; limit(1) }.decodeList<Conversation>().firstOrNull() } ?: return null
        return summaryFor(c, uid)
    }
    suspend fun createGroup(kind: String, title: String, memberIds: List<String>): String {
        requireReady()
        val r = client!!.postgrest.rpc("palka_create_group", buildJsonObject {
            put("p_kind", kind); put("p_title", title.trim()); put("p_members", memberIds.joinToString(","))
        })
        return r.data.trim().trim('"')
    }
    suspend fun addMembers(conversationId: String, memberIds: List<String>) {
        client!!.postgrest.rpc("palka_add_members", buildJsonObject { put("p_conversation", conversationId); put("p_members", memberIds.joinToString(",")) })
    }
    suspend fun leaveConversation(conversationId: String) {
        client!!.postgrest.rpc("palka_leave", buildJsonObject { put("p_conversation", conversationId) })
    }
    suspend fun conversationMembers(conversationId: String): List<GroupMember> {
        val rows = retryRead { client!!.from("conversation_members").select { filter { eq("conversation_id", conversationId) }; limit(500) }.decodeList<MemberRow>() }
        if (rows.isEmpty()) return emptyList()
        val profiles = retryRead { client!!.from("profiles").select { filter { isIn("id", rows.map { it.userId }) } }.decodeList<Profile>() }
        return rows.mapNotNull { r -> profiles.firstOrNull { it.id == r.userId }?.let { GroupMember(it, r.role) } }
            .sortedWith(compareBy({ it.role != "owner" }, { it.profile.displayName.ifBlank { it.profile.username }.lowercase() }))
    }
    /** Group/channel "read" marker (per member; direct chats use messages.read_at instead). */
    suspend fun markGroupRead(conversationId: String) {
        val uid = userId ?: return
        client!!.from("conversation_members").update(buildJsonObject { put("last_read_at", java.time.Instant.now().toString()) }) {
            filter { eq("conversation_id", conversationId); eq("user_id", uid) }
        }
    }
    /** Chat list data, newest conversation first. Chats run in parallel. */
    suspend fun chatSummaries(): List<ChatSummary> {
        val uid = userId ?: return emptyList()
        val convs = conversations() + groupConversations()
        val rows = coroutineScope {
            convs.map { c -> async { runCatching { summaryFor(c, uid) }.getOrNull() } }.awaitAll()
        }
        return rows.filterNotNull().sortedByDescending { it.last?.createdAt.orEmpty() }
    }
    suspend fun sentMessageCount(): Int {
        val uid = userId ?: return 0
        return client!!.from("messages").select { filter { eq("sender_id", uid) }; limit(500) }.decodeList<ChatMessage>().size
    }
    suspend fun openConversation(otherId: String): String {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("conversations").select {
            filter { or {
                and { eq("member_one", uid); eq("member_two", otherId) }
                and { eq("member_one", otherId); eq("member_two", uid) }
            } }
        }.decodeList<Conversation>().firstOrNull()
        if (existing != null) return existing.id
        val created = client!!.from("conversations").insert(buildJsonObject {
            put("member_one", uid); put("member_two", otherId)
        }) { select() }.decodeSingle<Conversation>()
        return created.id
    }
    fun appendCachedMessage(conversationId: String, message: ChatMessage) {
        val current = messageCache[conversationId].orEmpty()
        if (message.id == null || current.none { it.id == message.id }) messageCache[conversationId] = (current + message).takeLast(200)
    }
    suspend fun messages(conversationId: String): List<ChatMessage> = retryRead {
        client!!.from("messages").select {
            filter { eq("conversation_id", conversationId) }
            order("created_at", Order.ASCENDING)
            limit(200)
        }.decodeList<ChatMessage>().also { messageCache[conversationId] = it }
    }
    suspend fun privateNote(): String {
        val uid = userId ?: return ""
        return retryRead { client!!.from("private_notes").select { filter { eq("user_id", uid) }; limit(1) }.decodeList<PrivateNote>().firstOrNull()?.body.orEmpty() }
    }
    suspend fun savePrivateNote(body: String) {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("private_notes").select { filter { eq("user_id", uid) }; limit(1) }.decodeList<PrivateNote>().firstOrNull()
        val values = buildJsonObject { put("title", "Мои заметки"); put("body", body); put("updated_at", java.time.Instant.now().toString()) }
        if (existing == null) client!!.from("private_notes").insert(buildJsonObject { put("user_id", uid); put("title", "Мои заметки"); put("body", body) })
        else client!!.from("private_notes").update(values) { filter { eq("id", existing.id); eq("user_id", uid) } }
    }
    suspend fun sendMessage(conversationId: String, body: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("messages").insert(buildJsonObject {
            put("conversation_id", conversationId); put("sender_id", uid); put("body", body)
        })
    }
    /** Fast text send: use PostgREST's minimal response. The optimistic row is
     * reconciled with the authoritative INSERT received over Realtime. */
    suspend fun sendMessageFast(conversationId: String, body: String, replyTo: String? = null, id: String? = null) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("messages").insert(buildJsonObject {
            id?.let { put("id", it) }
            put("conversation_id", conversationId)
            put("sender_id", uid)
            put("body", body)
            replyTo?.let { put("reply_to", it) }
        })
    }
    suspend fun sendRichMessage(conversationId: String, body: String, replyTo: String? = null, mediaUrl: String? = null, mediaType: String? = null): ChatMessage {
        val uid = userId ?: error("Не выполнен вход")
        val sent = client!!.from("messages").insert(buildJsonObject {
            put("conversation_id", conversationId); put("sender_id", uid); put("body", body)
            replyTo?.let { put("reply_to", it) }; mediaUrl?.let { put("media_url", it) }; mediaType?.let { put("media_type", it) }
        }) { select() }.decodeSingle<ChatMessage>()
        appendCachedMessage(conversationId, sent)
        return sent
    }
    suspend fun editMessage(messageId: String, body: String) {
        client!!.from("messages").update(buildJsonObject { put("body", body); put("edited_at", java.time.Instant.now().toString()) }) { filter { eq("id", messageId); eq("sender_id", userId ?: "") } }
    }
    suspend fun deleteMessage(messageId: String) {
        client!!.from("messages").delete { filter { eq("id", messageId); eq("sender_id", userId ?: "") } }
    }
    suspend fun pinMessage(conversationId: String, messageId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("pinned_messages").upsert(buildJsonObject { put("conversation_id", conversationId); put("message_id", messageId); put("pinned_by", uid) })
    }
    suspend fun pinnedMessageId(conversationId: String): String? = client!!.from("pinned_messages").select {
        filter { eq("conversation_id", conversationId) }
        limit(1)
    }.decodeList<PinnedRow>().firstOrNull()?.messageId
    suspend fun unpinMessage(conversationId: String, messageId: String) {
        client!!.from("pinned_messages").delete {
            filter { eq("conversation_id", conversationId); eq("message_id", messageId) }
        }
    }
    suspend fun markRead(conversationId: String) {
        val uid = userId ?: return
        // Read receipts are idempotent: retry a failed UPDATE so a brief network
        // interruption or an expired JWT does not leave the sender's checkmarks stale.
        var lastError: Throwable? = null
        var refreshedSession = false
        val waits = longArrayOf(180, 450, 900)
        for (attempt in 0..waits.size) {
            try {
                client!!.from("messages").update(buildJsonObject {
                    put("read_at", java.time.Instant.now().toString())
                }) {
                    filter {
                        eq("conversation_id", conversationId)
                        neq("sender_id", uid)
                        exact("read_at", null)
                    }
                }
                return
            } catch (t: Throwable) {
                lastError = t
                val errorText = generateSequence(t) { it.cause }
                    .joinToString(" ") { it.message.orEmpty() }
                val expiredJwt = errorText.contains("PGRST303", ignoreCase = true) ||
                    errorText.contains("JWT expired", ignoreCase = true) ||
                    errorText.contains("token is expired", ignoreCase = true)
                if (expiredJwt && !refreshedSession) {
                    refreshedSession = true
                    client?.auth?.refreshCurrentSession()
                    continue
                }
                if (attempt < waits.size) kotlinx.coroutines.delay(waits[attempt])
            }
        }
        throw (lastError ?: IllegalStateException("Не удалось отметить сообщения прочитанными"))
    }
    suspend fun uploadChatMedia(bytes: ByteArray, fileName: String): String {
        val uid = userId ?: error("Не выполнен вход")
        val extension = fileName.substringAfterLast('.', "jpg").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "jpg" }
        val path = "$uid/${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}.$extension"
        client!!.storage.from("chat-media").upload(path, bytes) { upsert = false }
        return client!!.storage.from("chat-media").createSignedUrl(path, 7.days)
    }
    suspend fun blockUser(otherId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("user_blocks").upsert(buildJsonObject { put("blocker_id", uid); put("blocked_id", otherId) })
    }
    suspend fun blockedUsers(): List<String> {
        val uid = userId ?: return emptyList()
        return client!!.from("user_blocks").select { filter { eq("blocker_id", uid) } }.decodeList<BlockRow>().map { it.blockedId }
    }
    suspend fun unblockUser(otherId: String) {
        val uid = userId ?: error("Не выполнен вход")
        client!!.from("user_blocks").delete { filter { eq("blocker_id", uid); eq("blocked_id", otherId) } }
    }
    suspend fun blockedProfiles(): List<Profile> = blockedUsers().mapNotNull { id ->
        client!!.from("profiles").select { filter { eq("id", id) } }.decodeList<Profile>().firstOrNull()
    }
    suspend fun isBlockedByMe(otherId: String): Boolean = blockedUsers().contains(otherId)

    suspend fun setTyping(conversationId: String, typing: Boolean) {
        val uid = userId ?: return
        if (typing) client!!.from("chat_typing").upsert(buildJsonObject { put("conversation_id", conversationId); put("user_id", uid); put("updated_at", java.time.Instant.now().toString()) })
        else client!!.from("chat_typing").delete { filter { eq("conversation_id", conversationId); eq("user_id", uid) } }
    }
    suspend fun peerTyping(conversationId: String): Boolean {
        val uid = userId ?: return false
        val rows = client!!.from("chat_typing").select { filter { eq("conversation_id", conversationId); neq("user_id", uid) } }.decodeList<TypingRow>()
        return rows.any { runCatching { java.time.Duration.between(parseInstant(it.updatedAt), java.time.Instant.now()).seconds < 5 }.getOrDefault(false) }
    }

    suspend fun messageReactions(messageId: String): List<Reaction> = client!!.from("message_reactions").select {
        filter { eq("message_id", messageId) }
    }.decodeList<Reaction>()

    suspend fun react(messageId: String, emoji: String) {
        val uid = userId ?: error("Не выполнен вход")
        val existing = client!!.from("message_reactions").select {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }.decodeList<Reaction>().firstOrNull()
        val values = buildJsonObject { put("emoji", emoji) }
        if (existing == null) client!!.from("message_reactions").insert(buildJsonObject {
            put("message_id", messageId); put("user_id", uid); put("emoji", emoji)
        }) else client!!.from("message_reactions").update(values) {
            filter { eq("message_id", messageId); eq("user_id", uid) }
        }
    }
    @Volatile private var activeChannel: RealtimeChannel? = null
    @Volatile private var activeConversation: String? = null

    /** Instant peer-to-peer signal over the already-open Realtime socket (Broadcast). */
    suspend fun sendSignal(conversationId: String, event: String, payload: JsonObject) {
        val ch = activeChannel
        if (ch != null && activeConversation == conversationId) runCatching { ch.broadcast(event, payload) }
    }
    suspend fun broadcastMessage(m: ChatMessage) = sendSignal(m.conversationId, "msg", buildJsonObject {
        put("id", m.id); put("conversation_id", m.conversationId); put("sender_id", m.senderId)
        put("body", m.body); put("created_at", m.createdAt); put("reply_to", m.replyTo)
    })
    suspend fun sendRead(conversationId: String) = sendSignal(conversationId, "read", buildJsonObject { put("at", java.time.Instant.now().toString()) })
    suspend fun sendTyping(conversationId: String) = sendSignal(conversationId, "typing", buildJsonObject { put("at", java.time.Instant.now().toString()) })

    suspend fun watchMessages(
        conversationId: String,
        onSubscribed: suspend () -> Unit = {},
        onPeerRead: () -> Unit = {},
        onPeerTyping: () -> Unit = {},
        onChange: suspend (ChatMessage, Boolean) -> Unit
    ) {
        // Unique topic per subscription attempt: a leftover channel from a previous
        // visit/reconnect can never be reused (flows must be registered before joining).
        val channel = client!!.channel("palka-messages-$conversationId-${userId}-${java.util.UUID.randomUUID()}")
        // Fast path: Broadcast. Durable path: Postgres Changes. Both feed the same handler;
        // the UI dedupes by message id (the sender generates the id client-side).
        val inserts = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
            table = "messages"
            filter("conversation_id", FilterOperator.EQ, conversationId)
        }
        val updates = channel.postgresChangeFlow<PostgresAction.Update>(schema = "public") {
            table = "messages"
            filter("conversation_id", FilterOperator.EQ, conversationId)
        }
        val liveMessages = channel.broadcastFlow<JsonObject>("msg")
        val liveRead = channel.broadcastFlow<JsonObject>("read")
        val liveTyping = channel.broadcastFlow<JsonObject>("typing")
        val scope = CoroutineScope(Dispatchers.Main.immediate)
        val collectors = listOf(
            scope.launch {
                inserts.collect { action ->
                    val row = runCatching { rtJson.decodeFromJsonElement<ChatMessage>(action.record) }.getOrNull()
                    if (row?.conversationId == conversationId) onChange(row, true)
                }
            },
            scope.launch {
                updates.collect { action ->
                    val row = runCatching { rtJson.decodeFromJsonElement<ChatMessage>(action.record) }.getOrNull()
                    if (row?.conversationId == conversationId) onChange(row, false)
                }
            },
            scope.launch {
                liveMessages.collect { payload ->
                    val row = runCatching { rtJson.decodeFromJsonElement<ChatMessage>(payload) }.getOrNull()
                    if (row != null && row.conversationId == conversationId) onChange(row, true)
                }
            },
            scope.launch { liveRead.collect { onPeerRead() } },
            scope.launch { liveTyping.collect { onPeerTyping() } }
        )
        try {
            channel.subscribe(blockUntilSubscribed = true)
            activeChannel = channel
            activeConversation = conversationId
            onSubscribed()
            awaitCancellation()
        } finally {
            collectors.forEach { it.cancel() }
            if (activeChannel === channel) { activeChannel = null; activeConversation = null }
            // Previously the channel stayed subscribed forever after leaving the chat.
            withContext(NonCancellable) {
                runCatching { channel.unsubscribe() }
                runCatching { client!!.realtime.removeChannel(channel) }
            }
        }
    }
    suspend fun profileById(id: String): Profile? =
        retryRead { client!!.from("profiles").select { filter { eq("id", id) } }.decodeList<Profile>().firstOrNull() }

    /** Incoming unread messages newer than [sinceIso]; used to catch up after a reconnect. */
    suspend fun unreadIncomingSince(sinceIso: String): List<ChatMessage> {
        val uid = userId ?: return emptyList()
        return client!!.from("messages").select {
            filter { neq("sender_id", uid); exact("read_at", null); gte("created_at", sinceIso) }
            order("created_at", Order.ASCENDING)
            limit(20)
        }.decodeList<ChatMessage>()
    }

    /**
     * One Realtime subscription for ALL messages the user may read (RLS limits rows to the user's
     * conversations). Runs until cancelled or until the subscription fails.
     */
    suspend fun watchIncoming(onSubscribed: suspend () -> Unit = {}, onMessage: suspend (ChatMessage) -> Unit) {
        val channel = client!!.channel("palka-inbox-${userId}-${java.util.UUID.randomUUID()}")
        val inserts = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") { table = "messages" }
        coroutineScope {
            val collector = launch {
                inserts.collect { action ->
                    val row = runCatching { rtJson.decodeFromJsonElement<ChatMessage>(action.record) }.getOrNull()
                    if (row != null) runCatching { onMessage(row) }
                }
            }
            try {
                channel.subscribe(blockUntilSubscribed = true)
                onSubscribed()
                awaitCancellation()
            } finally {
                collector.cancel()
                withContext(NonCancellable) {
                    runCatching { channel.unsubscribe() }
                    runCatching { client!!.realtime.removeChannel(channel) }
                }
            }
        }
    }

    suspend fun touchPresence() {
        val uid = userId ?: return
        client!!.from("profiles").update(buildJsonObject { put("last_seen", java.time.Instant.now().toString()) }) {
            filter { eq("id", uid) }
        }
    }
}
