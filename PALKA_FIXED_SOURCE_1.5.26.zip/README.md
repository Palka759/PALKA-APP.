# PALKA 1.5.14

Focused performance update for text message sending. Text messages are inserted with a minimal PostgREST response; the instant local bubble is reconciled when its authoritative Realtime INSERT arrives. Photo/video and other rich-message flows are preserved.

Build through the repository's GitHub Actions workflow using Java 17 and Gradle 8.13. Required GitHub secrets: `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
