package com.palka.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.query.filter.FilterOperator
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.realtime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.webrtc.AudioTrack
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private val CallGreen = Color(0xFF3DDC84)
private val CallRed = Color(0xFFE5484D)
private val CallBg = Color(0xFF080D0A)
private val CallPanel = Color(0xFF1A241D)
private val CallCream = Color(0xFFEEF2EA)

@Serializable
data class CallSignal(
    val id: String? = null,
    @SerialName("call_id") val callId: String,
    @SerialName("from_id") val fromId: String,
    @SerialName("to_id") val toId: String,
    val kind: String,
    val payload: String = "",
    @SerialName("created_at") val createdAt: String? = null
)

/** One row of the "Calls" tab. */
data class CallRecord(val callId: String, val peer: Profile, val outgoing: Boolean, val answered: Boolean, val at: String?)

enum class CallPhase { Idle, Outgoing, Incoming, Connecting, Connected, Ended }

/**
 * One-to-one voice calls over WebRTC. Signalling (offer / answer / ICE / hang-up) goes through the
 * RLS-protected table `call_signals` (see supabase/update_v10.sql) and is delivered by Realtime
 * Postgres Changes, so only the two call parties can read it. Media flows peer-to-peer.
 */
object CallManager {
    var phase by mutableStateOf(CallPhase.Idle); private set
    var peer by mutableStateOf<Profile?>(null); private set
    var muted by mutableStateOf(false); private set
    var speaker by mutableStateOf(false); private set
    var seconds by mutableIntStateOf(0); private set
    var statusText by mutableStateOf(""); private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private var appContext: Context? = null
    private var listener: Job? = null
    private var timerJob: Job? = null
    private var timeoutJob: Job? = null

    private var callId: String? = null
    private var outgoing = false
    private var pendingOffer: String? = null
    private var remoteSet = false
    private val pendingIce = mutableListOf<IceCandidate>()
    /** ICE candidates that arrive before their invite (rows can be delivered out of order). */
    private val earlyIce = HashMap<String, MutableList<IceCandidate>>()
    private var connectedOnce = false

    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var ringPlayer: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private var factoryInitialized = false

    /** Starts the process-wide listener for incoming calls. Safe to call repeatedly. */
    fun start(ctx: Context) {
        appContext = ctx.applicationContext
        if (listener?.isActive == true) return
        listener = scope.launch { listenLoop() }
    }

    fun stop() {
        listener?.cancel(); listener = null
        if (phase != CallPhase.Idle) finish("Звонок завершён", notifyPeer = true)
    }

    private suspend fun listenLoop() {
        var wait = 2_000L
        while (scope.isActive) {
            val uid = Backend.userId
            if (uid == null || Backend.client == null) { delay(3_000); continue }
            try {
                watch(uid) { wait = 2_000L }
            } catch (c: CancellationException) { throw c } catch (_: Throwable) { }
            delay(wait)
            wait = minOf(wait * 2, 30_000L)
        }
    }

    private suspend fun watch(uid: String, onSubscribed: () -> Unit) {
        val channel = Backend.client!!.channel("palka-calls-$uid-${java.util.UUID.randomUUID()}")
        val inserts = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
            table = "call_signals"
            filter("to_id", FilterOperator.EQ, uid)
        }
        coroutineScope {
            val collector = launch {
                inserts.collect { action ->
                    val row = runCatching { json.decodeFromJsonElement<CallSignal>(action.record) }.getOrNull()
                    if (row != null) runCatching { onSignal(row) }
                }
            }
            try {
                channel.subscribe(blockUntilSubscribed = true)
                onSubscribed()
                awaitCancellation()
            } finally {
                collector.cancel()
                withContext(NonCancellable) {
                    runCatching { channel.unsubscribe() }
                    runCatching { Backend.client!!.realtime.removeChannel(channel) }
                }
            }
        }
    }

    // ---------------------------------------------------------------- incoming signals

    private suspend fun onSignal(s: CallSignal) {
        when (s.kind) {
            "invite" -> onInvite(s)
            "accept" -> if (s.callId == callId && outgoing && phase == CallPhase.Outgoing) {
                stopSounds()
                timeoutJob?.cancel()
                phase = CallPhase.Connecting; statusText = "Соединение…"
                runCatching {
                    pc?.setRemoteS(SessionDescription(SessionDescription.Type.ANSWER, s.payload))
                    remoteSet = true
                    flushIce()
                }.onFailure { finish("Не удалось соединиться", notifyPeer = true) }
            }
            "ice" -> {
                val c = parseIce(s.payload) ?: return
                if (s.callId == callId) {
                    if (remoteSet && pc != null) pc?.addIceCandidate(c) else pendingIce.add(c)
                } else if (phase == CallPhase.Idle) {
                    if (earlyIce.size > 8) earlyIce.clear()
                    earlyIce.getOrPut(s.callId) { mutableListOf() }.add(c)
                }
            }
            "decline" -> if (s.callId == callId) finish(if (s.payload == "busy") "Абонент занят" else "Звонок отклонён", notifyPeer = false)
            "end" -> if (s.callId == callId) finish("Звонок завершён", notifyPeer = false)
        }
    }

    private suspend fun onInvite(s: CallSignal) {
        if (phase != CallPhase.Idle) {
            // Already in a call: tell the caller we are busy.
            if (s.callId != callId) sendTo(s.fromId, s.callId, "decline", "busy")
            return
        }
        val caller = runCatching { Backend.profileById(s.fromId) }.getOrNull() ?: return
        callId = s.callId; outgoing = false; pendingOffer = s.payload
        remoteSet = false; pendingIce.clear(); connectedOnce = false
        earlyIce.remove(s.callId)?.let { pendingIce.addAll(it) }
        muted = false; speaker = false; seconds = 0
        peer = caller; phase = CallPhase.Incoming; statusText = "Входящий звонок"
        startRingtone()
        showIncomingNotification(caller)
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(50_000)
            if (phase == CallPhase.Incoming) finish("Пропущенный звонок", notifyPeer = false)
        }
    }

    // ---------------------------------------------------------------- user actions

    fun startCall(ctx: Context, target: Profile) {
        if (phase != CallPhase.Idle) return
        val uid = Backend.userId ?: return
        appContext = ctx.applicationContext
        callId = java.util.UUID.randomUUID().toString(); outgoing = true
        remoteSet = false; pendingIce.clear(); connectedOnce = false
        muted = false; speaker = false; seconds = 0
        peer = target; phase = CallPhase.Outgoing; statusText = "Вызываем…"
        startForegroundCall(ctx)
        scope.launch {
            try {
                val connection = createConnection()
                addMic(connection)
                setCommunicationAudio()
                val offer = connection.createOfferS()
                connection.setLocalS(offer)
                sendTo(target.id, callId!!, "invite", offer.description)
                startRingback()
                timeoutJob?.cancel()
                timeoutJob = scope.launch {
                    delay(45_000)
                    if (phase == CallPhase.Outgoing) finish("Нет ответа", notifyPeer = true)
                }
            } catch (t: Throwable) {
                finish("Не удалось начать звонок", notifyPeer = false)
            }
        }
    }

    fun accept(ctx: Context) {
        if (phase != CallPhase.Incoming) return
        val offer = pendingOffer ?: return
        val to = peer?.id ?: return
        val id = callId ?: return
        appContext = ctx.applicationContext
        stopSounds(); cancelNotification()
        timeoutJob?.cancel()
        phase = CallPhase.Connecting; statusText = "Соединение…"
        startForegroundCall(ctx)
        scope.launch {
            try {
                val connection = createConnection()
                addMic(connection)
                setCommunicationAudio()
                connection.setRemoteS(SessionDescription(SessionDescription.Type.OFFER, offer))
                remoteSet = true
                flushIce()
                val answer = connection.createAnswerS()
                connection.setLocalS(answer)
                sendTo(to, id, "accept", answer.description)
            } catch (t: Throwable) {
                finish("Не удалось соединиться", notifyPeer = true)
            }
        }
    }

    /** Decline an incoming call, cancel an outgoing one or end a running one. */
    fun hangUp() {
        if (phase == CallPhase.Idle || phase == CallPhase.Ended) return
        val declining = phase == CallPhase.Incoming
        val to = peer?.id; val id = callId
        if (to != null && id != null) scope.launch { runCatching { sendTo(to, id, if (declining) "decline" else "end", "") } }
        finish(if (declining) "Звонок отклонён" else "Звонок завершён", notifyPeer = false)
    }

    fun toggleMute() {
        muted = !muted
        audioTrack?.setEnabled(!muted)
    }

    fun toggleSpeaker() {
        speaker = !speaker
        applySpeaker()
    }

    // ---------------------------------------------------------------- WebRTC plumbing

    private fun ensureFactory(ctx: Context) {
        if (factory != null) return
        if (!factoryInitialized) {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions()
            )
            factoryInitialized = true
        }
        val adm = JavaAudioDeviceModule.builder(ctx)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .createAudioDeviceModule()
        factory = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory()
    }

    private fun iceServers(): List<PeerConnection.IceServer> {
        val list = mutableListOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        // Optional TURN relay (needed on some mobile networks). Set TURN_URL / TURN_USER / TURN_PASS in GitHub secrets.
        if (BuildConfig.TURN_URL.isNotBlank()) {
            list.add(
                PeerConnection.IceServer.builder(BuildConfig.TURN_URL)
                    .setUsername(BuildConfig.TURN_USER).setPassword(BuildConfig.TURN_PASS).createIceServer()
            )
        }
        return list
    }

    private fun createConnection(): PeerConnection {
        val ctx = appContext ?: error("no context")
        ensureFactory(ctx)
        val cfg = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                scope.launch {
                    when (state) {
                        PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> onConnected()
                        PeerConnection.IceConnectionState.FAILED -> finish("Не удалось соединиться (сеть блокирует звонок)", notifyPeer = true)
                        PeerConnection.IceConnectionState.DISCONNECTED -> if (phase == CallPhase.Connected) statusText = "Плохая связь…"
                        else -> {}
                    }
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                val c = candidate ?: return
                val to = peer?.id ?: return
                val id = callId ?: return
                val payload = buildJsonObject {
                    put("m", c.sdpMid ?: ""); put("i", c.sdpMLineIndex); put("c", c.sdp)
                }.toString()
                scope.launch(Dispatchers.IO) { runCatching { sendTo(to, id, "ice", payload) } }
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: org.webrtc.MediaStream?) {}
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {}
            override fun onDataChannel(channel: org.webrtc.DataChannel?) {}
            override fun onRenegotiationNeeded() {}
        }
        val connection = factory!!.createPeerConnection(cfg, observer) ?: error("PeerConnection is null")
        pc = connection
        return connection
    }

    private fun addMic(connection: PeerConnection) {
        val f = factory ?: return
        val source = f.createAudioSource(MediaConstraints())
        val track = f.createAudioTrack("palka_audio", source)
        track.setEnabled(!muted)
        audioTrack = track
        connection.addTrack(track, listOf("palka_stream"))
    }

    private fun onConnected() {
        if (phase == CallPhase.Connected || phase == CallPhase.Idle || phase == CallPhase.Ended) return
        connectedOnce = true
        stopSounds(); timeoutJob?.cancel()
        phase = CallPhase.Connected; statusText = ""
        seconds = 0
        timerJob?.cancel()
        timerJob = scope.launch { while (isActive) { delay(1000); seconds += 1 } }
    }

    private fun flushIce() {
        val connection = pc ?: return
        pendingIce.forEach { runCatching { connection.addIceCandidate(it) } }
        pendingIce.clear()
    }

    private fun parseIce(payload: String): IceCandidate? = runCatching {
        val o = json.parseToJsonElement(payload).jsonObject
        IceCandidate(o["m"]!!.jsonPrimitive.content, o["i"]!!.jsonPrimitive.content.toInt(), o["c"]!!.jsonPrimitive.content)
    }.getOrNull()

    private suspend fun sendTo(toId: String, id: String, kind: String, payload: String) {
        val uid = Backend.userId ?: return
        Backend.client!!.from("call_signals").insert(buildJsonObject {
            put("call_id", id); put("from_id", uid); put("to_id", toId); put("kind", kind); put("payload", payload)
        })
    }

    private fun finish(reason: String, notifyPeer: Boolean) {
        if (phase == CallPhase.Idle) return
        if (notifyPeer) {
            val to = peer?.id; val id = callId
            if (to != null && id != null) scope.launch { runCatching { sendTo(to, id, "end", "") } }
        }
        stopSounds(); cancelNotification()
        timeoutJob?.cancel(); timerJob?.cancel()
        runCatching { audioTrack?.setEnabled(false) }
        runCatching { pc?.close() }
        runCatching { pc?.dispose() }
        pc = null; audioTrack = null
        restoreAudio()
        appContext?.let { runCatching { it.stopService(Intent(it, CallService::class.java)) } }
        statusText = reason
        phase = CallPhase.Ended
        callId = null; pendingOffer = null; remoteSet = false; pendingIce.clear()
        scope.launch {
            delay(1_500)
            if (phase == CallPhase.Ended) { phase = CallPhase.Idle; peer = null; statusText = ""; seconds = 0 }
        }
    }

    // ---------------------------------------------------------------- audio

    private fun audioManager(): AudioManager? = appContext?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private fun setCommunicationAudio() {
        val am = audioManager() ?: return
        savedAudioMode = am.mode
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        applySpeaker()
    }

    @Suppress("DEPRECATION")
    private fun applySpeaker() { audioManager()?.isSpeakerphoneOn = speaker }

    @Suppress("DEPRECATION")
    private fun restoreAudio() {
        val am = audioManager() ?: return
        am.isSpeakerphoneOn = false
        am.mode = savedAudioMode
    }

    private fun startRingtone() {
        val ctx = appContext ?: return
        stopSounds()
        ringPlayer = runCatching {
            MediaPlayer.create(
                ctx, R.raw.palka_forest,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
            )?.apply { isLooping = true; start() }
        }.getOrNull()
    }

    private fun startRingback() {
        stopSounds()
        tone = runCatching { ToneGenerator(AudioManager.STREAM_VOICE_CALL, 60).also { it.startTone(ToneGenerator.TONE_SUP_RINGTONE) } }.getOrNull()
    }

    private fun stopSounds() {
        runCatching { ringPlayer?.stop() }; runCatching { ringPlayer?.release() }; ringPlayer = null
        runCatching { tone?.stopTone() }; runCatching { tone?.release() }; tone = null
    }

    // ---------------------------------------------------------------- notifications / service

    private const val CALL_CHANNEL = "palka_calls"
    private const val CALL_NOTIFICATION_ID = 7003

    private fun showIncomingNotification(caller: Profile) {
        val ctx = appContext ?: return
        if (NotificationHelper.appVisible) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureCallChannels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 7003,
            Intent(ctx, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP; action = "palka.incoming_call" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CALL_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_palka)
            .setContentTitle(caller.displayName.ifBlank { caller.username })
            .setContentText("Входящий звонок PALKA")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true).setAutoCancel(false)
            .setColor(0xFF3DDC84.toInt())
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(CALL_NOTIFICATION_ID, n) } catch (_: SecurityException) {}
    }

    private fun cancelNotification() {
        val ctx = appContext ?: return
        runCatching { NotificationManagerCompat.from(ctx).cancel(CALL_NOTIFICATION_ID) }
    }

    internal fun ensureCallChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val incoming = NotificationChannel(CALL_CHANNEL, "Входящие звонки", NotificationManager.IMPORTANCE_HIGH)
        incoming.setSound(null, null)
        incoming.enableVibration(false)
        nm.createNotificationChannel(incoming)
        val active = NotificationChannel("palka_call_active", "Текущий звонок", NotificationManager.IMPORTANCE_LOW)
        active.setShowBadge(false)
        nm.createNotificationChannel(active)
    }

    private fun startForegroundCall(ctx: Context) {
        runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, CallService::class.java)) }
    }

    // ---------------------------------------------------------------- call history

    suspend fun history(): List<CallRecord> {
        val uid = Backend.userId ?: return emptyList()
        val c = Backend.client ?: return emptyList()
        val invites = c.from("call_signals").select {
            filter {
                eq("kind", "invite")
                or { eq("from_id", uid); eq("to_id", uid) }
            }
            order("created_at", Order.DESCENDING)
            limit(40)
        }.decodeList<CallSignal>()
        if (invites.isEmpty()) return emptyList()
        val accepted = c.from("call_signals").select {
            filter { eq("kind", "accept"); isIn("call_id", invites.map { it.callId }) }
        }.decodeList<CallSignal>().map { it.callId }.toSet()
        val cache = HashMap<String, Profile?>()
        return invites.mapNotNull { inv ->
            val out = inv.fromId == uid
            val other = if (out) inv.toId else inv.fromId
            val p = cache.getOrPut(other) { runCatching { Backend.profileById(other) }.getOrNull() } ?: return@mapNotNull null
            CallRecord(inv.callId, p, out, inv.callId in accepted, inv.createdAt)
        }
    }
}

// -------------------------------------------------------------------- SdpObserver helpers

private suspend fun PeerConnection.createOfferS(): SessionDescription = suspendCancellableCoroutine { cont ->
    createOffer(object : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) { if (desc != null) cont.resume(desc) else cont.resumeWithException(IllegalStateException("empty offer")) }
        override fun onCreateFailure(error: String?) { cont.resumeWithException(IllegalStateException(error ?: "offer failed")) }
        override fun onSetSuccess() {}
        override fun onSetFailure(error: String?) {}
    }, MediaConstraints().apply { mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true")) })
}

private suspend fun PeerConnection.createAnswerS(): SessionDescription = suspendCancellableCoroutine { cont ->
    createAnswer(object : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) { if (desc != null) cont.resume(desc) else cont.resumeWithException(IllegalStateException("empty answer")) }
        override fun onCreateFailure(error: String?) { cont.resumeWithException(IllegalStateException(error ?: "answer failed")) }
        override fun onSetSuccess() {}
        override fun onSetFailure(error: String?) {}
    }, MediaConstraints())
}

private suspend fun PeerConnection.setLocalS(desc: SessionDescription): Unit = suspendCancellableCoroutine { cont ->
    setLocalDescription(object : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetSuccess() { cont.resume(Unit) }
        override fun onSetFailure(error: String?) { cont.resumeWithException(IllegalStateException(error ?: "setLocal failed")) }
    }, desc)
}

private suspend fun PeerConnection.setRemoteS(desc: SessionDescription): Unit = suspendCancellableCoroutine { cont ->
    setRemoteDescription(object : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription?) {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetSuccess() { cont.resume(Unit) }
        override fun onSetFailure(error: String?) { cont.resumeWithException(IllegalStateException(error ?: "setRemote failed")) }
    }, desc)
}

// -------------------------------------------------------------------- foreground service

/** Keeps the microphone alive while the app is in the background during a call. */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        CallManager.ensureCallChannels(this)
        val open = PendingIntent.getActivity(
            this, 7004,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "palka_call_active")
            .setSmallIcon(R.drawable.ic_stat_palka)
            .setContentTitle("PALKA")
            .setContentText("Идёт звонок")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(7002, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(7002, n)
        return START_NOT_STICKY
    }
}

// -------------------------------------------------------------------- UI

private fun hasMic(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

/** Returns a function that asks for the microphone permission (if needed) and then starts a call. */
@Composable
fun rememberCallStarter(): (Profile) -> Unit {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf<Profile?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val p = target; target = null
        if (granted && p != null) CallManager.startCall(ctx, p)
        else android.widget.Toast.makeText(ctx, "Нужен доступ к микрофону для звонков", android.widget.Toast.LENGTH_SHORT).show()
    }
    return { p ->
        if (hasMic(ctx)) CallManager.startCall(ctx, p)
        else { target = p; launcher.launch(Manifest.permission.RECORD_AUDIO) }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, label: String, bg: Color, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(68.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = tint, modifier = Modifier.size(30.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = CallCream.copy(alpha = .8f), fontSize = 12.sp)
    }
}

private fun formatDuration(total: Int): String = "%02d:%02d".format(total / 60, total % 60)

/** Full-screen call UI, drawn above everything while a call exists. */
@Composable
fun CallOverlay() {
    val phase = CallManager.phase
    if (phase == CallPhase.Idle) return
    val ctx = LocalContext.current
    val p = CallManager.peer
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) CallManager.accept(ctx) else CallManager.hangUp()
    }
    BackHandler(enabled = true) { /* a call is ended only with the red button */ }
    Box(Modifier.fillMaxSize().background(CallBg).clickable(enabled = false) {}) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(40.dp))
            if (p != null) Avatar(p.username, p.avatarUrl, 140.dp)
            Spacer(Modifier.height(20.dp))
            Text(
                if (p != null) p.displayName.ifBlank { p.username } else "", color = CallCream, fontSize = 28.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (p != null) Text("@${p.username}", color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                if (phase == CallPhase.Connected) formatDuration(CallManager.seconds) else CallManager.statusText,
                color = CallGreen, fontSize = 18.sp
            )
            Spacer(Modifier.weight(1f))
            if (phase == CallPhase.Incoming) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundButton(Icons.Default.CallEnd, "Отклонить", CallRed, Color.White) { CallManager.hangUp() }
                    RoundButton(Icons.Default.Call, "Ответить", CallGreen, CallBg) {
                        if (hasMic(ctx)) CallManager.accept(ctx) else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            } else if (phase != CallPhase.Ended) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundButton(
                        if (CallManager.muted) Icons.Default.MicOff else Icons.Default.Mic,
                        if (CallManager.muted) "Включить микрофон" else "Выключить микрофон",
                        if (CallManager.muted) Color.White else CallPanel,
                        if (CallManager.muted) CallBg else CallCream
                    ) { CallManager.toggleMute() }
                    RoundButton(
                        if (CallManager.speaker) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        if (CallManager.speaker) "Динамик вкл" else "Динамик выкл",
                        if (CallManager.speaker) Color.White else CallPanel,
                        if (CallManager.speaker) CallBg else CallCream
                    ) { CallManager.toggleSpeaker() }
                    RoundButton(Icons.Default.CallEnd, "Завершить", CallRed, Color.White) { CallManager.hangUp() }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun formatCallTime(iso: String?): String {
    if (iso == null) return ""
    return runCatching {
        val t = parseInstant(iso).atZone(java.time.ZoneId.systemDefault())
        val now = java.time.ZonedDateTime.now()
        if (t.toLocalDate() == now.toLocalDate()) "%02d:%02d".format(t.hour, t.minute)
        else "%02d.%02d %02d:%02d".format(t.dayOfMonth, t.monthValue, t.hour, t.minute)
    }.getOrDefault("")
}

/** "Calls" tab: recent calls, tap the phone to call back. */
@Composable
fun CallsTab() {
    var items by remember { mutableStateOf<List<CallRecord>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    val start = rememberCallStarter()
    LaunchedEffect(CallManager.phase) {
        // Reload at start and after each finished call.
        if (CallManager.phase == CallPhase.Idle || !loaded) {
            runCatching { items = CallManager.history() }
            loaded = true
        }
    }
    if (loaded && items.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("📞", fontSize = 44.sp)
            Spacer(Modifier.height(10.dp))
            Text("Звонков пока нет", color = CallCream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Открой личный чат и нажми на трубку вверху", color = Color.Gray, fontSize = 14.sp)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(items, key = { it.callId }) { r ->
            val missed = !r.outgoing && !r.answered
            Row(
                Modifier.fillMaxWidth().clickable { start(r.peer) }.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(r.peer.username, r.peer.avatarUrl, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.peer.displayName.ifBlank { r.peer.username }, color = if (missed) CallRed else CallCream, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (r.outgoing) Icons.Default.CallMade else if (missed) Icons.Default.CallMissed else Icons.Default.CallReceived,
                            null, tint = if (missed) CallRed else CallGreen, modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            (if (r.outgoing) "Исходящий" else if (missed) "Пропущенный" else "Входящий") + if (r.outgoing && !r.answered) " · без ответа" else "",
                            color = Color.Gray, fontSize = 13.sp
                        )
                    }
                }
                Text(formatCallTime(r.at), color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.width(10.dp))
                Icon(Icons.Default.Call, "Позвонить", tint = CallGreen)
            }
        }
    }
}
