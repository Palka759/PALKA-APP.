-- PALKA database schema. Run once in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  avatar_url text,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  member_one uuid not null references public.profiles(id) on delete cascade,
  member_two uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint different_members check (member_one <> member_two),
  constraint unique_direct_conversation unique (member_one, member_two)
);
create index if not exists conversations_member_two_idx on public.conversations(member_two);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

create table if not exists public.message_reactions (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null check (emoji in ('❤️','😂','🪵','👍')),
  created_at timestamptz not null default now(),
  unique(message_id, user_id)
);

-- Automatically create a starter profile when an email account is created.
create or replace function public.create_palka_profile()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id, username)
  values (new.id, 'palka_' || substr(replace(new.id::text, '-', ''), 1, 10))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_palka on auth.users;
create trigger on_auth_user_created_palka after insert on auth.users
for each row execute procedure public.create_palka_profile();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.message_reactions enable row level security;

-- Signed-in users can discover nicknames and read basic public profile info.
create policy "profiles visible to authenticated" on public.profiles
for select to authenticated using (true);
create policy "users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "users insert own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id);

create policy "members read conversations" on public.conversations
for select to authenticated using (auth.uid() in (member_one, member_two));
create policy "members create conversations" on public.conversations
for insert to authenticated with check (auth.uid() = member_one or auth.uid() = member_two);

create policy "members read messages" on public.messages
for select to authenticated using (
  exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two))
);
create policy "members send messages as self" on public.messages
for insert to authenticated with check (
  sender_id = auth.uid() and exists (
    select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
  )
);

create policy "chat members read reactions" on public.message_reactions
for select to authenticated using (
  exists (select 1 from public.messages m join public.conversations c on c.id = m.conversation_id
          where m.id = message_id and auth.uid() in (c.member_one, c.member_two))
);
create policy "chat members add own reactions" on public.message_reactions
for insert to authenticated with check (
  user_id = auth.uid() and exists (select 1 from public.messages m join public.conversations c on c.id = m.conversation_id
          where m.id = message_id and auth.uid() in (c.member_one, c.member_two))
);
create policy "users change own reactions" on public.message_reactions
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Enable realtime delivery for new messages and profile presence changes.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.profiles;
exception when duplicate_object then null; when undefined_object then null;
end $$;

-- Required Data API grants. RLS still decides which rows each user can access.
grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.conversations to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert, update on public.message_reactions to authenticated;
create unique index if not exists conversations_pair_unique
  on public.conversations (least(member_one, member_two), greatest(member_one, member_two));

-- Публичное хранилище аватарок PALKA
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do update set public = true;

create policy "Users can upload own PALKA avatar"
on storage.objects for insert to authenticated
with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Anyone can view PALKA avatars"
on storage.objects for select to public
using (bucket_id = 'avatars');


-- PALKA update: profile names, message actions, media, read receipts, blocks and private notes.
alter table public.profiles add column if not exists display_name text not null default '';
alter table public.messages add column if not exists reply_to uuid references public.messages(id) on delete set null;
alter table public.messages add column if not exists media_url text;
alter table public.messages add column if not exists media_type text;
alter table public.messages add column if not exists edited_at timestamptz;
alter table public.messages add column if not exists read_at timestamptz;

create table if not exists public.user_blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  constraint user_blocks_no_self check (blocker_id <> blocked_id)
);
create table if not exists public.private_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default '',
  body text not null default '',
  updated_at timestamptz not null default now()
);

alter table public.user_blocks enable row level security;
alter table public.private_notes enable row level security;
create policy "users manage own blocks" on public.user_blocks for all to authenticated
using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());
create policy "users manage own notes" on public.private_notes for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "members edit own messages" on public.messages for update to authenticated
using (sender_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (sender_id = auth.uid());
create policy "members delete own messages" on public.messages for delete to authenticated
using (sender_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
grant select, insert, update, delete on public.messages to authenticated;
grant select, insert, update, delete on public.user_blocks, public.private_notes to authenticated;

-- Private media bucket for chat attachments; users can upload under their own folder.
insert into storage.buckets (id, name, public) values ('chat-media','chat-media',false)
on conflict (id) do nothing;
create policy "Users upload own chat media" on storage.objects for insert to authenticated
with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users read chat media" on storage.objects for select to authenticated
using (bucket_id = 'chat-media');


-- PALKA live typing indicator
create table if not exists public.chat_typing (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  updated_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
alter table public.chat_typing enable row level security;
drop policy if exists "chat members read typing" on public.chat_typing;
create policy "chat members read typing" on public.chat_typing for select to authenticated
using (exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
drop policy if exists "users manage own typing" on public.chat_typing;
create policy "users manage own typing" on public.chat_typing for all to authenticated
using (user_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (user_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
grant select, insert, update, delete on public.chat_typing to authenticated;


-- PALKA 1.1.2: allow recipients to mark incoming messages as read.
drop policy if exists "members mark incoming messages read" on public.messages;
create policy "members mark incoming messages read" on public.messages
for update to authenticated
using (sender_id <> auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (sender_id <> auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));

create table if not exists public.pinned_messages (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  pinned_by uuid not null references public.profiles(id) on delete cascade,
  pinned_at timestamptz not null default now()
);
alter table public.pinned_messages enable row level security;
drop policy if exists "members manage pinned messages" on public.pinned_messages;
create policy "members manage pinned messages" on public.pinned_messages for all to authenticated
using (exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (pinned_by = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
grant select, insert, update, delete on public.pinned_messages to authenticated;
