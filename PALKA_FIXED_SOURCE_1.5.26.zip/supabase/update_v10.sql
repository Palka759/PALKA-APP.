-- PALKA 1.5.25: public groups/channels (search + join) and voice calls signalling.
-- Run ONCE in Supabase Dashboard > SQL Editor, then press Run. Safe to run repeatedly.
-- Requires update_v9.sql to have been run before.

-- ============ 1. Public groups and channels ============
alter table public.conversations add column if not exists is_public boolean not null default false;
alter table public.conversations add column if not exists handle text;
alter table public.conversations drop constraint if exists conversations_handle_check;
alter table public.conversations add constraint conversations_handle_check
  check (handle is null or handle ~ '^[a-z0-9_]{3,32}$');
create unique index if not exists conversations_handle_uidx on public.conversations (lower(handle)) where handle is not null;

-- Create a group/channel; optionally public with a unique @handle.
create or replace function public.palka_create_group2(p_kind text, p_title text, p_members text, p_public boolean, p_handle text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare cid uuid; h text := lower(trim(coalesce(p_handle, '')));
begin
  if p_public and h !~ '^[a-z0-9_]{3,32}$' then
    raise exception 'Адрес: 3–32 символа, только a-z, 0-9 и _';
  end if;
  cid := public.palka_create_group(p_kind, p_title, p_members);
  if p_public then
    begin
      update public.conversations set is_public = true, handle = h where id = cid and owner_id = auth.uid();
    exception when unique_violation then
      raise exception 'Такой @адрес уже занят';
    end;
  end if;
  return cid;
end $$;

-- Search public groups/channels by title or @handle. Empty query = most popular.
create or replace function public.palka_search_public(p_query text)
returns table (id uuid, kind text, title text, avatar_url text, handle text, member_count bigint, is_member boolean)
language sql stable security definer set search_path = '' as $$
  select c.id, c.kind, c.title, c.avatar_url, c.handle,
         (select count(*) from public.conversation_members m where m.conversation_id = c.id) as member_count,
         exists (select 1 from public.conversation_members m where m.conversation_id = c.id and m.user_id = auth.uid()) as is_member
  from public.conversations c
  where c.is_public and c.kind <> 'direct' and auth.uid() is not null
    and (
      coalesce(trim(p_query), '') = ''
      or c.title ilike '%' || replace(replace(replace(trim(p_query), '\', '\\'), '%', '\%'), '_', '\_') || '%'
      or c.handle ilike '%' || replace(replace(replace(trim(p_query), '\', '\\'), '%', '\%'), '_', '\_') || '%'
    )
  order by member_count desc, c.title
  limit 30;
$$;

-- Join a public group/channel without having written to anyone.
create or replace function public.palka_join_public(p_conversation uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Нужно войти в аккаунт'; end if;
  if not exists (select 1 from public.conversations c where c.id = p_conversation and c.is_public and c.kind <> 'direct') then
    raise exception 'Чат не найден или не публичный';
  end if;
  insert into public.conversation_members(conversation_id, user_id) values (p_conversation, auth.uid()) on conflict do nothing;
end $$;

revoke execute on function public.palka_create_group2(text, text, text, boolean, text) from public, anon;
revoke execute on function public.palka_search_public(text) from public, anon;
revoke execute on function public.palka_join_public(uuid) from public, anon;
grant execute on function public.palka_create_group2(text, text, text, boolean, text) to authenticated;
grant execute on function public.palka_search_public(text) to authenticated;
grant execute on function public.palka_join_public(uuid) to authenticated;

-- ============ 2. Voice calls: signalling through an RLS-protected table ============
create table if not exists public.call_signals (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null,
  from_id uuid not null references public.profiles(id) on delete cascade,
  to_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('invite','accept','ice','decline','end')),
  payload text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists call_signals_to_idx on public.call_signals(to_id, created_at desc);
create index if not exists call_signals_from_idx on public.call_signals(from_id, created_at desc);
create index if not exists call_signals_call_idx on public.call_signals(call_id);

-- You may call only people you already have a direct chat with, and not if they blocked you.
create or replace function public.palka_can_call(target uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select auth.uid() is not null and target <> auth.uid()
    and exists (select 1 from public.conversations c where c.kind = 'direct'
                and ((c.member_one = auth.uid() and c.member_two = target) or (c.member_one = target and c.member_two = auth.uid())))
    and not exists (select 1 from public.user_blocks b where b.blocker_id = target and b.blocked_id = auth.uid());
$$;
grant execute on function public.palka_can_call(uuid) to authenticated;

alter table public.call_signals enable row level security;
drop policy if exists "call parties read signals" on public.call_signals;
create policy "call parties read signals" on public.call_signals for select to authenticated
using (from_id = auth.uid() or to_id = auth.uid());
drop policy if exists "caller sends signals" on public.call_signals;
create policy "caller sends signals" on public.call_signals for insert to authenticated
with check (from_id = auth.uid() and public.palka_can_call(to_id));
grant select, insert on public.call_signals to authenticated;

-- Realtime delivery of signals (ignore "already member" errors on re-run).
do $$ begin
  alter publication supabase_realtime add table public.call_signals;
exception when duplicate_object then null;
         when undefined_object then null;
end $$;

-- Optional housekeeping: signals older than 3 days are useless except as call history.
-- delete from public.call_signals where created_at < now() - interval '30 days';
