-- PALKA v2 migration. Run this once in Supabase SQL Editor.
-- Adds separate display names, rich messages, blocks, typing, notes and media storage.
alter table public.profiles add column if not exists display_name text not null default '';
alter table public.messages add column if not exists reply_to uuid references public.messages(id) on delete set null;
alter table public.messages add column if not exists media_url text;
alter table public.messages add column if not exists media_type text;
alter table public.messages add column if not exists edited_at timestamptz;
alter table public.messages add column if not exists read_at timestamptz;

create table if not exists public.user_blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  constraint user_blocks_no_self check (blocker_id <> blocked_id)
);
create table if not exists public.private_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default '', body text not null default '', updated_at timestamptz not null default now()
);
create table if not exists public.chat_typing (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  updated_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

alter table public.user_blocks enable row level security;
alter table public.private_notes enable row level security;
alter table public.chat_typing enable row level security;

drop policy if exists "users manage own blocks" on public.user_blocks;
create policy "users manage own blocks" on public.user_blocks for all to authenticated
using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());
drop policy if exists "users manage own notes" on public.private_notes;
create policy "users manage own notes" on public.private_notes for all to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "chat members read typing" on public.chat_typing;
create policy "chat members read typing" on public.chat_typing for select to authenticated
using (exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
drop policy if exists "users manage own typing" on public.chat_typing;
create policy "users manage own typing" on public.chat_typing for all to authenticated
using (user_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (user_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));

drop policy if exists "members edit own messages" on public.messages;
create policy "members edit own messages" on public.messages for update to authenticated
using (sender_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (sender_id = auth.uid());
drop policy if exists "members delete own messages" on public.messages;
create policy "members delete own messages" on public.messages for delete to authenticated
using (sender_id = auth.uid() and exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));

grant select, insert, update, delete on public.messages to authenticated;
grant select, insert, update, delete on public.user_blocks, public.private_notes, public.chat_typing to authenticated;

-- Avatar uploads need UPDATE permission as Storage upsert replaces existing objects.
drop policy if exists "Users can update own PALKA avatar" on storage.objects;
create policy "Users can update own PALKA avatar" on storage.objects for update to authenticated
using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
insert into storage.buckets (id, name, public) values ('avatars','avatars',true)
on conflict (id) do update set public = true;
insert into storage.buckets (id, name, public) values ('chat-media','chat-media',false)
on conflict (id) do nothing;
drop policy if exists "Users upload own chat media" on storage.objects;
create policy "Users upload own chat media" on storage.objects for insert to authenticated
with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users read chat media" on storage.objects;
create policy "Users read chat media" on storage.objects for select to authenticated using (bucket_id = 'chat-media');

-- Permit recipients to set read_at without permitting them to edit someone else's text.
create or replace function public.palka_guard_message_update()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if auth.uid() <> old.sender_id then
    if new.body is distinct from old.body
       or new.reply_to is distinct from old.reply_to
       or new.media_url is distinct from old.media_url
       or new.media_type is distinct from old.media_type
       or new.sender_id is distinct from old.sender_id
       or new.conversation_id is distinct from old.conversation_id
       or new.edited_at is distinct from old.edited_at then
      raise exception 'Only the sender can edit message content';
    end if;
    if not exists (select 1 from public.conversations c where c.id = old.conversation_id and auth.uid() in (c.member_one,c.member_two)) then
      raise exception 'Not a conversation member';
    end if;
  end if;
  return new;
end;
$$;
drop trigger if exists palka_guard_message_update_trigger on public.messages;
create trigger palka_guard_message_update_trigger before update on public.messages
for each row execute function public.palka_guard_message_update();
drop policy if exists "members update messages in conversation" on public.messages;
create policy "members update messages in conversation" on public.messages for update to authenticated
using (exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)))
with check (exists (select 1 from public.conversations c where c.id = conversation_id and auth.uid() in (c.member_one,c.member_two)));
