-- PALKA 1.1.3 incremental database update.
-- Safe to run more than once. Does not alter existing profiles or messages.

create table if not exists public.chat_typing (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  updated_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

alter table public.chat_typing enable row level security;
drop policy if exists "chat members read typing" on public.chat_typing;
create policy "chat members read typing" on public.chat_typing
for select to authenticated
using (exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
));
drop policy if exists "users manage own typing" on public.chat_typing;
create policy "users manage own typing" on public.chat_typing
for all to authenticated
using (user_id = auth.uid() and exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
))
with check (user_id = auth.uid() and exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
));
grant select, insert, update, delete on public.chat_typing to authenticated;

create table if not exists public.pinned_messages (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  pinned_by uuid not null references public.profiles(id) on delete cascade,
  pinned_at timestamptz not null default now()
);
alter table public.pinned_messages enable row level security;
drop policy if exists "members manage pinned messages" on public.pinned_messages;
create policy "members manage pinned messages" on public.pinned_messages
for all to authenticated
using (exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
))
with check (pinned_by = auth.uid() and exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
));
grant select, insert, update, delete on public.pinned_messages to authenticated;
