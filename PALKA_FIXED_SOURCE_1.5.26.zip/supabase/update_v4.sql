-- PALKA 1.4.0: read receipts and private notes access. No anon access is granted.
grant select, insert, update, delete on public.private_notes to authenticated;
grant update (read_at) on public.messages to authenticated;
drop policy if exists "members mark incoming messages read" on public.messages;
create policy "members mark incoming messages read" on public.messages
for update to authenticated
using (sender_id <> auth.uid() and exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
))
with check (sender_id <> auth.uid() and exists (
  select 1 from public.conversations c
  where c.id = conversation_id and auth.uid() in (c.member_one, c.member_two)
));
