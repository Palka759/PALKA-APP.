-- PALKA 1.5.2: fast read receipts and realtime message updates.
-- Run once in Supabase SQL Editor. Safe to run repeatedly.

alter table public.messages
  add column if not exists read_at timestamptz;

grant select, insert, update, delete on public.messages to authenticated;
grant update (read_at) on public.messages to authenticated;

drop policy if exists "members mark incoming messages read" on public.messages;
create policy "members mark incoming messages read"
on public.messages
for update to authenticated
using (
  sender_id <> auth.uid()
  and exists (
    select 1 from public.conversations c
    where c.id = messages.conversation_id
      and auth.uid() in (c.member_one, c.member_two)
  )
)
with check (
  sender_id <> auth.uid()
  and exists (
    select 1 from public.conversations c
    where c.id = messages.conversation_id
      and auth.uid() in (c.member_one, c.member_two)
  )
);

create index if not exists messages_unread_by_conversation_idx
  on public.messages (conversation_id, read_at)
  where read_at is null;

-- Enable INSERT and UPDATE events for the app's realtime subscription.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'messages'
     ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;
