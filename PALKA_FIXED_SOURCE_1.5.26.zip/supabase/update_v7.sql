-- PALKA 1.5.4: message indexes and Realtime publication
-- Safe to run repeatedly. Does not alter photo storage permissions or expose data to anon.

create index if not exists messages_conversation_created_idx
  on public.messages (conversation_id, created_at);

create index if not exists messages_unread_by_conversation_idx
  on public.messages (conversation_id, read_at)
  where read_at is null;

alter table public.messages replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'messages'
     ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;
