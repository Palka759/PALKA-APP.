-- PALKA 1.5.21: allow any emoji reaction (the "+" button in the message menu).
-- Run once in Supabase SQL Editor. Safe to run repeatedly.
alter table public.message_reactions drop constraint if exists message_reactions_emoji_check;
alter table public.message_reactions
  add constraint message_reactions_emoji_check check (char_length(emoji) between 1 and 16);
