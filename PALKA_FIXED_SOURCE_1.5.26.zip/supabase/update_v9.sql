-- PALKA 1.5.24: groups and channels.
-- Run ONCE in Supabase Dashboard > SQL Editor, then press Run. Safe to run repeatedly.
-- Existing direct chats keep working. Groups/channels: members are chosen only from people
-- you already have a direct chat with. In a channel only the owner can write; members can react.

-- 1. conversations: kind + title + owner; direct members become optional for groups/channels
alter table public.conversations alter column member_one drop not null;
alter table public.conversations alter column member_two drop not null;
alter table public.conversations add column if not exists kind text not null default 'direct';
alter table public.conversations add column if not exists title text not null default '';
alter table public.conversations add column if not exists avatar_url text;
alter table public.conversations add column if not exists owner_id uuid references public.profiles(id) on delete set null;
alter table public.conversations drop constraint if exists conversations_kind_check;
alter table public.conversations add constraint conversations_kind_check check (kind in ('direct','group','channel'));
alter table public.conversations drop constraint if exists conversations_shape_check;
alter table public.conversations add constraint conversations_shape_check check (
  (kind = 'direct' and member_one is not null and member_two is not null)
  or (kind <> 'direct' and member_one is null and member_two is null)
);

-- 2. members
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  joined_at timestamptz not null default now(),
  last_read_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id);

insert into public.conversation_members(conversation_id, user_id)
  select id, member_one from public.conversations where kind = 'direct' on conflict do nothing;
insert into public.conversation_members(conversation_id, user_id)
  select id, member_two from public.conversations where kind = 'direct' on conflict do nothing;

create or replace function public.palka_direct_members() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.kind = 'direct' then
    insert into public.conversation_members(conversation_id, user_id)
    values (new.id, new.member_one), (new.id, new.member_two) on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists palka_direct_members_trigger on public.conversations;
create trigger palka_direct_members_trigger after insert on public.conversations
for each row execute function public.palka_direct_members();

-- 3. helper functions used by every policy
create or replace function public.palka_is_member(cid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversation_members m where m.conversation_id = cid and m.user_id = auth.uid())
      or exists (select 1 from public.conversations c where c.id = cid and c.kind = 'direct' and auth.uid() in (c.member_one, c.member_two));
$$;
create or replace function public.palka_can_post(cid uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversations c where c.id = cid and (
    (c.kind = 'direct' and auth.uid() in (c.member_one, c.member_two))
    or (c.kind = 'group' and exists (select 1 from public.conversation_members m where m.conversation_id = c.id and m.user_id = auth.uid()))
    or (c.kind = 'channel' and c.owner_id = auth.uid())
  ));
$$;

-- 4. policies
alter table public.conversation_members enable row level security;
drop policy if exists "members see members" on public.conversation_members;
create policy "members see members" on public.conversation_members for select to authenticated
using (public.palka_is_member(conversation_id));
drop policy if exists "member updates own read mark" on public.conversation_members;
create policy "member updates own read mark" on public.conversation_members for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select on public.conversation_members to authenticated;
grant update (last_read_at) on public.conversation_members to authenticated;

drop policy if exists "members read conversations" on public.conversations;
create policy "members read conversations" on public.conversations for select to authenticated
using (public.palka_is_member(id) or auth.uid() in (member_one, member_two));
drop policy if exists "members create conversations" on public.conversations;
create policy "members create conversations" on public.conversations for insert to authenticated
with check (kind = 'direct' and (auth.uid() = member_one or auth.uid() = member_two));

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated
using (public.palka_is_member(conversation_id));
drop policy if exists "members send messages as self" on public.messages;
create policy "members send messages as self" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and public.palka_can_post(conversation_id));
drop policy if exists "members edit own messages" on public.messages;
create policy "members edit own messages" on public.messages for update to authenticated
using (sender_id = auth.uid() and public.palka_can_post(conversation_id))
with check (sender_id = auth.uid());
drop policy if exists "members delete own messages" on public.messages;
create policy "members delete own messages" on public.messages for delete to authenticated
using (sender_id = auth.uid() and public.palka_is_member(conversation_id));
drop policy if exists "members update messages in conversation" on public.messages;
create policy "members update messages in conversation" on public.messages for update to authenticated
using (public.palka_is_member(conversation_id)) with check (public.palka_is_member(conversation_id));
drop policy if exists "members mark incoming messages read" on public.messages;
create policy "members mark incoming messages read" on public.messages for update to authenticated
using (sender_id <> auth.uid() and public.palka_is_member(conversation_id))
with check (sender_id <> auth.uid() and public.palka_is_member(conversation_id));

create or replace function public.palka_guard_message_update()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if auth.uid() <> old.sender_id then
    if new.body is distinct from old.body
       or new.reply_to is distinct from old.reply_to
       or new.media_url is distinct from old.media_url
       or new.media_type is distinct from old.media_type
       or new.sender_id is distinct from old.sender_id
       or new.conversation_id is distinct from old.conversation_id
       or new.edited_at is distinct from old.edited_at then
      raise exception 'Only the sender can edit message content';
    end if;
    if not public.palka_is_member(old.conversation_id) then
      raise exception 'Not a conversation member';
    end if;
  end if;
  return new;
end $$;

-- reactions: any member (including channel subscribers) may react
drop policy if exists "chat members read reactions" on public.message_reactions;
create policy "chat members read reactions" on public.message_reactions for select to authenticated
using (exists (select 1 from public.messages m where m.id = message_id and public.palka_is_member(m.conversation_id)));
drop policy if exists "chat members add own reactions" on public.message_reactions;
create policy "chat members add own reactions" on public.message_reactions for insert to authenticated
with check (user_id = auth.uid() and exists (select 1 from public.messages m where m.id = message_id and public.palka_is_member(m.conversation_id)));

-- typing rows (legacy) and pinned messages
drop policy if exists "chat members read typing" on public.chat_typing;
create policy "chat members read typing" on public.chat_typing for select to authenticated
using (public.palka_is_member(conversation_id));
drop policy if exists "users manage own typing" on public.chat_typing;
create policy "users manage own typing" on public.chat_typing for all to authenticated
using (user_id = auth.uid() and public.palka_is_member(conversation_id))
with check (user_id = auth.uid() and public.palka_is_member(conversation_id));

drop policy if exists "members manage pinned messages" on public.pinned_messages;
drop policy if exists "members read pinned messages" on public.pinned_messages;
create policy "members read pinned messages" on public.pinned_messages for select to authenticated
using (public.palka_is_member(conversation_id));
drop policy if exists "posters insert pinned messages" on public.pinned_messages;
create policy "posters insert pinned messages" on public.pinned_messages for insert to authenticated
with check (pinned_by = auth.uid() and public.palka_can_post(conversation_id));
drop policy if exists "posters update pinned messages" on public.pinned_messages;
create policy "posters update pinned messages" on public.pinned_messages for update to authenticated
using (public.palka_can_post(conversation_id)) with check (pinned_by = auth.uid() and public.palka_can_post(conversation_id));
drop policy if exists "posters delete pinned messages" on public.pinned_messages;
create policy "posters delete pinned messages" on public.pinned_messages for delete to authenticated
using (public.palka_can_post(conversation_id));

-- 5. RPC: create / add / leave
create or replace function public.palka_create_group(p_kind text, p_title text, p_members text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); cid uuid; mid uuid; ids uuid[];
begin
  if uid is null then raise exception 'Нужно войти в аккаунт'; end if;
  if p_kind not in ('group','channel') then raise exception 'Неверный тип чата'; end if;
  if char_length(trim(coalesce(p_title,''))) not between 1 and 60 then raise exception 'Название должно быть от 1 до 60 символов'; end if;
  insert into public.conversations(kind, title, owner_id) values (p_kind, trim(p_title), uid) returning id into cid;
  insert into public.conversation_members(conversation_id, user_id, role) values (cid, uid, 'owner');
  ids := coalesce(string_to_array(nullif(p_members, ''), ',')::uuid[], '{}');
  foreach mid in array ids loop
    if mid <> uid and exists (select 1 from public.conversations c where c.kind = 'direct'
         and ((c.member_one = uid and c.member_two = mid) or (c.member_one = mid and c.member_two = uid))) then
      insert into public.conversation_members(conversation_id, user_id) values (cid, mid) on conflict do nothing;
    end if;
  end loop;
  return cid;
end $$;

create or replace function public.palka_add_members(p_conversation uuid, p_members text)
returns void language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); mid uuid; ids uuid[];
begin
  if not exists (select 1 from public.conversations c where c.id = p_conversation and c.kind <> 'direct' and c.owner_id = uid) then
    raise exception 'Добавлять участников может только владелец';
  end if;
  ids := coalesce(string_to_array(nullif(p_members, ''), ',')::uuid[], '{}');
  foreach mid in array ids loop
    if mid <> uid and exists (select 1 from public.conversations c where c.kind = 'direct'
         and ((c.member_one = uid and c.member_two = mid) or (c.member_one = mid and c.member_two = uid))) then
      insert into public.conversation_members(conversation_id, user_id) values (p_conversation, mid) on conflict do nothing;
    end if;
  end loop;
end $$;

create or replace function public.palka_leave(p_conversation uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if exists (select 1 from public.conversations c where c.id = p_conversation and c.owner_id = auth.uid()) then
    raise exception 'Владелец не может выйти из своей группы или канала';
  end if;
  delete from public.conversation_members m
  using public.conversations c
  where m.conversation_id = p_conversation and m.user_id = auth.uid() and c.id = m.conversation_id and c.kind <> 'direct';
end $$;

revoke execute on function public.palka_create_group(text, text, text) from public, anon;
revoke execute on function public.palka_add_members(uuid, text) from public, anon;
revoke execute on function public.palka_leave(uuid) from public, anon;
grant execute on function public.palka_create_group(text, text, text) to authenticated;
grant execute on function public.palka_add_members(uuid, text) to authenticated;
grant execute on function public.palka_leave(uuid) to authenticated;
grant execute on function public.palka_is_member(uuid) to authenticated;
grant execute on function public.palka_can_post(uuid) to authenticated;
