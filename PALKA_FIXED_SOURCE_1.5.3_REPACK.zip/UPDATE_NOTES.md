PALKA 1.5.3

Build fix: removed unsupported PostgREST Kotlin filter isNull("read_at") from markRead. The query still marks incoming messages as read and keeps the existing conversation and sender filters. All other 1.5.2 source changes are preserved.
