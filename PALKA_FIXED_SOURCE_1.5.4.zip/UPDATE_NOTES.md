# PALKA 1.5.4

- Skips repeated read-receipt UPDATEs when there are no unread incoming messages.
- Uses Realtime as the primary message refresh path with a short burst guard.
- Fetches reactions only for newly received messages instead of repeatedly querying every old message.
- Keeps a slower polling fallback for network reconnects.
- Photo upload/storage code is unchanged.

Source archive integrity checked; Android build/runtime not verified in this environment.
