# PALKA 1.5.5

- Text messages now render optimistically and the composer clears immediately, before waiting for Supabase.
- Each text send runs independently so one slow request does not disable the next send.
- On server confirmation, the local pending bubble is replaced with the real database message; on failure it is removed and an error is shown.
- Edit-message flow remains confirmed by the server before clearing the editor.
- Photo upload and storage implementation are unchanged.
- Read receipts still depend on recipient read_at updates delivered through Supabase Realtime; no claim of zero network latency.

Validation: source diff reviewed; ZIP integrity checked. Android compilation and live two-account Realtime test were not available in this environment.
