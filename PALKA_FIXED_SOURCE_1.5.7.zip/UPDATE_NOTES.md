# PALKA 1.5.6

- Keep optimistic text-message display: the message appears in the chat immediately while the server request runs.
- Scope Realtime INSERT and UPDATE subscriptions to the currently open conversation instead of waking every open chat for unrelated messages.
- Queue Realtime refreshes that arrive while a refresh is already running or inside the short debounce window, so an event is not silently dropped.
- Mark only incoming messages whose `read_at` is still NULL. This avoids rewriting already-read rows and reduces unnecessary Realtime UPDATE events.
- Preserve existing photo/video upload and message UI paths.


## PALKA 1.5.7
- Fixed Kotlin compilation failure in Realtime subscription: removed unsupported direct filter property access for the pinned Supabase Kotlin 3.2.3 SDK.
- Realtime events are checked against conversation_id in the client before refreshing the open chat.
- Message sending, read receipts, and photo/video upload code are unchanged from 1.5.6.
