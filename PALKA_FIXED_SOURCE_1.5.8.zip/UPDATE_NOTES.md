# PALKA 1.5.8

Fix Kotlin compilation: remove invalid kotlinx.serialization.json.content import. The JsonPrimitive content property remains used.
