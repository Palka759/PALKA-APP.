# PALKA 1.5.8

Fix Kotlin compilation: remove invalid kotlinx.serialization.json.content import. The JsonPrimitive content property remains used.


## 1.5.9 — continuous chat updates
- Keep the Realtime listener running and retry its subscription with exponential backoff when it exits.
- Use a 15-second safety refresh only as fallback; Realtime remains the primary delivery path.
- Keep optimistic local messages visible while their server insert is still pending.
- Render fetched messages before starting read-receipt writes; mark only when unread incoming messages exist.
- Move typing and pinned-message checks out of every message refresh; typing is checked separately.
