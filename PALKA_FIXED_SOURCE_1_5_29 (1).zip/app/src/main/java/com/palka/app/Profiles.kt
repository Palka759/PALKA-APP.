package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage

private fun fmtTime(iso: String?, pattern: String): String = try {
    java.time.format.DateTimeFormatter.ofPattern(pattern)
        .withZone(java.time.ZoneId.systemDefault())
        .format(parseInstant(iso ?: ""))
} catch (_: Throwable) { "—" }

private fun onlineNow(lastSeen: String?): Boolean = try {
    lastSeen?.let { java.time.Duration.between(parseInstant(it), java.time.Instant.now()).seconds < 75 } ?: false
} catch (_: Throwable) { false }

private fun rankFor(total: Long): String = when {
    total >= 5000 -> "Древний лес 🌲"
    total >= 1000 -> "Дуб 🌳"
    total >= 100 -> "Палка 🪵"
    else -> "Росток 🌱"
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.Gray, fontSize = 14.sp)
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** Profile card: avatar (tap it again for the full photo), name, nick, status and message counters. */
@Composable
fun UserProfileDialog(person: Profile, conversationId: String?, onDismiss: () -> Unit) {
    var p by remember(person.id) { mutableStateOf(person) }
    var total by remember(person.id) { mutableStateOf<Long?>(null) }
    var shared by remember(person.id) { mutableStateOf<Long?>(null) }
    var showPhoto by remember(person.id) { mutableStateOf(false) }
    LaunchedEffect(person.id) {
        runCatching { Backend.profileById(person.id) }.getOrNull()?.let { p = it }
        runCatching { Backend.profileStats(person.id, conversationId) }.getOrNull()?.let { total = it.first; shared = it.second }
    }
    val text = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    val online = onlineNow(p.lastSeen)
    val hasPhoto = !p.avatarUrl.isNullOrBlank()
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.clip(CircleShape).clickable { if (hasPhoto) showPhoto = true }) {
                    Avatar(p.username, p.avatarUrl, 120.dp)
                }
                Text(if (hasPhoto) "Нажми на фото, чтобы открыть" else "Нет фото", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                Text(p.displayName.ifBlank { p.username }, color = text, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Text("@${p.username}", color = accent, fontSize = 15.sp)
                Spacer(Modifier.height(14.dp))
                InfoRow("Статус", if (online) "в сети" else "был(а) в сети: " + fmtTime(p.lastSeen, "d MMM, HH:mm"), if (online) accent else text)
                InfoRow("Сообщений всего", total?.toString() ?: "—", text)
                if (conversationId != null) InfoRow("Сообщений в этом чате", shared?.toString() ?: "—", text)
                InfoRow("Ранг", rankFor(total ?: 0L), text)
                InfoRow("В PALKA с", fmtTime(p.createdAt, "d MMM yyyy"), text)
                TextButton(onClick = onDismiss, modifier = Modifier.padding(top = 6.dp)) { Text("Закрыть", color = accent) }
            }
        }
    }
    if (showPhoto && hasPhoto) PhotoViewer(p.avatarUrl!!) { showPhoto = false }
}

/** Full-screen photo with pinch-to-zoom; tap anywhere to close. */
@Composable
fun PhotoViewer(url: String, onClose: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable { onClose() }, contentAlignment = Alignment.Center) {
            AsyncImage(
                model = url, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale > 1f) offset + pan else Offset.Zero
                        }
                    }
                    .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
            )
            Text("Нажмите, чтобы закрыть", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp))
        }
    }
}
