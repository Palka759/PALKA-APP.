package com.palka.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.sin

/**
 * Appearance settings that are not part of the colour theme: accent colour, font size,
 * bubble shape, wallpaper dimming/blur. Stored in SharedPreferences "palka_look".
 */
object Look {
    var accent by mutableStateOf("theme")
    var fontScale by mutableStateOf(1f)
    var bubble by mutableStateOf("round")
    var dim by mutableStateOf(0f)
    var blur by mutableStateOf(0)
    var customVersion by mutableStateOf(0)

    private const val PREFS = "palka_look"

    fun load(c: Context) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        accent = p.getString("accent", "theme") ?: "theme"
        fontScale = p.getFloat("font", 1f)
        bubble = p.getString("bubble", "round") ?: "round"
        dim = p.getFloat("dim", 0f)
        blur = p.getInt("blur", 0)
    }

    fun save(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("accent", accent).putFloat("font", fontScale).putString("bubble", bubble)
            .putFloat("dim", dim).putInt("blur", blur).apply()
    }

    val accentColors: List<Pair<String, Color>> = listOf(
        "green" to Color(0xFF3DDC84), "amber" to Color(0xFFFFB84D), "teal" to Color(0xFF2EC4B6),
        "pink" to Color(0xFFFF7EB6), "blue" to Color(0xFF6CB4FF), "violet" to Color(0xFFB794F6)
    )

    /** null = use the accent colour of the current theme. */
    fun accentOverride(key: String = accent): Color? = accentColors.firstOrNull { it.first == key }?.second

    fun bubbleShape(mine: Boolean, style: String = bubble): RoundedCornerShape = when (style) {
        "soft" -> RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomStart = if (mine) 26.dp else 8.dp, bottomEnd = if (mine) 8.dp else 26.dp)
        "square" -> RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = if (mine) 8.dp else 2.dp, bottomEnd = if (mine) 2.dp else 8.dp)
        else -> RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (mine) 18.dp else 5.dp, bottomEnd = if (mine) 5.dp else 18.dp)
    }

    fun defaultWallpaper(c: Context): String {
        val p = c.getSharedPreferences("palka_wallpaper_default", Context.MODE_PRIVATE)
        return p.getString("wp", null) ?: "img${p.getInt("wallpaper", 0)}"
    }

    fun chatWallpaper(c: Context, conversationId: String): String {
        val p = c.getSharedPreferences("palka_wallpaper_$conversationId", Context.MODE_PRIVATE)
        return p.getString("wp", null) ?: p.getInt("wallpaper", -1).let { if (it >= 0) "img$it" else defaultWallpaper(c) }
    }
}

/** Simple counters shown in the hidden "Диагностика связи" dialog (tap the status dot in a chat). */
object NetStats {
    @Volatile var lastInsertMs = -1L       // HTTP INSERT round trip of our last message
    @Volatile var lastEchoMs = -1L         // from sending until our own row came back through Realtime
    @Volatile var lastPeerLagMs = Long.MIN_VALUE // peer's send clock -> our receive clock (needs equal phone clocks)
    @Volatile var lastSubscribeMs = -1L    // time to open the Realtime channel
    @Volatile var reconnects = 0
    val sendStart = java.util.concurrent.ConcurrentHashMap<String, Long>()
}

/** Outlives the chat screen: a message being sent is not cancelled when the user leaves the chat. */
val deliveryScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main.immediate)

data class WpInfo(val id: String, val title: String, val animated: Boolean = false)

val PalkaWallpapers = listOf(
    WpInfo("img0", "Чаща"), WpInfo("img1", "Тропа"), WpInfo("img2", "Поляна"), WpInfo("img3", "Опушка"),
    WpInfo("night", "Ночной лес"), WpInfo("fog", "Туман"), WpInfo("rain", "Дождь", true), WpInfo("sunset", "Закат"),
    WpInfo("snow", "Снегопад", true), WpInfo("fireflies", "Светлячки", true), WpInfo("crystal", "Кристаллы"),
    WpInfo("sticks", "Палки"), WpInfo("leaves", "Листопад", true), WpInfo("custom", "Своё")
)

fun saveCustomWallpaper(ctx: Context, uri: Uri): Boolean {
    return try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
        java.io.File(ctx.filesDir, "wp_custom.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        Look.customVersion++
        true
    } catch (_: Throwable) { false }
}

fun hasCustomWallpaper(ctx: Context): Boolean = java.io.File(ctx.filesDir, "wp_custom.jpg").exists()

/** blur 0..100. Cheap blur: scale down and back up with filtering. */
fun loadCustomWallpaper(ctx: Context, blur: Int): ImageBitmap? {
    return try {
        val f = java.io.File(ctx.filesDir, "wp_custom.jpg")
        if (!f.exists()) return null
        val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        if (blur <= 0) return src.asImageBitmap()
        val factor = 1f / (1f + blur / 6f)
        val w = (src.width * factor).toInt().coerceAtLeast(8)
        val h = (src.height * factor).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        Bitmap.createScaledBitmap(small, src.width, src.height, true).asImageBitmap()
    } catch (_: Throwable) { null }
}

/** Chat/preview background: resource photo, user's picture or a drawn (optionally animated) scene, plus dimming. */
@Composable
fun WallpaperBackdrop(id: String, dim: Float, blur: Int, modifier: Modifier = Modifier, animate: Boolean = true) {
    val ctx = LocalContext.current
    Box(modifier) {
        if (id.startsWith("img")) {
            val res = when (id) {
                "img1" -> R.drawable.palka_forest_wallpaper_2
                "img2" -> R.drawable.palka_forest_wallpaper_3
                "img3" -> R.drawable.palka_forest_wallpaper_4
                else -> R.drawable.palka_forest_wallpaper_1
            }
            Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (id == "custom") {
            val bmp by produceState<ImageBitmap?>(null, blur, Look.customVersion) {
                value = withContext(Dispatchers.IO) { loadCustomWallpaper(ctx, blur) }
            }
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxSize().background(Color(0xFF0F1A12)))
        } else {
            SceneWallpaper(id, animate)
        }
        if (dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim.coerceIn(0f, 0.85f))))
    }
}

@Composable
private fun SceneWallpaper(id: String, animate: Boolean) {
    val animated = animate && PalkaWallpapers.firstOrNull { it.id == id }?.animated == true
    var t by remember { mutableFloatStateOf(0f) }
    if (animated) {
        LaunchedEffect(id) {
            val start = withFrameNanos { it }
            while (true) {
                withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
            }
        }
    }
    Canvas(Modifier.fillMaxSize()) { drawScene(id, t) }
}

private fun DrawScope.pines(color: Color, baseY: Float, count: Int, hMin: Float, hMax: Float, seed: Int) {
    val rnd = java.util.Random(seed.toLong())
    for (i in 0 until count) {
        val slot = size.width / count
        val cx = slot * (i + 0.5f) + (rnd.nextFloat() - 0.5f) * slot * 0.8f
        val h = hMin + rnd.nextFloat() * (hMax - hMin)
        val w = h * 0.34f
        drawRect(color, Offset(cx - w * 0.06f, baseY - h * 0.12f), Size(w * 0.12f, h * 0.14f))
        for (k in 0..2) {
            val top = baseY - h + k * h * 0.27f
            val bottom = top + h * 0.42f
            val half = w * (0.5f + 0.3f * k)
            val p = Path()
            p.moveTo(cx, top)
            p.lineTo(cx + half, bottom)
            p.lineTo(cx - half, bottom)
            p.close()
            drawPath(p, color)
        }
    }
}

private fun DrawScope.vgrad(vararg colors: Long) {
    drawRect(Brush.verticalGradient(colors.map { Color(it) }))
}

private fun DrawScope.drawScene(id: String, t: Float) {
    val w = size.width
    val h = size.height
    when (id) {
        "night" -> {
            vgrad(0xFF050B12, 0xFF0B2218, 0xFF0F2E1F)
            val rnd = java.util.Random(7)
            for (i in 0 until 70) drawCircle(Color.White.copy(alpha = 0.25f + rnd.nextFloat() * 0.5f), 1f + rnd.nextFloat() * 1.6f, Offset(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.55f))
            val moon = Offset(w * 0.76f, h * 0.13f)
            drawCircle(Brush.radialGradient(listOf(Color(0x66FFF3D0), Color.Transparent), moon, w * 0.22f), w * 0.22f, moon)
            drawCircle(Color(0xFFFFF3D0), w * 0.065f, moon)
            pines(Color(0xFF0C1F17), h * 0.80f, 8, h * 0.22f, h * 0.36f, 1)
            pines(Color(0xFF06110C), h * 1.02f, 5, h * 0.32f, h * 0.52f, 2)
        }
        "fog" -> {
            vgrad(0xFF1A2A24, 0xFF2C3F36, 0xFF1B2B24)
            pines(Color(0xFF22362D), h * 0.72f, 9, h * 0.2f, h * 0.32f, 3)
            for (i in 0..5) {
                val y = h * (0.25f + i * 0.13f)
                drawOval(Color(0xFFCFE3D6).copy(alpha = 0.09f), Offset(-w * 0.2f + (i % 2) * w * 0.25f, y), Size(w * 1.1f, h * 0.12f))
            }
            pines(Color(0xFF14211B), h * 1.0f, 6, h * 0.3f, h * 0.5f, 4)
            drawRect(Color(0xFFCFE3D6).copy(alpha = 0.06f))
        }
        "rain" -> {
            vgrad(0xFF0B1A1A, 0xFF123027, 0xFF0B1D17)
            for (i in 0..3) {
                rotate(-30f + i * 22f, Offset(w * (0.1f + i * 0.3f), h)) {
                    drawOval(Color(0xFF1E5A38).copy(alpha = 0.75f), Offset(w * (0.1f + i * 0.3f) - w * 0.1f, h - h * 0.12f), Size(w * 0.2f, h * 0.3f))
                }
            }
            val rnd = java.util.Random(11)
            for (i in 0 until 70) {
                val x = rnd.nextFloat() * w
                val len = 18f + rnd.nextFloat() * 26f
                val speed = 0.5f + rnd.nextFloat() * 0.7f
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + len) - len
                drawLine(Color(0xFFBFE8D8).copy(alpha = 0.32f), Offset(x, y), Offset(x - len * 0.18f, y + len), strokeWidth = 2f)
            }
        }
        "sunset" -> {
            drawRect(Brush.verticalGradient(0f to Color(0xFF2B1B3D), 0.35f to Color(0xFFB5476B), 0.62f to Color(0xFFFF9E5E), 0.8f to Color(0xFF3A2A2E), 1f to Color(0xFF140E17)))
            val sun = Offset(w * 0.5f, h * 0.6f)
            drawCircle(Brush.radialGradient(listOf(Color(0x88FFD08A), Color.Transparent), sun, w * 0.5f), w * 0.5f, sun)
            drawCircle(Color(0xFFFFD08A), w * 0.14f, sun)
            pines(Color(0xFF241420), h * 0.86f, 9, h * 0.18f, h * 0.3f, 5)
            pines(Color(0xFF140E17), h * 1.02f, 5, h * 0.3f, h * 0.48f, 6)
        }
        "snow" -> {
            vgrad(0xFF0E1A2B, 0xFF1E3350, 0xFF2A4260)
            pines(Color(0xFF14243A), h * 0.82f, 8, h * 0.22f, h * 0.36f, 8)
            pines(Color(0xFF0B1523), h * 1.02f, 5, h * 0.32f, h * 0.5f, 9)
            val rnd = java.util.Random(21)
            for (i in 0 until 80) {
                val r = 1.4f + rnd.nextFloat() * 2.6f
                val speed = 0.05f + rnd.nextFloat() * 0.09f
                val x = (rnd.nextFloat() * w + sin((t * 0.8f + i).toDouble()).toFloat() * 14f)
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + 10f) - 5f
                drawCircle(Color.White.copy(alpha = 0.55f + rnd.nextFloat() * 0.4f), r, Offset(x, y))
            }
        }
        "fireflies" -> {
            vgrad(0xFF04100A, 0xFF0A2214, 0xFF0F2C19)
            pines(Color(0xFF07170E), h * 0.85f, 8, h * 0.2f, h * 0.34f, 12)
            pines(Color(0xFF030B06), h * 1.02f, 5, h * 0.3f, h * 0.5f, 13)
            val rnd = java.util.Random(31)
            for (i in 0 until 30) {
                val bx = rnd.nextFloat() * w
                val by = h * (0.25f + rnd.nextFloat() * 0.65f)
                val sp = 0.25f + rnd.nextFloat() * 0.5f
                val ph = rnd.nextFloat() * 6.28f
                val x = bx + sin((t * sp + ph).toDouble()).toFloat() * w * 0.05f
                val y = by + sin((t * sp * 1.3f + ph * 2f).toDouble()).toFloat() * h * 0.03f
                val glow = (0.5f + 0.5f * sin((t * (0.8f + sp) + ph).toDouble()).toFloat()).coerceIn(0f, 1f)
                val c = Offset(x, y)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFD7FF6A).copy(alpha = 0.55f * glow), Color.Transparent), c, 22f), 22f, c)
                drawCircle(Color(0xFFF4FFB0).copy(alpha = 0.4f + 0.6f * glow), 2.6f, c)
            }
        }
        "crystal" -> {
            vgrad(0xFF120A24, 0xFF1B1038, 0xFF0A1428)
            val glow = Offset(w * 0.5f, h * 0.85f)
            drawCircle(Brush.radialGradient(listOf(Color(0x552EC4B6), Color.Transparent), glow, w * 0.8f), w * 0.8f, glow)
            val rnd = java.util.Random(41)
            val cols = listOf(Color(0xFF2EC4B6), Color(0xFFFF7EB6), Color(0xFF8E7CFF))
            for (i in 0 until 11) {
                val x = w * (i + 0.5f) / 11f + (rnd.nextFloat() - 0.5f) * w * 0.05f
                val ch = h * (0.1f + rnd.nextFloat() * 0.26f)
                val cw = w * (0.035f + rnd.nextFloat() * 0.04f)
                val base = h * 1.0f
                val c = cols[i % cols.size]
                val p = Path()
                p.moveTo(x, base - ch)
                p.lineTo(x + cw, base - ch * 0.72f)
                p.lineTo(x + cw * 0.8f, base)
                p.lineTo(x - cw * 0.8f, base)
                p.lineTo(x - cw, base - ch * 0.72f)
                p.close()
                drawPath(p, c.copy(alpha = 0.5f))
                drawLine(Color.White.copy(alpha = 0.25f), Offset(x, base - ch), Offset(x - cw * 0.3f, base), strokeWidth = 2f)
            }
            val st = java.util.Random(43)
            for (i in 0 until 40) drawCircle(Color.White.copy(alpha = 0.2f + st.nextFloat() * 0.4f), 1f + st.nextFloat() * 1.4f, Offset(st.nextFloat() * w, st.nextFloat() * h * 0.7f))
        }
        "sticks" -> {
            drawRect(Color(0xFF0E1A12))
            val rnd = java.util.Random(51)
            for (i in 0 until 46) {
                val cx = rnd.nextFloat() * w
                val cy = rnd.nextFloat() * h
                val len = w * (0.18f + rnd.nextFloat() * 0.22f)
                val th = 10f + rnd.nextFloat() * 8f
                val deg = rnd.nextFloat() * 180f
                rotate(deg, Offset(cx, cy)) {
                    drawRoundRect(Color(0xFF3B2A1A).copy(alpha = 0.7f), Offset(cx - len / 2, cy - th / 2), Size(len, th), CornerRadius(th / 2, th / 2))
                    drawRoundRect(Color(0xFF6B4A2A).copy(alpha = 0.45f), Offset(cx - len / 2 + th, cy - th / 2 + 2f), Size(len - th * 2, 2.5f), CornerRadius(2f, 2f))
                }
                if (i % 3 == 0) drawCircle(Color(0xFF2E7A45).copy(alpha = 0.35f), 7f + rnd.nextFloat() * 6f, Offset(cx + len * 0.2f, cy))
            }
            drawRect(Brush.verticalGradient(listOf(Color(0xAA0E1A12), Color.Transparent, Color(0xAA0E1A12))))
        }
        "leaves" -> {
            vgrad(0xFF2A1A0E, 0xFF4A2A12, 0xFF1C130B)
            val cols = listOf(Color(0xFFD9822B), Color(0xFFB5451B), Color(0xFFE0A526), Color(0xFF8C5A1E))
            val rnd = java.util.Random(61)
            for (i in 0 until 26) {
                val sz = 18f + rnd.nextFloat() * 22f
                val speed = 0.04f + rnd.nextFloat() * 0.06f
                val x = rnd.nextFloat() * w + sin((t * 0.7f + i).toDouble()).toFloat() * 30f
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + sz * 2) - sz
                val deg = t * (20f + rnd.nextFloat() * 50f) + i * 40f
                rotate(deg, Offset(x, y)) {
                    drawOval(cols[i % cols.size].copy(alpha = 0.85f), Offset(x - sz / 2, y - sz / 3), Size(sz, sz * 0.66f))
                    drawLine(Color(0x55000000), Offset(x - sz / 2, y), Offset(x + sz / 2, y), strokeWidth = 1.5f)
                }
            }
        }
        else -> drawRect(Color(0xFF0F1A12))
    }
}

// ---------------------------------------------------------------- stickers

data class StickerDef(val id: String, val emoji: String, val caption: String, val color: Long)

val PalkaStickers = listOf(
    StickerDef("stick", "🪵", "Палка!", 0xFF8A5A2B), StickerDef("pine", "🌲", "Ёлки-палки", 0xFF2E7A45),
    StickerDef("fire", "🔥", "Горячо!", 0xFFD9531E), StickerDef("mushroom", "🍄", "Гриб-молодец", 0xFFB5451B),
    StickerDef("owl", "🦉", "Не сплю", 0xFF6B4A2A), StickerDef("wolf", "🐺", "Ауф", 0xFF4A5560),
    StickerDef("moon", "🌙", "Спокойной ночи", 0xFF3A4A8A), StickerDef("tent", "⛺", "Я в походе", 0xFF2E7A6A),
    StickerDef("bear", "🐻", "Обнимаю", 0xFF8A5A2B), StickerDef("heart", "💚", "Люблю", 0xFF2E9A55),
    StickerDef("ok", "👌", "Ок", 0xFF3D8A5A), StickerDef("lol", "🤣", "Ржу", 0xFFC98B1E),
    StickerDef("wow", "😮", "Ого", 0xFF8E5AB5), StickerDef("sad", "😢", "Грустно", 0xFF3A6A9A),
    StickerDef("angry", "😡", "Злюсь", 0xFFB53A3A), StickerDef("hi", "👋", "Привет", 0xFF3D8A5A)
)

@Composable
fun StickerView(id: String, size: Dp = 128.dp) {
    val def = PalkaStickers.firstOrNull { it.id == id } ?: PalkaStickers[0]
    Column(Modifier.width(size), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(def.emoji, fontSize = (size.value * 0.5f).sp)
        Text(
            def.caption, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(def.color)).padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}

/** One-line text for the chat list, pinned bar, replies and notifications. */
fun previewText(m: ChatMessage): String = when (m.mediaType) {
    "video" -> "🎥 Видео"
    "image" -> if (m.mediaUrl?.contains(".gif", true) == true) "GIF" else "📷 Фото"
    "audio" -> "🎤 Голосовое сообщение"
    "sticker" -> PalkaStickers.firstOrNull { it.id == m.body.removePrefix("sticker:") }?.let { "${it.emoji} Стикер" } ?: "Стикер"
    "poll" -> "📊 " + m.body.lineSequence().firstOrNull().orEmpty()
    else -> m.body
}

// ---------------------------------------------------------------- voice messages

fun voiceDuration(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: java.io.File? = null
    private var startMs = 0L

    val elapsedMs: Long get() = if (rec != null) SystemClock.elapsedRealtime() - startMs else 0L

    fun start(): Boolean {
        return try {
            val f = java.io.File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val r = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(48000)
            r.setAudioSamplingRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r; file = f; startMs = SystemClock.elapsedRealtime()
            true
        } catch (_: Throwable) {
            cancel()
            false
        }
    }

    /** Finishes the recording. Returns the file and its length, or null if it was too short/failed. */
    fun stop(): Pair<java.io.File, Long>? {
        val r = rec ?: return null
        val f = file
        val ms = SystemClock.elapsedRealtime() - startMs
        rec = null; file = null
        return try {
            r.stop(); r.release()
            if (f != null && ms >= 600) f to ms else { f?.delete(); null }
        } catch (_: Throwable) {
            runCatching { r.release() }
            f?.delete()
            null
        }
    }

    fun cancel() {
        rec?.let { runCatching { it.stop() }; runCatching { it.release() } }
        file?.delete()
        rec = null; file = null
    }
}

object VoicePlaying { var activeUrl by mutableStateOf<String?>(null) }

@Composable
fun VoiceBubble(url: String, label: String, accent: Color, textColor: Color) {
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var loading by remember { mutableStateOf(false) }
    var player by remember(url) { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(url) {
        onDispose {
            player?.let { runCatching { it.release() } }
            player = null
            if (VoicePlaying.activeUrl == url) VoicePlaying.activeUrl = null
        }
    }
    // Another voice message started: pause this one.
    LaunchedEffect(VoicePlaying.activeUrl) {
        if (VoicePlaying.activeUrl != url && playing) {
            runCatching { player?.pause() }
            playing = false
        }
    }
    LaunchedEffect(playing) {
        while (playing) {
            player?.let { p -> runCatching { if (p.duration > 0) progress = p.currentPosition.toFloat() / p.duration } }
            delay(150)
        }
    }
    fun toggle() {
        val p = player
        if (p != null && !loading) {
            if (playing) { runCatching { p.pause() }; playing = false }
            else { VoicePlaying.activeUrl = url; runCatching { p.start() }; playing = true }
            return
        }
        if (loading) return
        loading = true
        val np = MediaPlayer()
        try {
            np.setDataSource(url)
            np.setOnPreparedListener { mp -> loading = false; VoicePlaying.activeUrl = url; mp.start(); playing = true }
            np.setOnCompletionListener { mp -> playing = false; progress = 0f; runCatching { mp.seekTo(0) } }
            np.setOnErrorListener { _, _, _ -> loading = false; playing = false; true }
            np.prepareAsync()
            player = np
        } catch (_: Throwable) {
            loading = false
            runCatching { np.release() }
        }
    }
    Row(Modifier.width(210.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(accent).clickable { toggle() }, contentAlignment = Alignment.Center) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF08100B), modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = accent, trackColor = textColor.copy(alpha = 0.2f))
            Text(if (loading) "Загрузка…" else label, color = textColor.copy(alpha = 0.75f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
