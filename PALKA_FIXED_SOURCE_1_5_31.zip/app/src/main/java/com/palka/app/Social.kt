package com.palka.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlin.math.sin

// ------------------------------------------------------------------ данные: рамки и стили пузырей

@Serializable data class SocialRow(
    val id: String, val username: String,
    val frame: String = "none", val bubble: String = "default"
)

/** Кто какую рамку/стиль пузырей выбрал (виден всем, обновляется раз в 10 секунд вместе со списком чатов). */
object Social {
    val frameByName = mutableStateMapOf<String, String>()
    val bubbleById = mutableStateMapOf<String, String>()

    suspend fun refresh() {
        val rows = Backend.client!!.from("profiles").select(io.github.jan.supabase.postgrest.query.Columns.list("id", "username", "frame", "bubble")) {
            filter { or { neq("frame", "none"); neq("bubble", "default") } }
            limit(1000)
        }.decodeList<SocialRow>()
        val frames = rows.filter { it.frame != "none" }.associate { it.username to it.frame }
        val bubbles = rows.filter { it.bubble != "default" }.associate { it.id to it.bubble }
        frameByName.keys.retainAll(frames.keys); frameByName.putAll(frames)
        bubbleById.keys.retainAll(bubbles.keys); bubbleById.putAll(bubbles)
    }
}

suspend fun Backend.saveExtras(city: String, showWeather: Boolean, birthdayIso: String?, frame: String, bubble: String) {
    val uid = userId ?: error("Не выполнен вход")
    client!!.from("profiles").update({
        set("city", city)
        set("show_weather", showWeather)
        set("birthday", birthdayIso)
        set("frame", frame)
        set("bubble", bubble)
    }) { filter { eq("id", uid) } }
}

val FRAME_CHOICES = listOf("none" to "Без рамки", "leaves" to "🍃 Листья", "fire" to "🔥 Огонь", "snow" to "❄️ Снег", "gold" to "👑 Золото", "neon" to "💠 Неон")
val BUBBLE_CHOICES = listOf("default" to "Обычный", "paper" to "📜 Бумага", "wood" to "🪵 Дерево", "neon" to "💠 Неон", "glass" to "🫧 Стекло")

// ------------------------------------------------------------------ рамка аватарки

@Composable
fun AvatarFrame(frame: String?, boxSize: Dp, content: @Composable (Dp) -> Unit) {
    if (frame.isNullOrBlank() || frame == "none") { content(boxSize); return }
    val t = rememberInfiniteTransition(label = "frame")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "frameAngle")
    val ringDp = (boxSize.value * 0.08f).coerceAtLeast(3f).dp
    val colors = when (frame) {
        "leaves" -> listOf(Color(0xFF2E7D32), Color(0xFF9CCC65), Color(0xFF1B5E20), Color(0xFF66BB6A), Color(0xFF2E7D32))
        "fire" -> listOf(Color(0xFFFF6F00), Color(0xFFFFD54F), Color(0xFFD50000), Color(0xFFFF9100), Color(0xFFFF6F00))
        "snow" -> listOf(Color(0xFFE3F2FD), Color(0xFF64B5F6), Color.White, Color(0xFF90CAF9), Color(0xFFE3F2FD))
        "gold" -> listOf(Color(0xFFFFD54F), Color(0xFFFFF8E1), Color(0xFFFFB300), Color(0xFFFFE082), Color(0xFFFFD54F))
        else -> listOf(Color(0xFF00E5FF), Color(0xFFD500F9), Color(0xFF00E5FF), Color(0xFFD500F9), Color(0xFF00E5FF))
    }
    val spins = frame == "fire" || frame == "neon" || frame == "gold"
    val deco = when (frame) { "leaves" -> "🍃"; "fire" -> "🔥"; "snow" -> "❄️"; "gold" -> "👑"; else -> "" }
    Box(Modifier.size(boxSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(boxSize)) {
            val sw = ringDp.toPx()
            rotate(if (spins) angle else 0f) {
                drawCircle(brush = Brush.sweepGradient(colors), radius = (this.size.minDimension - sw) / 2f, style = Stroke(sw))
            }
        }
        content(boxSize - ringDp * 2 - 1.dp)
        if (deco.isNotEmpty()) Text(deco, fontSize = (boxSize.value * 0.3f).sp, modifier = Modifier.align(Alignment.TopEnd))
    }
}

/** Аватарка с рамкой, которую выбрал пользователь (ищется по нику). */
@Composable
internal fun Avatar(nick: String, url: String? = null, size: Dp = 46.dp) {
    AvatarFrame(Social.frameByName[nick], size) { inner -> AvatarPlain(nick, url, inner) }
}

// ------------------------------------------------------------------ стиль пузыря

fun Modifier.palkaBubble(style: String?, base: Color, shape: Shape): Modifier = when (style) {
    "wood" -> this.background(Brush.verticalGradient(listOf(Color(0xFF8D6E63), Color(0xFF5D4037))), shape).border(1.dp, Color(0xFF3E2723), shape)
    "paper" -> this.background(Color(0xFF7D6E4F), shape).border(1.dp, Color(0xFFD7C79E), shape)
    "neon" -> this.background(Color(0xFF120B2E), shape).border(1.5.dp, Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFFD500F9))), shape)
    "glass" -> this.background(Color.White.copy(alpha = 0.16f), shape).border(1.dp, Color.White.copy(alpha = 0.4f), shape)
    else -> this.background(base)
}

// ------------------------------------------------------------------ погода

private fun weatherEmoji(code: Int): String = when (code) {
    0 -> "☀️"; 1, 2 -> "🌤"; 3 -> "☁️"; 45, 48 -> "🌫"
    in 51..57 -> "🌦"; in 61..67 -> "🌧"; in 71..77 -> "❄️"; in 80..82 -> "🌧"
    85, 86 -> "🌨"; in 95..99 -> "⛈"; else -> "🌡"
}

/** Текущая погода в городе через Open-Meteo (без ключей). Возвращает, например, "🌤 +5°C, Киев". */
suspend fun fetchWeather(city: String): String? = withContext(Dispatchers.IO) {
    runCatching {
        fun get(u: String): String {
            val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            return c.inputStream.bufferedReader().use { it.readText() }
        }
        val q = java.net.URLEncoder.encode(city.trim(), "UTF-8")
        val results = org.json.JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ru")).optJSONArray("results")
            ?: return@runCatching null
        val r = results.getJSONObject(0)
        val lat = r.getDouble("latitude"); val lon = r.getDouble("longitude")
        val cur = org.json.JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")).getJSONObject("current")
        val t = Math.round(cur.getDouble("temperature_2m")).toInt()
        val sign = if (t > 0) "+" else ""
        "${weatherEmoji(cur.getInt("weather_code"))} $sign$t°C, ${r.optString("name", city)}"
    }.getOrNull()
}

// ------------------------------------------------------------------ день рождения и конфетти

fun isBirthdayToday(iso: String?): Boolean = try {
    if (iso.isNullOrBlank()) false else {
        val d = java.time.LocalDate.parse(iso.take(10)); val n = java.time.LocalDate.now()
        d.monthValue == n.monthValue && d.dayOfMonth == n.dayOfMonth
    }
} catch (_: Throwable) { false }

private class Confetto(val x: Float, val y0: Float, val speed: Float, val phase: Float, val color: Color, val size: Float, val spin: Float)

@Composable
fun ConfettiOverlay(title: String, onDone: () -> Unit) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(7000, easing = LinearEasing)); onDone() }
    val palette = listOf(Color(0xFFFF5252), Color(0xFFFFD740), Color(0xFF69F0AE), Color(0xFF40C4FF), Color(0xFFE040FB), Color(0xFFFFAB40))
    val parts = remember {
        val r = kotlin.random.Random(5)
        List(90) { Confetto(r.nextFloat(), -r.nextFloat() * 0.5f, 0.6f + r.nextFloat() * 0.8f, r.nextFloat() * 6.28f, palette[r.nextInt(palette.size)], 8f + r.nextFloat() * 10f, r.nextFloat() * 360f) }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val p = progress.value
            val alpha = (1f - (p - 0.85f) / 0.15f).coerceIn(0f, 1f)
            parts.forEach { c ->
                val y = (c.y0 + p * c.speed * 1.5f) * size.height
                if (y in -20f..size.height) {
                    val x = c.x * size.width + sin(p * 12f + c.phase) * 24f
                    rotate(c.spin + p * 400f, Offset(x, y)) {
                        drawRect(c.color.copy(alpha = alpha), Offset(x, y), Size(c.size, c.size * 0.55f))
                    }
                }
            }
        }
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 70.dp, start = 24.dp, end = 24.dp)
                .clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 16.dp, vertical = 8.dp))
    }
}

// ------------------------------------------------------------------ экран настроек: город, день рождения, рамка, пузыри

private fun isoToRu(iso: String?): String = try {
    if (iso.isNullOrBlank()) "" else java.time.LocalDate.parse(iso.take(10)).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))
} catch (_: Throwable) { "" }

private fun ruToIso(ru: String): String? = try {
    if (ru.isBlank()) null else java.time.LocalDate.parse(ru.trim(), java.time.format.DateTimeFormatter.ofPattern("d.M.yyyy")).toString()
} catch (_: Throwable) { "bad" }

@Composable
fun ExtrasDialog(me: Profile, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var loaded by remember { mutableStateOf(false) }
    var city by remember { mutableStateOf("") }
    var showWeather by remember { mutableStateOf(false) }
    var birthday by remember { mutableStateOf("") }
    var frame by remember { mutableStateOf("none") }
    var bubble by remember { mutableStateOf("default") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(me.id) {
        val p = runCatching { Backend.profileById(me.id) }.getOrNull() ?: me
        city = p.city; showWeather = p.showWeather; birthday = isoToRu(p.birthday); frame = p.frame; bubble = p.bubble
        loaded = true
    }
    val accent = MaterialTheme.colorScheme.primary
    val text = MaterialTheme.colorScheme.onSurface
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Украшения и данные") },
        confirmButton = {
            TextButton(enabled = loaded && !busy, onClick = {
                val iso = ruToIso(birthday)
                if (iso == "bad") { error = "Дата в формате ДД.ММ.ГГГГ, например 15.03.2005"; return@TextButton }
                busy = true; error = ""
                scope.launch {
                    runCatching { Backend.saveExtras(city.trim(), showWeather && city.isNotBlank(), iso, frame, bubble); Social.refresh() }
                        .onSuccess { onDismiss() }
                        .onFailure { error = "Не удалось сохранить. Выполнен ли update_v13.sql?" }
                    busy = false
                }
            }) { Text("Сохранить", color = accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Рамка аватарки", color = text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                    AvatarFrame(frame, 72.dp) { inner -> AvatarPlain(me.username, me.avatarUrl, inner) }
                }
                ChipRow(FRAME_CHOICES, frame) { frame = it }
                Spacer(Modifier.height(12.dp))
                Text("Мой стиль пузырей (видят все)", color = text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                ChipRow(BUBBLE_CHOICES, bubble) { bubble = it }
                Spacer(Modifier.height(12.dp))
                Text("Город и погода", color = text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(city, { city = it.take(60) }, label = { Text("Город") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Switch(showWeather, { showWeather = it })
                    Spacer(Modifier.size(8.dp))
                    Text("Показывать друзьям погоду в профиле", color = text, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text("День рождения", color = text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(birthday, { birthday = it.take(10) }, label = { Text("ДД.ММ.ГГГГ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("В этот день у друзей в чате с тобой упадут конфетти 🎉", color = androidx.compose.ui.graphics.Color.Gray, fontSize = 11.sp)
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    )
}

@Composable
private fun ChipRow(items: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    val rows = items.chunked(3)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (id, label) ->
                    val sel = id == selected
                    Text(label, color = if (sel) accent else Color.Gray, fontSize = 13.sp, maxLines = 1,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .border(if (sel) 2.dp else 1.dp, if (sel) accent else Color.Gray.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .clickable { onPick(id) }.padding(horizontal = 10.dp, vertical = 7.dp))
                }
            }
        }
    }
}
