package com.palka.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import io.github.jan.supabase.postgrest.postgrest
import kotlin.math.cos
import kotlin.math.sin

/** Состояние костра дружбы в одном чате. */
data class CampfireState(val streak: Int, val best: Int, val totalDays: Int, val todayDone: Boolean, val meToday: Boolean)

suspend fun Backend.campfire(conversationId: String): CampfireState {
    val tzMin = java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
    val r = client!!.postgrest.rpc("palka_campfire", buildJsonObject {
        put("p_conversation", conversationId)
        put("p_tz_min", tzMin)
    })
    val o = Json.parseToJsonElement(r.data).jsonObject
    fun i(k: String) = o[k]?.jsonPrimitive?.intOrNull ?: 0
    fun b(k: String) = o[k]?.jsonPrimitive?.booleanOrNull ?: false
    return CampfireState(i("streak"), i("best"), i("total_days"), b("today_done"), b("me_today"))
}

/** Стадии дерева: с какого количества дней дерево меняется. */
private val TREE_STAGES = listOf(
    0 to "Семечко",
    3 to "Росток",
    7 to "Саженец",
    20 to "Молодое деревце",
    50 to "Крепкое дерево",
    100 to "Могучий дуб",
    200 to "Древний дуб",
    365 to "Священное древо"
)

private fun stageIndex(days: Int): Int = TREE_STAGES.indexOfLast { days >= it.first }.coerceAtLeast(0)

@Composable
fun CampfireDialog(friendName: String, conversationId: String, onDismiss: () -> Unit) {
    var state by remember(conversationId) { mutableStateOf<CampfireState?>(null) }
    var error by remember(conversationId) { mutableStateOf("") }
    LaunchedEffect(conversationId) {
        runCatching { Backend.campfire(conversationId) }
            .onSuccess { state = it }
            .onFailure { error = "Не удалось загрузить костёр. Выполнен ли update_v12.sql?" }
    }
    val days = state?.streak ?: 0
    val stage = stageIndex(days)
    val nextAt = TREE_STAGES.getOrNull(stage + 1)?.first
    val prevAt = TREE_STAGES[stage].first
    val progress = if (nextAt == null) 1f else ((days - prevAt).toFloat() / (nextAt - prevAt)).coerceIn(0f, 1f)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1220), Color(0xFF14261B), Color(0xFF1F2A14))))
        ) {
            Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Костёр дружбы", color = Color(0xFFFFE0B2), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onDismiss) { Text("Закрыть", color = Color(0xFFFFB74D)) }
                }
                Text("с $friendName", color = Color(0xFFB0BEC5), fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))

                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    FriendshipTree(stage = stage, modifier = Modifier.fillMaxSize())
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FireEmoji(active = state?.todayDone == true)
                    Spacer(Modifier.padding(horizontal = 6.dp))
                    Column {
                        Text(if (state == null) "…" else "$days ${dayWord(days)} подряд", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(TREE_STAGES[stage].second, color = Color(0xFFA5D6A7), fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (nextAt != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Color(0xFFFFB74D), trackColor = Color(0x33FFFFFF))
                    Text("До «${TREE_STAGES[stage + 1].second}»: ещё ${nextAt - days} ${dayWord(nextAt - days)}", color = Color(0xFFB0BEC5), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                } else {
                    Text("Дерево выросло до максимума 🌟", color = Color(0xFFFFE082), fontSize = 13.sp)
                }
                Spacer(Modifier.height(10.dp))
                val s = state
                val todayText = when {
                    error.isNotBlank() -> error
                    s == null -> ""
                    s.todayDone -> "Сегодня вы оба написали — огонь горит! 🔥"
                    s.meToday -> "Ты уже написал(а). Ждём $friendName, чтобы засчитать день."
                    s.streak > 0 -> "Напишите оба сегодня, чтобы костёр не погас!"
                    else -> "Напишите друг другу сегодня, и костёр разгорится."
                }
                Text(todayText, color = if (error.isBlank()) Color(0xFFFFE0B2) else Color(0xFFFF9B86), fontSize = 14.sp, textAlign = TextAlign.Center)
                if (s != null) {
                    Spacer(Modifier.height(6.dp))
                    Text("Рекорд: ${s.best} ${dayWord(s.best)} · Всего дней общения: ${s.totalDays}", color = Color(0xFF90A4AE), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(6.dp))
                Text("День засчитывается, когда в чате написали оба.", color = Color(0xFF78909C), fontSize = 11.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

private fun dayWord(n: Int): String {
    val m100 = n % 100
    val m10 = n % 10
    return when {
        m100 in 11..14 -> "дней"
        m10 == 1 -> "день"
        m10 in 2..4 -> "дня"
        else -> "дней"
    }
}

@Composable
private fun FireEmoji(active: Boolean) {
    val t = rememberInfiniteTransition(label = "fire")
    val scale by t.animateFloat(0.92f, 1.12f, infiniteRepeatable(tween(500, easing = LinearEasing), RepeatMode.Reverse), label = "fireScale")
    Text(if (active) "🔥" else "🪵", fontSize = 44.sp, modifier = Modifier.graphicsLayer(scaleX = if (active) scale else 1f, scaleY = if (active) scale else 1f))
}

/** Дерево рисуется кодом; чем выше стадия, тем оно больше, гуще и красивее. */
@Composable
fun FriendshipTree(stage: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "sway")
    val sway by t.animateFloat(-1f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Reverse), label = "swayV")
    val glow by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "glowV")
    Canvas(modifier) { drawTree(stage, sway, glow) }
}

private fun DrawScope.drawTree(stage: Int, sway: Float, glow: Float) {
    val w = size.width
    val h = size.height
    val groundY = h * 0.92f
    val cx = w / 2f
    // земля
    drawOval(Color(0xFF2E4A26), Offset(cx - w * 0.42f, groundY - h * 0.03f), Size(w * 0.84f, h * 0.08f))
    drawOval(Color(0xFF3B5E2F), Offset(cx - w * 0.30f, groundY - h * 0.025f), Size(w * 0.60f, h * 0.055f))

    if (stage == 0) {
        // семечко с маленьким ростком
        drawCircle(Color(0xFF6D4C41), w * 0.03f, Offset(cx, groundY - h * 0.005f))
        drawLine(Color(0xFF66BB6A), Offset(cx, groundY), Offset(cx + sway * 3f, groundY - h * 0.07f), strokeWidth = 5f, cap = StrokeCap.Round)
        drawCircle(Color(0xFF81C784), w * 0.025f, Offset(cx - w * 0.025f + sway * 3f, groundY - h * 0.075f))
        drawCircle(Color(0xFF81C784), w * 0.025f, Offset(cx + w * 0.025f + sway * 3f, groundY - h * 0.08f))
        return
    }

    val trunkH = h * (0.12f + 0.05f * stage)
    val trunkW = w * (0.012f + 0.0105f * stage)
    val topX = cx + sway * w * 0.006f * stage
    val topY = groundY - trunkH
    // ствол
    drawLine(Color(0xFF5D4037), Offset(cx, groundY), Offset(topX, topY), strokeWidth = trunkW, cap = StrokeCap.Round)
    drawLine(Color(0xFF795548), Offset(cx - trunkW * 0.2f, groundY), Offset(topX - trunkW * 0.2f, topY), strokeWidth = trunkW * 0.35f, cap = StrokeCap.Round)

    // ветки
    val branches = (stage - 1).coerceAtLeast(0).coerceAtMost(6)
    for (i in 0 until branches) {
        val f = 0.35f + 0.5f * i / (branches.coerceAtLeast(2) - 1).coerceAtLeast(1)
        val by = groundY - trunkH * f
        val dir = if (i % 2 == 0) -1f else 1f
        val len = w * (0.05f + 0.012f * stage)
        drawLine(Color(0xFF6D4C41), Offset(cx + (topX - cx) * f, by), Offset(cx + (topX - cx) * f + dir * len, by - len * 0.7f + sway * 2f), strokeWidth = trunkW * 0.45f, cap = StrokeCap.Round)
    }

    // крона
    val crownR = w * (0.05f + 0.028f * stage)
    val crownCy = topY - crownR * 0.25f
    val rnd = kotlin.random.Random(7)
    val blobs = 5 + stage * 4
    val greens = listOf(Color(0xFF2E7D32), Color(0xFF388E3C), Color(0xFF43A047), Color(0xFF66BB6A), Color(0xFF1B5E20))
    for (i in 0 until blobs) {
        val a = rnd.nextFloat() * 6.2831f
        val d = rnd.nextFloat() * crownR
        val r = crownR * (0.35f + rnd.nextFloat() * 0.3f)
        val sx = sway * (1f + d / crownR) * 2f
        drawCircle(greens[i % greens.size], r, Offset(topX + cos(a) * d + sx, crownCy + sin(a) * d * 0.8f))
    }
    // осенний / особый оттенок листьев
    if (stage >= 3) {
        val r2 = kotlin.random.Random(11)
        for (i in 0 until stage * 3) {
            val a = r2.nextFloat() * 6.2831f
            val d = r2.nextFloat() * crownR * 0.95f
            drawCircle(Color(0xFF9CCC65), crownR * 0.1f, Offset(topX + cos(a) * d + sway * 3f, crownCy + sin(a) * d * 0.8f))
        }
    }
    // цветы и плоды
    if (stage >= 4) {
        val r3 = kotlin.random.Random(23)
        val bloom = if (stage >= 6) Color(0xFFFFD54F) else Color(0xFFF48FB1)
        for (i in 0 until (stage - 3) * 6) {
            val a = r3.nextFloat() * 6.2831f
            val d = r3.nextFloat() * crownR * 0.95f
            drawCircle(bloom, crownR * 0.06f, Offset(topX + cos(a) * d + sway * 3f, crownCy + sin(a) * d * 0.8f))
        }
    }
    // сияние самого высокого уровня
    if (stage >= 7) {
        drawCircle(Color(0xFFFFE082).copy(alpha = 0.18f * glow), crownR * 1.35f, Offset(topX, crownCy))
        val r4 = kotlin.random.Random(31)
        for (i in 0 until 14) {
            val a = r4.nextFloat() * 6.2831f
            val d = crownR * (1.0f + r4.nextFloat() * 0.5f)
            drawCircle(Color(0xFFFFF59D).copy(alpha = 0.3f + 0.7f * glow), 4f, Offset(topX + cos(a) * d, crownCy + sin(a) * d))
        }
    }
}
