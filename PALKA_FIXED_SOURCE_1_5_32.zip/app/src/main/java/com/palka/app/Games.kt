package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

// ------------------------------------------------------------------ данные

@Serializable data class GameRow(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    val kind: String,
    val p1: String,
    val p2: String,
    val state: JsonObject = JsonObject(emptyMap()),
    val turn: String? = null,
    val status: String = "active"
) {
    fun str(key: String): String? = state[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }
}

/** Создать игру в личном чате (сервер также добавляет карточку-сообщение). */
suspend fun Backend.createGame(conversationId: String, kind: String, state: JsonObject) {
    client!!.postgrest.rpc("palka_game_create", buildJsonObject {
        put("p_conversation", conversationId)
        put("p_kind", kind)
        put("p_state", state)
    })
}

suspend fun Backend.gameById(id: String): GameRow? =
    client!!.from("palka_games").select { filter { eq("id", id) } }.decodeList<GameRow>().firstOrNull()

suspend fun Backend.gameMove(id: String, state: JsonObject, nextTurn: String?, status: String) {
    client!!.postgrest.rpc("palka_game_update", buildJsonObject {
        put("p_id", id)
        put("p_state", state)
        put("p_turn", nextTurn)
        put("p_status", status)
    })
}

fun parseGameBody(body: String): Pair<String, String> {
    val raw = body.removePrefix("game:")
    val i = raw.indexOf('|')
    return if (i < 0) raw to "" else raw.substring(0, i) to raw.substring(i + 1)
}

fun gameTitle(kind: String) = when (kind) { "ttt" -> "Крестики-нолики"; "rps" -> "Камень-ножницы-бумага"; "hang" -> "Виселица"; else -> "Игра" }

// ------------------------------------------------------------------ запуск игры

@Composable
fun GameStartDialog(friendName: String, conversationId: String, onCreated: () -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf<String?>(null) }
    var word by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Игра с $friendName") },
        confirmButton = {
            TextButton(enabled = !busy && kind != null && (kind != "hang" || word.trim().length in 3..12), onClick = {
                val k = kind ?: return@TextButton
                busy = true; error = ""
                val state = when (k) {
                    "ttt" -> buildJsonObject { put("board", "---------") }
                    "hang" -> buildJsonObject { put("word", word.trim().uppercase().replace('Ё', 'Е')); put("guess", "") }
                    else -> buildJsonObject { }
                }
                scope.launch {
                    runCatching { Backend.createGame(conversationId, k, state) }
                        .onSuccess { onCreated(); onDismiss() }
                        .onFailure { error = "Не удалось начать игру. Выполнен ли update_v13.sql?" }
                    busy = false
                }
            }) { Text("Начать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ttt" to "❌⭕ Крестики-нолики", "rps" to "✊✋✌️ Камень-ножницы-бумага", "hang" to "🔤 Виселица (загадай слово)").forEach { (k, label) ->
                    val sel = kind == k
                    Text(label, color = if (sel) MaterialTheme3Primary() else Color.Gray, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(if (sel) Color(0x223DDC84) else Color(0x14FFFFFF))
                            .clickable { kind = k }.padding(12.dp))
                }
                if (kind == "hang") {
                    OutlinedTextField(word, { word = it.filter { c -> c.isLetter() }.take(12) }, label = { Text("Слово (3–12 букв)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Друг будет угадывать его по буквам.", color = Color.Gray, fontSize = 11.sp)
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp)
            }
        }
    )
}

@Composable private fun MaterialTheme3Primary(): Color = androidx.compose.material3.MaterialTheme.colorScheme.primary

// ------------------------------------------------------------------ карточка игры в чате

@Composable
fun GameCard(body: String, myId: String?, friendName: String, accent: Color, textColor: Color) {
    val (kind, id) = parseGameBody(body)
    val scope = rememberCoroutineScope()
    var game by remember(id) { mutableStateOf<GameRow?>(null) }
    var error by remember(id) { mutableStateOf("") }

    fun finished(g: GameRow): Boolean = g.status == "done" || (g.kind == "rps" && g.str("a") != null && g.str("b") != null)

    LaunchedEffect(id) {
        while (id.isNotBlank()) {
            val g = runCatching { Backend.gameById(id) }.getOrNull()
            if (g != null) game = g
            if (g != null && finished(g)) break
            delay(2000)
        }
    }

    fun move(state: JsonObject, nextTurn: String?, status: String) {
        val g = game ?: return
        scope.launch {
            error = ""
            runCatching { Backend.gameMove(g.id, state, nextTurn, status) }
                .onSuccess { runCatching { Backend.gameById(g.id) }.getOrNull()?.let { game = it } }
                .onFailure { error = "Ход не принят" }
        }
    }

    Column(Modifier.width(240.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎮 " + gameTitle(kind), color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        val g = game
        if (g == null || myId == null) {
            Text("Загрузка игры…", color = textColor, fontSize = 13.sp)
        } else {
            val other = if (myId == g.p1) g.p2 else g.p1
            when (g.kind) {
                "ttt" -> TttView(g, myId, other, friendName, accent, textColor, ::move)
                "rps" -> RpsView(g, myId, friendName, accent, textColor, ::move)
                "hang" -> HangView(g, myId, other, friendName, accent, textColor, ::move)
            }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 11.sp)
    }
}

// ---- крестики-нолики

private val TTT_LINES = listOf(
    intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
    intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
    intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
)

private fun tttWinner(b: String): Char? = TTT_LINES.firstOrNull { l -> b[l[0]] != '-' && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]] }?.let { b[it[0]] }

@Composable
private fun TttView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val board = (g.str("board") ?: "---------").padEnd(9, '-')
    val mySym = if (me == g.p1) 'X' else 'O'
    val win = tttWinner(board)
    val full = !board.contains('-')
    val done = win != null || full || g.status == "done"
    val myTurn = !done && g.turn == me
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (r in 0 until 3) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (c in 0 until 3) {
                val i = r * 3 + c
                val ch = board[i]
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.25f))
                    .clickable(enabled = myTurn && ch == '-') {
                        val nb = board.substring(0, i) + mySym + board.substring(i + 1)
                        val w = tttWinner(nb)
                        val f = !nb.contains('-')
                        if (w != null || f) move(buildJsonObject { put("board", nb); put("winner", if (w != null) me else "draw") }, null, "done")
                        else move(buildJsonObject { put("board", nb) }, other, "active")
                    }, contentAlignment = Alignment.Center) {
                    Text(when (ch) { 'X' -> "❌"; 'O' -> "⭕"; else -> "" }, fontSize = 28.sp)
                }
            }
        }
    }
    val status = when {
        win != null -> if (win == mySym) "Ты победил! 🎉" else "Победил $friendName"
        full -> "Ничья 🤝"
        myTurn -> "Твой ход (${if (mySym == 'X') "❌" else "⭕"})"
        else -> "Ход $friendName…"
    }
    Text(status, color = textColor, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
}

// ---- камень-ножницы-бумага

private fun rpsEmoji(c: String?) = when (c) { "R" -> "✊"; "P" -> "✋"; "S" -> "✌️"; else -> "❔" }
private fun rpsBeats(a: String, b: String) = (a == "R" && b == "S") || (a == "S" && b == "P") || (a == "P" && b == "R")

@Composable
private fun RpsView(g: GameRow, me: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val slot = if (me == g.p1) "a" else "b"
    val otherSlot = if (slot == "a") "b" else "a"
    val mine = g.str(slot)
    val theirs = g.str(otherSlot)
    if (mine != null && theirs != null) {
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(rpsEmoji(mine), fontSize = 40.sp); Text("vs", color = textColor, fontSize = 14.sp); Text(rpsEmoji(theirs), fontSize = 40.sp)
        }
        Text(when { mine == theirs -> "Ничья 🤝"; rpsBeats(mine, theirs) -> "Ты победил! 🎉"; else -> "Победил $friendName" }, color = textColor, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
    } else if (mine != null) {
        Text(rpsEmoji(mine), fontSize = 40.sp)
        Text("Выбор сделан. Ждём $friendName…", color = textColor, fontSize = 13.sp)
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("R", "P", "S").forEach { pick ->
                Box(Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = 0.18f)).clickable {
                    move(buildJsonObject { put(slot, pick) }, null, if (theirs != null) "done" else "active")
                }, contentAlignment = Alignment.Center) { Text(rpsEmoji(pick), fontSize = 32.sp) }
            }
        }
        Text(if (theirs != null) "$friendName уже выбрал(а). Твой ход!" else "Сделай выбор — соперник не увидит его", color = textColor, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
    }
}

// ---- виселица

private const val ALPHABET = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
private const val MAX_MISTAKES = 6

@Composable
private fun HangView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val word = g.str("word").orEmpty()
    val guess = g.str("guess").orEmpty()
    val iGuess = me == g.p2
    val mistakes = guess.count { it !in word }
    val won = word.isNotEmpty() && word.all { it in guess }
    val lost = mistakes >= MAX_MISTAKES
    val done = won || lost || g.status == "done"
    val shown = word.map { if (it in guess || (!iGuess && done)) it else '_' }.joinToString(" ")
    Text(shown, color = textColor, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    Text("❤️".repeat((MAX_MISTAKES - mistakes).coerceAtLeast(0)) + "🖤".repeat(mistakes.coerceAtMost(MAX_MISTAKES)), fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
    if (!done && iGuess) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            ALPHABET.chunked(8).forEach { rowLetters ->
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowLetters.forEach { ch ->
                        val used = ch in guess
                        Box(Modifier.size(27.dp).clip(RoundedCornerShape(6.dp))
                            .background(if (used) Color.Black.copy(alpha = 0.25f) else accent.copy(alpha = 0.2f))
                            .clickable(enabled = !used) {
                                val ng = guess + ch
                                val nm = ng.count { it !in word }
                                val w = word.all { it in ng }
                                if (w || nm >= MAX_MISTAKES) move(buildJsonObject { put("guess", ng) }, null, "done")
                                else move(buildJsonObject { put("guess", ng) }, me, "active")
                            }, contentAlignment = Alignment.Center) {
                            Text(ch.toString(), color = if (used) Color.Gray else textColor, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
    Text(
        when {
            won -> if (iGuess) "Ты угадал слово! 🎉" else "$friendName угадал(а) слово"
            lost -> if (iGuess) "Проиграл. Слово было: $word" else "$friendName не угадал(а) 😈"
            iGuess -> "Угадай слово по буквам"
            else -> "Ты загадал(а) «$word». $friendName угадывает…"
        }, color = textColor, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
    )
}
