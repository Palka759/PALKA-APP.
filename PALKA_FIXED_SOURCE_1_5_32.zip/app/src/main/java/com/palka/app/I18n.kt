package com.palka.app

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit

/**
 * Whole-app translation. Every Text(...) in the app goes through [Text] below, which looks the
 * Russian source string up in this dictionary (Russian is the source language, so it is shown as is).
 */
object Translator {
    var current by mutableStateOf("Русский")
    private const val PREFS = "palka_look"

    fun load(c: Context) {
        current = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", "Русский") ?: "Русский"
    }
    fun set(c: Context, language: String) {
        current = language
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", language).apply()
    }

    private val dict = HashMap<String, Array<String>>()
    private fun a(ru: String, en: String, uk: String) { dict[ru] = arrayOf(en, uk) }

    private fun lookup(key: String, idx: Int): String? = dict[key]?.get(idx)

    fun translate(language: String, text: String): String {
        if (language == "Русский" || text.isEmpty()) return text
        val idx = if (language == "Українська") 1 else 0
        lookup(text, idx)?.let { return it }
        val lead = text.takeWhile { it.isWhitespace() }
        val trail = text.takeLastWhile { it.isWhitespace() }
        val core = text.trim()
        if (core.isEmpty()) return text
        if (core != text) lookup(core, idx)?.let { return lead + it + trail }
        // "Заблокировано: 3", "Ответ: ..." -> translate the head only
        val colon = core.indexOf(": ")
        if (colon > 0) lookup(core.substring(0, colon), idx)?.let { return lead + it + core.substring(colon) + trail }
        if (core.endsWith(":")) lookup(core.dropLast(1), idx)?.let { return lead + it + ":" + trail }
        // "Лесная стиль"
        if (core.endsWith(" стиль")) {
            val theme = core.removeSuffix(" стиль")
            val t = lookup(theme, idx) ?: theme
            return lead + t + (if (idx == 0) " style" else " стиль") + trail
        }
        // "Создать (3)"
        val open = core.lastIndexOf(" (")
        if (open > 0 && core.endsWith(")")) lookup(core.substring(0, open), idx)?.let { return lead + it + core.substring(open) + trail }
        // "Вариант 2", "3 подписчиков"
        val sp = core.indexOf(' ')
        if (sp > 0) {
            val head = core.substring(0, sp)
            val tail = core.substring(sp + 1)
            if (head.all { it.isDigit() }) lookup(tail, idx)?.let { return lead + head + " " + it + trail }
            if (head.none { it.isLetterOrDigit() }) lookup(tail, idx)?.let { return lead + head + " " + it + trail }
        }
        val lastSp = core.lastIndexOf(' ')
        if (lastSp > 0 && core.substring(lastSp + 1).all { it.isDigit() } && core.substring(lastSp + 1).isNotEmpty())
            lookup(core.substring(0, lastSp), idx)?.let { return lead + it + core.substring(lastSp) + trail }
        return text
    }

    init {
        // ---- main tabs & settings
        a("Настройки", "Settings", "Налаштування"); a("Тема", "Theme", "Тема"); a("Обои чата", "Chat wallpapers", "Шпалери чату")
        a("Язык", "Language", "Мова"); a("Аккаунт", "Account", "Обліковий запис"); a("Уведомления", "Notifications", "Сповіщення")
        a("Чёрный список", "Blocked users", "Чорний список"); a("Выйти", "Sign out", "Вийти"); a("Главное", "Main", "Головне")
        a("Лесная", "Forest", "Лісова"); a("Тёмная", "Dark", "Темна"); a("Светлая", "Light", "Світла"); a("Осень", "Autumn", "Осінь")
        a("Зима", "Winter", "Зима"); a("Хэллоуин", "Halloween", "Гелловін"); a("Закат", "Sunset", "Захід"); a("Ёлка", "Xmas tree", "Ялинка")
        a("Сакура", "Sakura", "Сакура"); a("Любовь", "Love", "Кохання"); a("Аврора", "Aurora", "Аврора"); a("Неон", "Neon", "Неон"); a("Океан", "Ocean", "Океан")
        a("Выбрана", "Selected", "Обрана"); a("Нажми, чтобы выбрать", "Tap to select", "Натисни, щоб обрати"); a("Назад", "Back", "Назад")
        a("Чаты", "Chats", "Чати"); a("Контакты", "Contacts", "Контакти"); a("Заметки", "Notes", "Нотатки"); a("Профиль", "Profile", "Профіль")
        a("Поиск чатов", "Search chats", "Пошук чатів"); a("Пока нет чатов", "No chats yet", "Поки немає чатів")
        a("Найди друга во вкладке Контакты", "Find a friend in Contacts", "Знайди друга у вкладці Контакти")
        a("Введи ник друга и нажми поиск", "Enter a username and search", "Введи нік друга та натисни пошук")
        a("Мои заметки", "My notes", "Мої нотатки"); a("Сохранить", "Save", "Зберегти"); a("Фото", "Photo", "Фото"); a("Изменить", "Edit", "Змінити")
        a("Палка тут", "Stick is here", "Палка тут"); a("Не в сети", "Offline", "Не в мережі"); a("Выбрать язык", "Select language", "Обрати мову")
        // ---- auth & errors
        a("Не удалось загрузить профиль", "Could not load profile", "Не вдалося завантажити профіль")
        a("Проверь почту и подтверди регистрацию", "Check your email and confirm registration", "Перевір пошту та підтверди реєстрацію")
        a("Не удалось войти", "Could not sign in", "Не вдалося увійти"); a("Подключаемся к PALKA…", "Connecting to PALKA…", "Підключаємось до PALKA…")
        a("Повторить", "Retry", "Повторити"); a("Не удалось сохранить ник", "Could not save username", "Не вдалося зберегти нік")
        a("Ошибка чата", "Chat error", "Помилка чату"); a("Не удалось прочитать фото", "Could not read the photo", "Не вдалося прочитати фото")
        a("Не удалось сохранить профиль", "Could not save profile", "Не вдалося зберегти профіль")
        a("Создать аккаунт", "Create account", "Створити обліковий запис"); a("С возвращением!", "Welcome back!", "З поверненням!")
        a("Только email и пароль. Номер не нужен.", "Just email and password. No phone number needed.", "Лише email і пароль. Номер не потрібен.")
        a("Пароль", "Password", "Пароль"); a("Зарегистрироваться", "Sign up", "Зареєструватися"); a("Войти", "Sign in", "Увійти")
        a("Уже есть аккаунт? Войти", "Already have an account? Sign in", "Вже є акаунт? Увійти")
        a("Нет аккаунта? Регистрация", "No account? Sign up", "Немає акаунта? Реєстрація")
        a("Придумай свой ник", "Choose a username", "Придумай свій нік"); a("По нему тебя смогут найти друзья", "Friends will find you by it", "За ним тебе зможуть знайти друзі")
        a("Например: lesnoy_palka", "For example: lesnoy_palka", "Наприклад: lesnoy_palka"); a("Продолжить", "Continue", "Продовжити")
        // ---- chat list
        a("Все", "All", "Усі"); a("Лесной звонок", "Forest bell", "Лісовий дзвінок"); a("Звонки", "Calls", "Дзвінки"); a("Поиск", "Search", "Пошук")
        a("Личные", "Personal", "Особисті"); a("Группы", "Groups", "Групи"); a("Ничего не найдено", "Nothing found", "Нічого не знайдено")
        a("Групп и каналов пока нет. Нажми + и создай свою", "No groups or channels yet. Tap + to create one", "Груп і каналів поки немає. Натисни + і створи свою")
        a("Пока нет чатов. Нажми + и найди друга по @username", "No chats yet. Tap + and find a friend by @username", "Поки немає чатів. Натисни + і знайди друга за @username")
        a("заметки", "notes", "нотатки"); a("Создать", "Create", "Створити"); a("Новый чат", "New chat", "Новий чат")
        a("Найти канал или группу", "Find a channel or group", "Знайти канал або групу"); a("Новая группа", "New group", "Нова група"); a("Новый канал", "New channel", "Новий канал")
        a("Каналы и группы", "Channels and groups", "Канали та групи"); a("Люди", "People", "Люди"); a("Найти", "Find", "Знайти"); a("Найди друга", "Find a friend", "Знайди друга")
        a("Введи @username и нажми поиск", "Enter @username and search", "Введи @username і натисни пошук")
        a("Название или @адрес", "Title or @handle", "Назва або @адреса")
        a("Публичные каналы и группы появятся здесь", "Public channels and groups will appear here", "Публічні канали та групи з'являться тут")
        a("подписчиков", "subscribers", "підписників"); a("участников", "members", "учасників")
        a("Не удалось вступить", "Could not join", "Не вдалося вступити"); a("Открыть", "Open", "Відкрити"); a("Подписаться", "Subscribe", "Підписатися"); a("Вступить", "Join", "Вступити")
        a("Название канала", "Channel name", "Назва каналу"); a("Название группы", "Group name", "Назва групи")
        a("Публичный (виден в поиске, можно вступить по ссылке-имени)", "Public (visible in search, can be joined by its handle)", "Публічний (видно в пошуку, можна вступити за іменем)")
        a("@адрес (3–32: a-z, 0-9, _)", "@handle (3–32: a-z, 0-9, _)", "@адреса (3–32: a-z, 0-9, _)")
        a("В канале писать можешь только ты. Остальные смогут ставить реакции.", "Only you can post in the channel. Others can react.", "У каналі писати можеш лише ти. Інші зможуть ставити реакції.")
        a("Все участники группы могут писать сообщения.", "All group members can send messages.", "Усі учасники групи можуть писати повідомлення.")
        a("Подписчики (из твоих чатов)", "Subscribers (from your chats)", "Підписники (з твоїх чатів)"); a("Участники (из твоих чатов)", "Members (from your chats)", "Учасники (з твоїх чатів)")
        a("Здесь появятся люди, с которыми ты уже переписывался.", "People you have already chatted with will appear here.", "Тут з'являться люди, з якими ти вже листувався.")
        a("Создаём…", "Creating…", "Створюємо…"); a("Личные заметки", "Private notes", "Особисті нотатки")
        a("Запиши сюда свои мысли...", "Write your thoughts here...", "Запиши сюди свої думки..."); a("Сохранено", "Saved", "Збережено")
        // ---- profile
        a("В лесу… 🌲", "In the forest… 🌲", "У лісі… 🌲"); a("Сообщения", "Messages", "Повідомлення"); a("Друзей", "Friends", "Друзів"); a("Сейчас", "Now", "Зараз")
        a("Изменить профиль", "Edit profile", "Змінити профіль"); a("Пока пусто", "Empty for now", "Поки порожньо"); a("Заблокировано", "Blocked", "Заблоковано")
        a("Блокировки", "Blocked", "Блокування"); a("Оформление", "Appearance", "Оформлення"); a("Включены", "On", "Увімкнено"); a("Выключены", "Off", "Вимкнено")
        a("Завершить текущий сеанс", "End the current session", "Завершити поточний сеанс"); a("Здесь пока никого нет", "Nobody here yet", "Тут поки нікого немає")
        a("Заблокированные пользователи появятся тут", "Blocked users will appear here", "Заблоковані користувачі з'являться тут"); a("Разблокировать", "Unblock", "Розблокувати")
        a("Привет! Как тебе новый вид?", "Hi! How do you like the new look?", "Привіт! Як тобі новий вигляд?"); a("Огонь! 🪵", "Awesome! 🪵", "Вогонь! 🪵")
        a("Обои", "Wallpapers", "Шпалери"); a("Выбрать своё фото из галереи", "Pick your own photo from the gallery", "Обрати своє фото з галереї")
        a("Затемнение обоев", "Wallpaper dimming", "Затемнення шпалер"); a("Размытие своих обоев", "Blur of your wallpaper", "Розмиття своїх шпалер")
        a("Темы приложения", "App themes", "Теми застосунку"); a("Акцентный цвет", "Accent colour", "Акцентний колір"); a("Пузыри сообщений", "Message bubbles", "Бульбашки повідомлень")
        a("Круглые", "Round", "Круглі"); a("Мягкие", "Soft", "М'які"); a("Строгие", "Strict", "Строгі"); a("Размер шрифта в чате", "Chat font size", "Розмір шрифту в чаті")
        a("Применить", "Apply", "Застосувати"); a("Уведомления о сообщениях", "Message notifications", "Сповіщення про повідомлення"); a("Стук палки", "Stick knock", "Стукіт палки")
        a("Тихий", "Silent", "Тихий"); a("Звук уведомлений", "Notification sound", "Звук сповіщень"); a("Вибрация", "Vibration", "Вібрація")
        a("Показывать текст сообщения", "Show message text", "Показувати текст повідомлення"); a("Уведомления в приложении", "In-app notifications", "Сповіщення в застосунку")
        a("Отображать счётчик непрочитанных", "Show unread counter", "Показувати лічильник непрочитаних"); a("Система", "System", "Система")
        a("Системные настройки уведомлений", "System notification settings", "Системні налаштування сповіщень"); a("Разрешение, каналы, звук", "Permission, channels, sound", "Дозвіл, канали, звук")
        a("Работа в фоне", "Background work", "Робота у фоні"); a("Выбери «Не ограничивать» для PALKA", "Choose “Unrestricted” for PALKA", "Обери «Не обмежувати» для PALKA")
        a("Сообщения приходят, пока приложение закрыто, через фоновое соединение (в шторке висит тихое уведомление «Ожидаем новые сообщения»). Если на телефоне включена жёсткая экономия батареи, отключи её для PALKA.",
            "Messages arrive while the app is closed through a background connection (a quiet “Waiting for new messages” notification stays in the shade). If strict battery saving is on, turn it off for PALKA.",
            "Повідомлення приходять, поки застосунок закрито, через фонове з'єднання (у шторці висить тихе сповіщення «Очікуємо нові повідомлення»). Якщо на телефоні ввімкнено жорстку економію батареї, вимкни її для PALKA.")
        a("✓ Выбрана", "✓ Selected", "✓ Обрана"); a("Твой профиль", "Your profile", "Твій профіль"); a("Имя", "Name", "Ім'я")
        a("@username (3–20 символов)", "@username (3–20 characters)", "@username (3–20 символів)"); a("Выбрать из галереи", "Choose from gallery", "Обрати з галереї"); a("Отмена", "Cancel", "Скасувати")
        // ---- chat
        a("Нет сообщений", "No messages", "Немає повідомлень"); a("Заметки ✏️", "Notes ✏️", "Нотатки ✏️"); a("Написать  ›", "Write  ›", "Написати  ›"); a("Ещё", "More", "Ще")
        a("Ответить", "Reply", "Відповісти"); a("Копировать", "Copy", "Копіювати"); a("Переслать", "Forward", "Переслати"); a("Открепить", "Unpin", "Відкріпити")
        a("Закрепить", "Pin", "Закріпити"); a("Удалить", "Delete", "Видалити"); a("Нет ID", "No ID", "Немає ID")
        a("Не удалось поставить реакцию", "Could not add the reaction", "Не вдалося поставити реакцію"); a("Не удалось отправить сообщение", "Could not send the message", "Не вдалося надіслати повідомлення")
        a("Не удалось проголосовать", "Could not vote", "Не вдалося проголосувати"); a("Не удалось включить микрофон", "Could not start the microphone", "Не вдалося ввімкнути мікрофон")
        a("Для голосовых нужен доступ к микрофону", "Voice messages need microphone access", "Для голосових потрібен доступ до мікрофона")
        a("🎤 Голосовое", "🎤 Voice message", "🎤 Голосове"); a("Не удалось отправить голосовое", "Could not send the voice message", "Не вдалося надіслати голосове")
        a("Слишком коротко — держи запись подольше", "Too short — hold the recording longer", "Занадто коротко — тримай запис довше")
        a("Не удалось прочитать файл", "Could not read the file", "Не вдалося прочитати файл"); a("🎥 Видео", "🎥 Video", "🎥 Відео"); a("📷 Фото", "📷 Photo", "📷 Фото")
        a("Не удалось отправить файл", "Could not send the file", "Не вдалося надіслати файл"); a("Не удалось обновить чат", "Could not refresh the chat", "Не вдалося оновити чат")
        a("Переподключение к чату...", "Reconnecting to the chat...", "Перепідключення до чату...")
        a("печатает…", "typing…", "друкує…"); a("в сети", "online", "в мережі"); a("не в сети", "offline", "не в мережі"); a("Звонок", "Call", "Дзвінок")
        a("Подписчики", "Subscribers", "Підписники"); a("Участники", "Members", "Учасники"); a("Заблокировать", "Block", "Заблокувати"); a("Ошибка блокировки", "Block error", "Помилка блокування")
        a("Нет связи с сервером. Повторяем подключение…", "No connection to the server. Retrying…", "Немає зв'язку із сервером. Повторюємо підключення…")
        a("Закреплённое сообщение", "Pinned message", "Закріплене повідомлення"); a("Сообщение откреплено", "Message unpinned", "Повідомлення відкріплено")
        a("Не удалось открепить", "Could not unpin", "Не вдалося відкріпити"); a("Ответ", "Reply", "Відповідь"); a("Вы", "You", "Ви")
        a("Сообщение недоступно", "Message unavailable", "Повідомлення недоступне"); a("Голосовое", "Voice message", "Голосове"); a("Открыть фото", "Open photo", "Відкрити фото")
        a("изменено ·", "edited ·", "змінено ·"); a("Не отправлено, повторяю", "Not sent, retrying", "Не надіслано, повторюю"); a("Отправляется", "Sending", "Надсилається")
        a("Прочитано", "Read", "Прочитано"); a("Отправлено", "Sent", "Надіслано"); a("Кто-то", "Someone", "Хтось"); a("печатает…", "typing…", "друкує…")
        a("Нажмите, чтобы закрыть", "Tap to close", "Натисніть, щоб закрити"); a("Не удалось переслать", "Could not forward", "Не вдалося переслати")
        a("Сообщение закреплено", "Message pinned", "Повідомлення закріплено"); a("Не удалось изменить закрепление", "Could not change the pin", "Не вдалося змінити закріплення")
        a("Ошибка удаления", "Delete error", "Помилка видалення"); a("Запись…", "Recording…", "Запис…"); a("Отправить", "Send", "Надіслати"); a("Эмодзи", "Emoji", "Емодзі")
        a("Изменить сообщение...", "Edit message...", "Змінити повідомлення..."); a("Сообщение...", "Message...", "Повідомлення..."); a("Вложение", "Attachment", "Вкладення")
        a("Фото, видео, GIF", "Photo, video, GIF", "Фото, відео, GIF"); a("Опрос", "Poll", "Опитування"); a("Не удалось изменить сообщение", "Could not edit the message", "Не вдалося змінити повідомлення")
        a("Голосовое сообщение", "Voice message", "Голосове повідомлення")
        a("📢 В канале пишет только владелец. Нажми на сообщение, чтобы поставить реакцию.", "📢 Only the owner posts in this channel. Tap a message to react.", "📢 У каналі пише лише власник. Натисни на повідомлення, щоб поставити реакцію.")
        a("Закрыть", "Close", "Закрити"); a("Диагностика связи", "Connection diagnostics", "Діагностика зв'язку"); a("подключён", "connected", "підключено"); a("нет связи", "no connection", "немає зв'язку")
        a("Готово", "Done", "Готово"); a("Как у всех", "Same as everyone", "Як у всіх"); a("Обои этого чата", "Wallpaper of this chat", "Шпалери цього чату")
        a("Новый опрос", "New poll", "Нове опитування"); a("Вопрос", "Question", "Питання"); a("Вариант", "Option", "Варіант"); a("+ Вариант", "+ Option", "+ Варіант")
        a("владелец", "owner", "власник"); a("Добавить из твоих чатов", "Add from your chats", "Додати з твоїх чатів"); a("Не удалось добавить", "Could not add", "Не вдалося додати")
        a("Добавить", "Add", "Додати"); a("Не удалось выйти", "Could not leave", "Не вдалося вийти"); a("деревянный чат для своих", "a wooden chat for friends", "дерев'яний чат для своїх")
        a("Голосов", "Votes", "Голосів"); a("Загрузка…", "Loading…", "Завантаження…")
        // ---- calls
        a("Звонок завершён", "Call ended", "Дзвінок завершено"); a("Соединение…", "Connecting…", "З'єднання…"); a("Не удалось соединиться", "Could not connect", "Не вдалося з'єднатися")
        a("Абонент занят", "User is busy", "Абонент зайнятий"); a("Звонок отклонён", "Call declined", "Дзвінок відхилено"); a("Входящий звонок", "Incoming call", "Вхідний дзвінок")
        a("Пропущенный звонок", "Missed call", "Пропущений дзвінок"); a("Вызываем…", "Calling…", "Викликаємо…"); a("Нет ответа", "No answer", "Немає відповіді")
        a("Не удалось начать звонок", "Could not start the call", "Не вдалося почати дзвінок")
        a("Не удалось соединиться (сеть блокирует звонок)", "Could not connect (the network blocks the call)", "Не вдалося з'єднатися (мережа блокує дзвінок)")
        a("Плохая связь…", "Poor connection…", "Погана зв'язок…"); a("Входящий звонок PALKA", "Incoming PALKA call", "Вхідний дзвінок PALKA"); a("Отклонить", "Decline", "Відхилити")
        a("Входящие звонки", "Incoming calls", "Вхідні дзвінки"); a("Текущий звонок", "Current call", "Поточний дзвінок"); a("Идёт звонок", "Call in progress", "Триває дзвінок")
        a("Нужен доступ к микрофону для звонков", "Microphone access is needed for calls", "Для дзвінків потрібен доступ до мікрофона")
        a("Включить микрофон", "Unmute", "Увімкнути мікрофон"); a("Выключить микрофон", "Mute", "Вимкнути мікрофон"); a("Динамик вкл", "Speaker on", "Динамік увімк."); a("Динамик выкл", "Speaker off", "Динамік вимк.")
        a("Завершить", "End call", "Завершити"); a("Приём звонков: онлайн", "Receiving calls: online", "Прийом дзвінків: онлайн")
        a("Приём звонков: резервный режим (проверка каждые несколько секунд)", "Receiving calls: backup mode (checks every few seconds)", "Прийом дзвінків: резервний режим (перевірка кожні кілька секунд)")
        a("Звонков пока нет", "No calls yet", "Дзвінків поки немає"); a("Открой личный чат и нажми на трубку вверху", "Open a personal chat and tap the phone at the top", "Відкрий особистий чат і натисни на слухавку вгорі")
        a("Исходящий", "Outgoing", "Вихідний"); a("Пропущенный", "Missed", "Пропущений"); a("Входящий", "Incoming", "Вхідний"); a("· без ответа", "· no answer", "· без відповіді"); a("Позвонить", "Call", "Подзвонити")
        // ---- wallpapers
        a("Чаща", "Thicket", "Хаща"); a("Тропа", "Trail", "Стежка"); a("Поляна", "Glade", "Галявина"); a("Опушка", "Forest edge", "Узлісся"); a("Ночной лес", "Night forest", "Нічний ліс")
        a("Туман", "Fog", "Туман"); a("Дождь", "Rain", "Дощ"); a("Снегопад", "Snowfall", "Снігопад"); a("Светлячки", "Fireflies", "Світлячки"); a("Кристаллы", "Crystals", "Кристали")
        a("Палки", "Sticks", "Палки"); a("Листопад", "Leaf fall", "Листопад"); a("Своё", "Custom", "Своє"); a("Праздники", "Holidays", "Свята")
        a("Северное сияние", "Northern lights", "Північне сяйво"); a("Галактика", "Galaxy", "Галактика"); a("Океан волн", "Ocean waves", "Океан хвиль"); a("Сакура", "Sakura", "Сакура")
        a("Лето", "Summer", "Літо"); a("Неон-город", "Neon city", "Неон-місто"); a("Новый год", "New Year", "Новий рік"); a("Ёлка ✨", "Xmas tree ✨", "Ялинка ✨")
        a("Хэллоуин 🎃", "Halloween 🎃", "Гелловін 🎃"); a("14 февраля", "Feb 14", "14 лютого"); a("8 Марта", "March 8", "8 Березня"); a("Весна", "Spring", "Весна"); a("Дождь из звёзд", "Star rain", "Зоряний дощ")
        // ---- profile card
        a("Профиль пользователя", "User profile", "Профіль користувача"); a("Сообщений всего", "Total messages", "Усього повідомлень"); a("Сообщений в этом чате", "Messages in this chat", "Повідомлень у цьому чаті")
        a("В PALKA с", "In PALKA since", "У PALKA з"); a("Статус", "Status", "Статус"); a("был(а) в сети", "last seen", "був(ла) в мережі"); a("Ранг", "Rank", "Ранг")
        a("Росток 🌱", "Sprout 🌱", "Паросток 🌱"); a("Палка 🪵", "Stick 🪵", "Палка 🪵"); a("Дуб 🌳", "Oak 🌳", "Дуб 🌳"); a("Древний лес 🌲", "Ancient forest 🌲", "Давній ліс 🌲")
        a("Нажми на фото, чтобы открыть", "Tap the photo to open it", "Натисни на фото, щоб відкрити"); a("Нет фото", "No photo", "Немає фото"); a("Ник", "Username", "Нік")
    }
}

/** Drop-in replacement of material3 Text: same parameters, but plain String texts are translated. */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current
) {
    val shown = Translator.translate(Translator.current, text)
    androidx.compose.material3.Text(
        text = shown, modifier = modifier, color = color, fontSize = fontSize, fontStyle = fontStyle,
        fontWeight = fontWeight, fontFamily = fontFamily, letterSpacing = letterSpacing,
        textDecoration = textDecoration, textAlign = textAlign, lineHeight = lineHeight, overflow = overflow,
        softWrap = softWrap, maxLines = maxLines, minLines = minLines, onTextLayout = onTextLayout, style = style
    )
}
