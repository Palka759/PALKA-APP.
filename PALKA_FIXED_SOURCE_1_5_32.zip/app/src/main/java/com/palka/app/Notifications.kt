package com.palka.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/** Notification channels, message notifications and "which chat is open" state. */
object NotificationHelper {
    /** True while MainActivity is on screen (set from onStart/onStop). */
    @Volatile var appVisible = false
    /** Conversation currently open in ChatScreen; no notification is shown for it while visible. */
    @Volatile var openConversationId: String? = null
    /** Set when a notification is tapped: (conversationId, peerId). Consumed by PalkaApp. */
    var pendingOpen by mutableStateOf<Pair<String, String>?>(null)

    private class Line(val text: String, val time: Long, val sender: String)
    private val history = ConcurrentHashMap<String, MutableList<Line>>()

    fun soundKey(name: String) = when (name) { "Стук палки" -> "knock"; "Тихий" -> "silent"; else -> "forest" }
    fun channelId(soundName: String, vibration: Boolean) = "msg_${soundKey(soundName)}_${if (vibration) "v" else "n"}"
    private fun notificationId(conversationId: String) = conversationId.hashCode()

    /** Sound/vibration of a channel cannot change after creation, so one channel exists per combination. */
    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val labels = mapOf("forest" to "Лесной звонок", "knock" to "Стук палки", "silent" to "Тихий")
        for ((key, label) in labels) for (vib in listOf(true, false)) {
            val id = "msg_${key}_${if (vib) "v" else "n"}"
            val ch = NotificationChannel(id, "Сообщения · $label${if (vib) " · вибро" else ""}", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Новые сообщения PALKA"
            ch.enableVibration(vib)
            if (vib) ch.vibrationPattern = longArrayOf(0, 180, 110, 180)
            if (key == "silent") ch.setSound(null, null) else {
                val res = if (key == "knock") "palka_knock" else "palka_forest"
                ch.setSound(
                    Uri.parse("android.resource://${ctx.packageName}/raw/$res"),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            nm.createNotificationChannel(ch)
        }
        val svc = NotificationChannel("palka_service", "Фоновое соединение", NotificationManager.IMPORTANCE_MIN)
        svc.description = "Нужно, чтобы сообщения приходили, когда приложение закрыто"
        svc.setShowBadge(false)
        nm.createNotificationChannel(svc)
    }

    fun settings(ctx: Context, uid: String) = ctx.getSharedPreferences("palka_settings_$uid", Context.MODE_PRIVATE)

    private fun openIntent(ctx: Context, conversationId: String?, peerId: String?): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            action = "palka.open.${conversationId ?: "main"}"
            if (conversationId != null && peerId != null) {
                putExtra("open_conversation", conversationId)
                putExtra("open_peer", peerId)
            }
        }
        return PendingIntent.getActivity(
            ctx, (conversationId ?: "main").hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun serviceNotification(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, "palka_service")
            .setSmallIcon(R.drawable.ic_stat_palka)
            .setContentTitle("PALKA")
            .setContentText("Ожидаем новые сообщения")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openIntent(ctx, null, null))
            .build()

    /** Posts (or updates) the notification of one conversation. [silent] = no sound (used for catch-up). */
    fun showMessage(ctx: Context, uid: String, m: ChatMessage, senderName: String, silent: Boolean = false, groupTitle: String? = null) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val prefs = settings(ctx, uid)
        val showText = prefs.getBoolean("show_text", true)
        val sound = prefs.getString("sound", "Лесной звонок") ?: "Лесной звонок"
        val vibration = prefs.getBoolean("vibration", true)
        val text = if (showText) previewText(m).ifBlank { "Сообщение" } else "Новое сообщение"
        val time = runCatching { parseInstant(m.createdAt ?: "").toEpochMilli() }.getOrDefault(System.currentTimeMillis())

        val lines = history.getOrPut(m.conversationId) { java.util.Collections.synchronizedList(mutableListOf()) }
        lines.add(Line(text, time, senderName))
        while (lines.size > 6) lines.removeAt(0)

        val me = Person.Builder().setName("Я").build()
        val style = NotificationCompat.MessagingStyle(me)
        if (groupTitle != null) { style.conversationTitle = groupTitle; style.isGroupConversation = true }
        synchronized(lines) { lines.forEach { style.addMessage(it.text, it.time, Person.Builder().setName(it.sender).build()) } }

        val n = NotificationCompat.Builder(ctx, channelId(sound, vibration))
            .setSmallIcon(R.drawable.ic_stat_palka)
            .setContentTitle(groupTitle ?: senderName)
            .setContentText(if (groupTitle != null) "$senderName: $text" else text)
            .setStyle(style)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setWhen(time)
            .setColor(0xFF3DDC84.toInt())
            .setSilent(silent)
            .setContentIntent(openIntent(ctx, m.conversationId, m.senderId))
            .build()
        try { NotificationManagerCompat.from(ctx).notify(notificationId(m.conversationId), n) } catch (_: SecurityException) {}
    }

    fun cancelConversation(ctx: Context, conversationId: String) {
        history.remove(conversationId)
        runCatching { NotificationManagerCompat.from(ctx).cancel(notificationId(conversationId)) }
    }

    fun cancelAll(ctx: Context) {
        history.clear()
        runCatching { NotificationManagerCompat.from(ctx).cancelAll() }
    }
}

/**
 * Keeps one Realtime subscription to every incoming message of the signed-in user while the app is
 * closed. This is what makes notifications work without Firebase; Android may still stop it on
 * phones with very aggressive battery savers (battery optimisation should be disabled for PALKA).
 */
class MessageService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val seen = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
    private val names = ConcurrentHashMap<String, String>()
    @Volatile private var blocked: Set<String> = emptySet()
    @Volatile private var blockedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannels(this)
        CallManager.ensureCallChannels(this)
        val n = NotificationHelper.serviceNotification(this)
        if (Build.VERSION.SDK_INT >= 34) startForeground(SERVICE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(SERVICE_ID, n)
        if (job?.isActive != true) job = scope.launch { run() }
        CallManager.start(this) // incoming calls are received while the app is closed too
        return START_STICKY
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private suspend fun run() {
        runCatching { Backend.awaitAuthInitialization() }
        var wait = 2_000L
        while (scope.isActive) {
            val uid = Backend.userId
            if (uid == null || !NotificationHelper.settings(this, uid).getBoolean("notifications", true)) { stopSelf(); return }
            try {
                Backend.watchIncoming(
                    onSubscribed = { wait = 2_000L; catchUp(uid) },
                    onMessage = { m -> handle(uid, m, silent = false) }
                )
            } catch (c: CancellationException) { throw c } catch (_: Throwable) { }
            delay(wait)
            wait = minOf(wait * 2, 30_000L)
        }
    }

    private suspend fun refreshBlocked() {
        if (System.currentTimeMillis() - blockedAt < 5 * 60_000L) return
        blocked = runCatching { Backend.blockedUsers().toSet() }.getOrDefault(blocked)
        blockedAt = System.currentTimeMillis()
    }

    private suspend fun nameOf(id: String): String {
        names[id]?.let { return it }
        val p = runCatching { Backend.profileById(id) }.getOrNull() ?: return "Новое сообщение"
        val n = p.displayName.ifBlank { p.username }
        names[id] = n
        return n
    }

    /** After (re)connecting, show unread messages that arrived while the socket was down — silently. */
    private suspend fun catchUp(uid: String) {
        val since = java.time.Instant.now().minusSeconds(30 * 60).toString()
        val missed = runCatching { Backend.unreadIncomingSince(since) }.getOrDefault(emptyList())
        missed.forEach { handle(uid, it, silent = true) }
    }

    private suspend fun handle(uid: String, m: ChatMessage, silent: Boolean) {
        if (m.senderId == uid) return
        val id = m.id ?: return
        if (!seen.add(id)) return
        if (seen.size > 300) synchronized(seen) { seen.remove(seen.first()) }
        if (!NotificationHelper.settings(this, uid).getBoolean("notifications", true)) return
        if (NotificationHelper.appVisible && NotificationHelper.openConversationId == m.conversationId) return
        refreshBlocked()
        if (m.senderId in blocked) return
        val info = Backend.conversationInfo(m.conversationId)
        val groupTitle = if (info != null && info.kind != "direct") info.title.ifBlank { if (info.kind == "channel") "Канал" else "Группа" } else null
        NotificationHelper.showMessage(this, uid, m, nameOf(m.senderId), silent, groupTitle)
    }

    companion object {
        private const val SERVICE_ID = 7001
        fun start(ctx: Context) {
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, MessageService::class.java)) }
        }
        fun stop(ctx: Context) { runCatching { ctx.stopService(Intent(ctx, MessageService::class.java)) } }
    }
}

/** Restarts the listener after the phone reboots or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val a = intent?.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // The service stops itself if nobody is signed in.
            MessageService.start(context)
        }
    }
}
