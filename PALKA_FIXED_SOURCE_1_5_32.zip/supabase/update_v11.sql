-- PALKA 1.5.29: faster message checks + profile statistics. Run once in the Supabase SQL editor.

create index if not exists messages_sender_idx on public.messages (sender_id);
create index if not exists messages_conv_created_desc_idx on public.messages (conversation_id, created_at desc);
create index if not exists conversation_members_user_idx on public.conversation_members (user_id, conversation_id);

-- Counts of messages for the profile card: total sent by the user and sent inside one shared chat.
create or replace function public.palka_profile_stats(p_user uuid, p_conversation uuid default null)
returns json language sql stable security definer set search_path = '' as $$
  select json_build_object(
    'total', (select count(*) from public.messages m where m.sender_id = p_user),
    'shared', case
      when p_conversation is not null and public.palka_is_member(p_conversation)
        then (select count(*) from public.messages m where m.conversation_id = p_conversation and m.sender_id = p_user)
      else null end
  );
$$;
revoke all on function public.palka_profile_stats(uuid, uuid) from public;
grant execute on function public.palka_profile_stats(uuid, uuid) to authenticated;
