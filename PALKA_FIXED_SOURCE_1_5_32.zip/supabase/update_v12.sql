-- PALKA 1.6.0: Костёр дружбы (серия дней) + Подарки (шишки, магазин, подарки в профиле).
-- Запусти один раз в Supabase SQL Editor (после update_v11.sql).

-- ============================================================ КОСТЁР ДРУЖБЫ
-- День засчитывается, если в этом чате в этот день написали ОБА человека.
-- p_tz_min: смещение часового пояса телефона в минутах (Киев = 120 или 180).
create or replace function public.palka_campfire(p_conversation uuid, p_tz_min int default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
  v_today date := ((now() at time zone 'UTC') + make_interval(mins => p_tz_min))::date;
  v_streak int := 0;
  v_best int := 0;
  v_total int := 0;
  v_today_done boolean := false;
  v_me_today boolean := false;
begin
  if not public.palka_is_member(p_conversation) then
    raise exception 'not a member';
  end if;

  with d as (
    select ((m.created_at at time zone 'UTC') + make_interval(mins => p_tz_min))::date as day
    from public.messages m
    where m.conversation_id = p_conversation
    group by 1
    having count(distinct m.sender_id) >= 2
  ), g as (
    select day, day - (row_number() over (order by day))::int as grp from d
  ), isl as (
    select grp, max(day) as last_day, count(*) as len from g group by grp
  )
  select
    coalesce((select len from isl where last_day >= v_today - 1 order by last_day desc limit 1), 0),
    coalesce((select max(len) from isl), 0),
    coalesce((select count(*) from d), 0),
    exists (select 1 from d where day = v_today)
  into v_streak, v_best, v_total, v_today_done;

  select exists (
    select 1 from public.messages m
    where m.conversation_id = p_conversation and m.sender_id = auth.uid()
      and ((m.created_at at time zone 'UTC') + make_interval(mins => p_tz_min))::date = v_today
  ) into v_me_today;

  return json_build_object('streak', v_streak, 'best', v_best, 'total_days', v_total,
                           'today_done', v_today_done, 'me_today', v_me_today);
end $$;
revoke all on function public.palka_campfire(uuid, int) from public;
grant execute on function public.palka_campfire(uuid, int) to authenticated;

-- ============================================================ ШИШКИ (кошелёк)
create table if not exists public.palka_wallet (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  coins int not null default 300 check (coins >= 0),
  last_bonus date
);
alter table public.palka_wallet enable row level security;
revoke all on public.palka_wallet from anon, authenticated;

create or replace function public.palka_wallet_get()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select coins, last_bonus into v_coins, v_last from public.palka_wallet where user_id = auth.uid();
  return json_build_object('coins', v_coins, 'can_claim', v_last is null or v_last < current_date);
end $$;

create or replace function public.palka_wallet_claim()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select last_bonus into v_last from public.palka_wallet where user_id = auth.uid() for update;
  if v_last is null or v_last < current_date then
    update public.palka_wallet set coins = coins + 50, last_bonus = current_date
      where user_id = auth.uid() returning coins into v_coins;
    return json_build_object('coins', v_coins, 'can_claim', false, 'claimed', 50);
  end if;
  select coins into v_coins from public.palka_wallet where user_id = auth.uid();
  return json_build_object('coins', v_coins, 'can_claim', false, 'claimed', 0);
end $$;

revoke all on function public.palka_wallet_get() from public;
revoke all on function public.palka_wallet_claim() from public;
grant execute on function public.palka_wallet_get() to authenticated;
grant execute on function public.palka_wallet_claim() to authenticated;

-- ============================================================ ПОДАРКИ
create table if not exists public.palka_gift_catalog (
  id text primary key,
  emoji text not null,
  title text not null,
  price int not null check (price > 0),
  sort int not null default 0
);
alter table public.palka_gift_catalog enable row level security;
drop policy if exists "everyone reads gift catalog" on public.palka_gift_catalog;
create policy "everyone reads gift catalog" on public.palka_gift_catalog for select to authenticated using (true);
grant select on public.palka_gift_catalog to authenticated;

insert into public.palka_gift_catalog (id, emoji, title, price, sort) values
  ('mushroom', '🍄', 'Гриб', 10, 1),
  ('leaf',     '🍃', 'Листик', 15, 2),
  ('pine',     '🌲', 'Ёлочка', 25, 3),
  ('stick',    '🪵', 'Палка', 30, 4),
  ('fox',      '🦊', 'Лисёнок', 50, 5),
  ('owl',      '🦉', 'Сова', 80, 6),
  ('spark',    '🔥', 'Искра костра', 100, 7),
  ('bear',     '🐻', 'Медведь', 150, 8),
  ('deer',     '🦌', 'Олень', 250, 9),
  ('rainbow',  '🌈', 'Радуга', 400, 10),
  ('crown',    '👑', 'Корона леса', 1000, 11)
on conflict (id) do update set emoji = excluded.emoji, title = excluded.title, price = excluded.price, sort = excluded.sort;

create table if not exists public.palka_gifts (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  gift_id text not null references public.palka_gift_catalog(id),
  note text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists palka_gifts_to_idx on public.palka_gifts (to_user, created_at desc);
alter table public.palka_gifts enable row level security;
drop policy if exists "gifts are public in profiles" on public.palka_gifts;
create policy "gifts are public in profiles" on public.palka_gifts for select to authenticated using (true);
grant select on public.palka_gifts to authenticated;

-- Купить и подарить: списывает шишки, пишет подарок и отправляет в чат сообщение-подарок.
create or replace function public.palka_send_gift(p_conversation uuid, p_gift text, p_note text default '')
returns json language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  v_other uuid;
  v_price int;
  v_coins int;
  v_note text := left(trim(coalesce(p_note, '')), 200);
  v_msg uuid;
begin
  if v_me is null then raise exception 'not signed in'; end if;
  select case when c.member_one = v_me then c.member_two else c.member_one end into v_other
    from public.conversations c
    where c.id = p_conversation and c.kind = 'direct' and v_me in (c.member_one, c.member_two);
  if v_other is null then raise exception 'Подарок можно отправить только в личный чат'; end if;
  if exists (select 1 from public.user_blocks b
             where (b.blocker_id = v_other and b.blocked_id = v_me) or (b.blocker_id = v_me and b.blocked_id = v_other)) then
    raise exception 'Нельзя отправить подарок: пользователь заблокирован';
  end if;
  select price into v_price from public.palka_gift_catalog where id = p_gift;
  if v_price is null then raise exception 'Такого подарка нет'; end if;

  insert into public.palka_wallet (user_id) values (v_me) on conflict do nothing;
  update public.palka_wallet set coins = coins - v_price where user_id = v_me and coins >= v_price returning coins into v_coins;
  if v_coins is null then raise exception 'Не хватает шишек'; end if;

  insert into public.palka_gifts (from_user, to_user, gift_id, note) values (v_me, v_other, p_gift, v_note);
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'gift:' || p_gift || '|' || v_note, 'gift') returning id into v_msg;

  return json_build_object('coins', v_coins, 'message_id', v_msg);
end $$;
revoke all on function public.palka_send_gift(uuid, text, text) from public;
grant execute on function public.palka_send_gift(uuid, text, text) to authenticated;
