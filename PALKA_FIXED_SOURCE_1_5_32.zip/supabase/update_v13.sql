-- PALKA 1.5.31: погода друга, рамки аватарок, стили пузырей, день рождения (конфетти), мини-игры.
-- Запусти один раз в Supabase SQL Editor (после update_v12.sql).

-- ============================================================ ПРОФИЛЬ: новые поля
alter table public.profiles add column if not exists city text not null default '';
alter table public.profiles add column if not exists show_weather boolean not null default false;
alter table public.profiles add column if not exists birthday date;
alter table public.profiles add column if not exists frame text not null default 'none';
alter table public.profiles add column if not exists bubble text not null default 'default';
-- (права на обновление своего профиля уже есть: "users update own profile")

-- ============================================================ МИНИ-ИГРЫ
create table if not exists public.palka_games (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  kind text not null check (kind in ('ttt', 'rps', 'hang')),
  p1 uuid not null references public.profiles(id) on delete cascade,
  p2 uuid not null references public.profiles(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  turn uuid,
  status text not null default 'active',
  updated_at timestamptz not null default now()
);
create index if not exists palka_games_conv_idx on public.palka_games (conversation_id);
alter table public.palka_games enable row level security;
drop policy if exists "members read games" on public.palka_games;
create policy "members read games" on public.palka_games for select to authenticated
using (public.palka_is_member(conversation_id));
grant select on public.palka_games to authenticated;

-- Начать игру в личном чате: создаёт игру и сообщение-карточку в чате.
create or replace function public.palka_game_create(p_conversation uuid, p_kind text, p_state jsonb default '{}'::jsonb)
returns json language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  v_other uuid;
  v_turn uuid;
  v_id uuid;
begin
  if v_me is null then raise exception 'not signed in'; end if;
  select case when c.member_one = v_me then c.member_two else c.member_one end into v_other
    from public.conversations c
    where c.id = p_conversation and c.kind = 'direct' and v_me in (c.member_one, c.member_two);
  if v_other is null then raise exception 'Игры доступны только в личных чатах'; end if;
  if exists (select 1 from public.user_blocks b
             where (b.blocker_id = v_other and b.blocked_id = v_me) or (b.blocker_id = v_me and b.blocked_id = v_other)) then
    raise exception 'Пользователь заблокирован';
  end if;
  if p_kind not in ('ttt', 'rps', 'hang') then raise exception 'Неизвестная игра'; end if;
  v_turn := case p_kind when 'ttt' then v_me when 'hang' then v_other else null end;
  insert into public.palka_games (conversation_id, kind, p1, p2, state, turn)
    values (p_conversation, p_kind, v_me, v_other, coalesce(p_state, '{}'::jsonb), v_turn) returning id into v_id;
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'game:' || p_kind || '|' || v_id::text, 'game');
  return json_build_object('id', v_id);
end $$;

-- Ход в игре: состояние объединяется (jsonb ||), ход проверяется на сервере.
create or replace function public.palka_game_update(p_id uuid, p_state jsonb, p_turn uuid, p_status text)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_games;
begin
  select * into g from public.palka_games where id = p_id for update;
  if g.id is null or auth.uid() not in (g.p1, g.p2) then raise exception 'Нет доступа к игре'; end if;
  if g.turn is not null and g.turn <> auth.uid() then raise exception 'Сейчас не твой ход'; end if;
  update public.palka_games
     set state = g.state || coalesce(p_state, '{}'::jsonb), turn = p_turn,
         status = coalesce(p_status, g.status), updated_at = now()
   where id = p_id;
end $$;

revoke all on function public.palka_game_create(uuid, text, jsonb) from public;
revoke all on function public.palka_game_update(uuid, jsonb, uuid, text) from public;
grant execute on function public.palka_game_create(uuid, text, jsonb) to authenticated;
grant execute on function public.palka_game_update(uuid, jsonb, uuid, text) to authenticated;
