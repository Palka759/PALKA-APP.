package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

data class PaidInfo(val price: Int, val kind: String, val unlocked: Boolean, val url: String?)

private fun parsePaid(data: String): PaidInfo {
    val o = Json.parseToJsonElement(data).jsonObject
    return PaidInfo(
        o["price"]?.jsonPrimitive?.intOrNull ?: 0,
        o["kind"]?.jsonPrimitive?.contentOrNull ?: "image",
        o["unlocked"]?.jsonPrimitive?.booleanOrNull ?: false,
        runCatching { o["media_url"]?.jsonPrimitive?.contentOrNull }.getOrNull()
    )
}

suspend fun Backend.createPaidPost(conversationId: String, mediaUrl: String, kind: String, price: Int, caption: String) {
    client!!.postgrest.rpc("palka_paid_create", buildJsonObject {
        put("p_conversation", conversationId); put("p_media_url", mediaUrl)
        put("p_kind", kind); put("p_price", price); put("p_caption", caption)
    })
}

suspend fun Backend.paidInfo(messageId: String): PaidInfo =
    parsePaid(client!!.postgrest.rpc("palka_paid_info", buildJsonObject { put("p_message", messageId) }).data)

suspend fun Backend.paidUnlock(messageId: String): PaidInfo =
    parsePaid(client!!.postgrest.rpc("palka_paid_unlock", buildJsonObject { put("p_message", messageId) }).data)

/** Тело сообщения "paid:<image|video>|<цена>|<подпись>". */
private fun parsePaidBody(body: String): Triple<String, Int, String> {
    val parts = body.removePrefix("paid:").split("|", limit = 3)
    return Triple(parts.getOrNull(0) ?: "image", parts.getOrNull(1)?.toIntOrNull() ?: 0, parts.getOrNull(2).orEmpty())
}

/** Диалог владельца канала: цена и подпись к платному посту. */
@Composable
fun PaidPostDialog(onDismiss: () -> Unit, onConfirm: (Int, String) -> Unit) {
    var price by remember { mutableStateOf("25") }
    var caption by remember { mutableStateOf("") }
    val p = price.toIntOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Платный пост 🔒") },
        confirmButton = {
            TextButton(enabled = p != null && p in 1..1000, onClick = { onConfirm(p ?: 25, caption.trim()) }) { Text("Опубликовать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(price, { price = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Цена в шишках (1–1000)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(caption, { caption = it.take(300) }, label = { Text("Подпись (видна всем)") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                Text("Подписчики увидят фото или видео только после оплаты. Шишки получишь ты.", color = Color.Gray, fontSize = 11.sp)
            }
        }
    )
}

@Composable
fun PaidCard(body: String, messageId: String?, accent: Color, textColor: Color) {
    val (kindHint, priceHint, caption) = parsePaidBody(body)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var info by remember(messageId) { mutableStateOf<PaidInfo?>(null) }
    var failed by remember(messageId) { mutableStateOf(false) }
    var error by remember(messageId) { mutableStateOf("") }
    var confirm by remember(messageId) { mutableStateOf(false) }
    var busy by remember(messageId) { mutableStateOf(false) }
    var viewer by remember(messageId) { mutableStateOf<String?>(null) }

    LaunchedEffect(messageId) {
        if (messageId == null || messageId.startsWith("local-")) return@LaunchedEffect
        runCatching { Backend.paidInfo(messageId) }.onSuccess { info = it }.onFailure { failed = true }
    }
    val kind = info?.kind ?: kindHint
    val price = info?.price ?: priceHint

    Column(Modifier.width(230.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val i = info
        if (i != null && i.unlocked && !i.url.isNullOrBlank()) {
            if (kind == "image") {
                AsyncImage(model = i.url, contentDescription = "Платное фото", contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(12.dp)).clickable { viewer = i.url })
            } else {
                Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.4f))
                    .clickable {
                        runCatching {
                            context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(i.url), "video/*"))
                        }
                    }, contentAlignment = Alignment.Center) { Text("▶ Смотреть видео", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(12.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF2B2140), Color(0xFF0F1B2E)))),
                contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔒", fontSize = 34.sp)
                    Text(if (kind == "video") "Платное видео" else "Платное фото", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    if (failed) Text("Недоступно", color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (!failed && messageId != null && !messageId.startsWith("local-")) {
                TextButton(enabled = !busy && i != null, onClick = { confirm = true }) { Text("Открыть за $price 🌰", color = accent, fontWeight = FontWeight.Bold) }
            }
        }
        if (i?.unlocked == true && priceHint > 0) Text("Платный пост · $price 🌰", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        if (caption.isNotBlank()) Text(caption, color = textColor, fontSize = 14.sp, textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp)
    }

    if (confirm && messageId != null) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Открыть за $price 🌰?") },
            text = { Text("Шишки получит автор канала. Доступ останется у тебя навсегда.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false; busy = true; error = ""
                    scope.launch {
                        runCatching { Backend.paidUnlock(messageId) }
                            .onSuccess { info = it }
                            .onFailure { t ->
                                val m = generateSequence(t) { it.cause }.joinToString(" ") { it.message.orEmpty() }
                                error = if (m.contains("Не хватает шишек")) "Не хватает шишек 🌰" else "Не удалось открыть. Проверь интернет и update_v16.sql"
                            }
                        busy = false
                    }
                }) { Text("Открыть") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } }
        )
    }
    viewer?.let { url -> PhotoViewer(url) { viewer = null } }
}
