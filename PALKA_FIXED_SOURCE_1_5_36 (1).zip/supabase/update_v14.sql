-- PALKA 1.5.33: шишки теперь редкие, восстановление огонька (5 в месяц).
-- Запусти один раз в Supabase SQL Editor (после update_v13.sql).

-- ============================================================ ШИШКИ: обнулить у всех
alter table public.palka_wallet alter column coins set default 0;
update public.palka_wallet set coins = 0, last_bonus = null;

-- Шишки: 1 в день, только тем, кто в PALKA 50 дней и дольше (считается с даты регистрации).
create or replace function public.palka_wallet_get()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date; v_age int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select coins, last_bonus into v_coins, v_last from public.palka_wallet where user_id = auth.uid();
  select (current_date - coalesce(created_at, now())::date) into v_age from public.profiles where id = auth.uid();
  v_age := coalesce(v_age, 0);
  return json_build_object('coins', v_coins,
    'can_claim', v_age >= 50 and (v_last is null or v_last < current_date),
    'days_left', greatest(50 - v_age, 0));
end $$;

create or replace function public.palka_wallet_claim()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date; v_age int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select last_bonus into v_last from public.palka_wallet where user_id = auth.uid() for update;
  select (current_date - coalesce(created_at, now())::date) into v_age from public.profiles where id = auth.uid();
  v_age := coalesce(v_age, 0);
  if v_age >= 50 and (v_last is null or v_last < current_date) then
    update public.palka_wallet set coins = coins + 1, last_bonus = current_date
      where user_id = auth.uid() returning coins into v_coins;
    return json_build_object('coins', v_coins, 'can_claim', false, 'days_left', 0, 'claimed', 1);
  end if;
  select coins into v_coins from public.palka_wallet where user_id = auth.uid();
  return json_build_object('coins', v_coins, 'can_claim', false, 'days_left', greatest(50 - v_age, 0), 'claimed', 0);
end $$;

-- ============================================================ ОГОНЁК: восстановление
create table if not exists public.palka_fire_restores (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  day date not null,
  used_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (conversation_id, day)
);
alter table public.palka_fire_restores enable row level security;
revoke all on public.palka_fire_restores from anon, authenticated;

create or replace function public.palka_campfire(p_conversation uuid, p_tz_min int default 0)
returns json language plpgsql stable security definer set search_path = '' as $$
declare
  v_today date := ((now() at time zone 'UTC') + make_interval(mins => p_tz_min))::date;
  v_streak int := 0; v_best int := 0; v_total int := 0;
  v_today_done boolean := false; v_me_today boolean := false;
  v_last date; v_last_len int := 0; v_gap int := 0; v_used int := 0;
begin
  if not public.palka_is_member(p_conversation) then raise exception 'not a member'; end if;

  with d as (
    (select ((m.created_at at time zone 'UTC') + make_interval(mins => p_tz_min))::date as day
       from public.messages m where m.conversation_id = p_conversation
       group by 1 having count(distinct m.sender_id) >= 2)
    union
    (select r.day from public.palka_fire_restores r where r.conversation_id = p_conversation)
  ), g as (
    select day, day - (row_number() over (order by day))::int as grp from d
  ), isl as (
    select grp, max(day) as last_day, count(*) as len from g group by grp
  )
  select
    coalesce((select len from isl where last_day >= v_today - 1 order by last_day desc limit 1), 0),
    coalesce((select max(len) from isl), 0),
    coalesce((select count(*) from d), 0),
    exists (select 1 from d where day = v_today),
    (select max(last_day) from isl),
    coalesce((select len from isl order by last_day desc limit 1), 0)
  into v_streak, v_best, v_total, v_today_done, v_last, v_last_len;

  if v_last is not null and v_last < v_today - 1 then v_gap := v_today - 1 - v_last; end if;

  select exists (
    select 1 from public.messages m
    where m.conversation_id = p_conversation and m.sender_id = auth.uid()
      and ((m.created_at at time zone 'UTC') + make_interval(mins => p_tz_min))::date = v_today
  ) into v_me_today;

  select count(*) into v_used from public.palka_fire_restores r
   where r.used_by = auth.uid() and r.created_at >= date_trunc('month', now());

  return json_build_object('streak', v_streak, 'best', v_best, 'total_days', v_total,
    'today_done', v_today_done, 'me_today', v_me_today,
    'gap', v_gap, 'last_len', v_last_len, 'last_day', v_last,
    'restores_left', greatest(5 - v_used, 0));
end $$;

-- Восстановить все пропущенные дни разом (по 1 восстановлению за день, всего 5 в месяц на человека).
create or replace function public.palka_fire_restore(p_conversation uuid, p_tz_min int default 0)
returns json language plpgsql security definer set search_path = '' as $$
declare
  v_today date := ((now() at time zone 'UTC') + make_interval(mins => p_tz_min))::date;
  j json; v_gap int; v_left int; v_len int; v_last date;
begin
  j := public.palka_campfire(p_conversation, p_tz_min);
  v_gap := (j->>'gap')::int; v_left := (j->>'restores_left')::int;
  v_len := (j->>'last_len')::int; v_last := (j->>'last_day')::date;
  if v_gap <= 0 then raise exception 'Восстанавливать нечего'; end if;
  if v_len < 3 then raise exception 'Серия была слишком короткой'; end if;
  if v_gap > v_left then raise exception 'Не хватает восстановлений'; end if;
  insert into public.palka_fire_restores (conversation_id, day, used_by)
    select p_conversation, d::date, auth.uid() from generate_series(v_last + 1, v_today - 1, interval '1 day') d
    on conflict do nothing;
  return public.palka_campfire(p_conversation, p_tz_min);
end $$;

revoke all on function public.palka_campfire(uuid, int) from public;
revoke all on function public.palka_fire_restore(uuid, int) from public;
grant execute on function public.palka_campfire(uuid, int) to authenticated;
grant execute on function public.palka_fire_restore(uuid, int) to authenticated;
