-- Убрать подарки дешевле 25 (гриб и листик). Уже подаренные остаются в профилях.
alter table public.palka_gift_catalog add column if not exists active boolean not null default true;
update public.palka_gift_catalog set active = false where price < 25;

create or replace function public.palka_send_gift(p_conversation uuid, p_gift text, p_note text default '')
returns json language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid();
  v_other uuid;
  v_price int;
  v_coins int;
  v_note text := left(trim(coalesce(p_note, '')), 200);
  v_msg uuid;
begin
  if v_me is null then raise exception 'not signed in'; end if;
  select case when c.member_one = v_me then c.member_two else c.member_one end into v_other
    from public.conversations c
    where c.id = p_conversation and c.kind = 'direct' and v_me in (c.member_one, c.member_two);
  if v_other is null then raise exception 'Подарок можно отправить только в личный чат'; end if;
  if exists (select 1 from public.user_blocks b
             where (b.blocker_id = v_other and b.blocked_id = v_me) or (b.blocker_id = v_me and b.blocked_id = v_other)) then
    raise exception 'Нельзя отправить подарок: пользователь заблокирован';
  end if;
  select price into v_price from public.palka_gift_catalog where id = p_gift and active;
  if v_price is null then raise exception 'Такого подарка нет'; end if;

  insert into public.palka_wallet (user_id) values (v_me) on conflict do nothing;
  update public.palka_wallet set coins = coins - v_price where user_id = v_me and coins >= v_price returning coins into v_coins;
  if v_coins is null then raise exception 'Не хватает шишек'; end if;

  insert into public.palka_gifts (from_user, to_user, gift_id, note) values (v_me, v_other, p_gift, v_note);
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'gift:' || p_gift || '|' || v_note, 'gift') returning id into v_msg;

  return json_build_object('coins', v_coins, 'message_id', v_msg);
end $$;
revoke all on function public.palka_send_gift(uuid, text, text) from public;
grant execute on function public.palka_send_gift(uuid, text, text) to authenticated;
