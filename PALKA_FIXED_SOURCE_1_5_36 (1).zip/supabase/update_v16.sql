-- PALKA 1.5.35: платные фото/видео в каналах за шишки. Шишки получает владелец канала.
-- Запусти один раз в Supabase SQL Editor (после update_v15.sql).

create table if not exists public.palka_paid_posts (
  message_id uuid primary key references public.messages(id) on delete cascade,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  media_url text not null,
  media_kind text not null check (media_kind in ('image', 'video')),
  price int not null check (price between 1 and 1000)
);
create table if not exists public.palka_paid_unlocks (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (message_id, user_id)
);
-- Прямого доступа к таблицам нет: ссылка на файл выдаётся только после оплаты (через функции ниже).
alter table public.palka_paid_posts enable row level security;
alter table public.palka_paid_unlocks enable row level security;
revoke all on public.palka_paid_posts from anon, authenticated;
revoke all on public.palka_paid_unlocks from anon, authenticated;

-- Владелец канала публикует платный пост.
create or replace function public.palka_paid_create(p_conversation uuid, p_media_url text, p_kind text, p_price int, p_caption text default '')
returns json language plpgsql security definer set search_path = '' as $$
declare v_me uuid := auth.uid(); v_msg uuid; v_cap text := left(trim(coalesce(p_caption, '')), 300);
begin
  if v_me is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from public.conversations c where c.id = p_conversation and c.kind = 'channel' and c.owner_id = v_me) then
    raise exception 'Платные посты может публиковать только владелец канала';
  end if;
  if p_kind not in ('image', 'video') then raise exception 'Неверный тип'; end if;
  if p_price < 1 or p_price > 1000 then raise exception 'Цена от 1 до 1000 шишек'; end if;
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'paid:' || p_kind || '|' || p_price::text || '|' || v_cap, 'paid') returning id into v_msg;
  insert into public.palka_paid_posts (message_id, conversation_id, owner_id, media_url, media_kind, price)
    values (v_msg, p_conversation, v_me, p_media_url, p_kind, p_price);
  return json_build_object('id', v_msg);
end $$;

-- Цена и (если оплачено или ты владелец) ссылка на файл.
create or replace function public.palka_paid_info(p_message uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare p public.palka_paid_posts; v_ok boolean;
begin
  select * into p from public.palka_paid_posts where message_id = p_message;
  if p.message_id is null then raise exception 'Пост не найден'; end if;
  if not public.palka_is_member(p.conversation_id) then raise exception 'Нет доступа'; end if;
  v_ok := p.owner_id = auth.uid()
          or exists (select 1 from public.palka_paid_unlocks u where u.message_id = p_message and u.user_id = auth.uid());
  return json_build_object('price', p.price, 'kind', p.media_kind, 'unlocked', v_ok,
                           'media_url', case when v_ok then p.media_url else null end);
end $$;

-- Оплатить просмотр: шишки списываются у зрителя и зачисляются владельцу канала.
create or replace function public.palka_paid_unlock(p_message uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare p public.palka_paid_posts; v_me uuid := auth.uid(); v_coins int;
begin
  select * into p from public.palka_paid_posts where message_id = p_message;
  if p.message_id is null then raise exception 'Пост не найден'; end if;
  if not public.palka_is_member(p.conversation_id) then raise exception 'Нет доступа'; end if;
  if p.owner_id = v_me
     or exists (select 1 from public.palka_paid_unlocks u where u.message_id = p_message and u.user_id = v_me) then
    return public.palka_paid_info(p_message);
  end if;
  insert into public.palka_wallet (user_id) values (v_me) on conflict do nothing;
  update public.palka_wallet set coins = coins - p.price where user_id = v_me and coins >= p.price returning coins into v_coins;
  if v_coins is null then raise exception 'Не хватает шишек'; end if;
  insert into public.palka_wallet (user_id) values (p.owner_id) on conflict do nothing;
  update public.palka_wallet set coins = coins + p.price where user_id = p.owner_id;
  insert into public.palka_paid_unlocks (message_id, user_id) values (p_message, v_me);
  return json_build_object('price', p.price, 'kind', p.media_kind, 'unlocked', true, 'media_url', p.media_url, 'coins', v_coins);
end $$;

revoke all on function public.palka_paid_create(uuid, text, text, int, text) from public;
revoke all on function public.palka_paid_info(uuid) from public;
revoke all on function public.palka_paid_unlock(uuid) from public;
grant execute on function public.palka_paid_create(uuid, text, text, int, text) to authenticated;
grant execute on function public.palka_paid_info(uuid) to authenticated;
grant execute on function public.palka_paid_unlock(uuid) to authenticated;
