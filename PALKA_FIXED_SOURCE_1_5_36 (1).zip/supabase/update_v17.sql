-- PALKA 1.5.36: таймер до шишек и продажа подарков (20% от цены). Запусти после update_v16.sql.

create or replace function public.palka_wallet_get()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date; v_age int; v_next int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select coins, last_bonus into v_coins, v_last from public.palka_wallet where user_id = auth.uid();
  select (current_date - coalesce(created_at, now())::date) into v_age from public.profiles where id = auth.uid();
  v_age := coalesce(v_age, 0);
  v_next := extract(epoch from (date_trunc('day', now() at time zone 'UTC') + interval '1 day') - (now() at time zone 'UTC'))::int;
  return json_build_object('coins', v_coins,
    'can_claim', v_age >= 50 and (v_last is null or v_last < current_date),
    'days_left', greatest(50 - v_age, 0),
    'next_in_sec', v_next);
end $$;

create or replace function public.palka_wallet_claim()
returns json language plpgsql security definer set search_path = '' as $$
declare v_coins int; v_last date; v_age int; v_next int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  select last_bonus into v_last from public.palka_wallet where user_id = auth.uid() for update;
  select (current_date - coalesce(created_at, now())::date) into v_age from public.profiles where id = auth.uid();
  v_age := coalesce(v_age, 0);
  v_next := extract(epoch from (date_trunc('day', now() at time zone 'UTC') + interval '1 day') - (now() at time zone 'UTC'))::int;
  if v_age >= 50 and (v_last is null or v_last < current_date) then
    update public.palka_wallet set coins = coins + 1, last_bonus = current_date
      where user_id = auth.uid() returning coins into v_coins;
    return json_build_object('coins', v_coins, 'can_claim', false, 'days_left', 0, 'next_in_sec', v_next, 'claimed', 1);
  end if;
  select coins into v_coins from public.palka_wallet where user_id = auth.uid();
  return json_build_object('coins', v_coins, 'can_claim', false, 'days_left', greatest(50 - v_age, 0), 'next_in_sec', v_next, 'claimed', 0);
end $$;

-- Продажа подарка из своего профиля: 20% от цены (25 -> 5), минимум 1.
create or replace function public.palka_sell_gift(p_gift_row uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare v_gift text; v_price int; v_got int; v_coins int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  delete from public.palka_gifts where id = p_gift_row and to_user = auth.uid() returning gift_id into v_gift;
  if v_gift is null then raise exception 'Подарок не найден'; end if;
  select price into v_price from public.palka_gift_catalog where id = v_gift;
  v_got := greatest((coalesce(v_price, 0) * 20) / 100, 1);
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  update public.palka_wallet set coins = coins + v_got where user_id = auth.uid() returning coins into v_coins;
  return json_build_object('coins', v_coins, 'got', v_got);
end $$;
revoke all on function public.palka_sell_gift(uuid) from public;
grant execute on function public.palka_sell_gift(uuid) to authenticated;
