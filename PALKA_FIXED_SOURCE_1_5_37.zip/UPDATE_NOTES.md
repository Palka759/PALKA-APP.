# PALKA 1.5.15

- Reduced Supabase typing writes: one start update per typing burst instead of one write per keystroke.
- Kept optimistic local message rendering and the existing PostgREST message insert path unchanged.
- Left read receipts and media upload behavior unchanged.
- Updated Android version to 1.5.15 and CI archive selection.

Build status: source-level checks only; Android Gradle build must be verified by GitHub Actions.


## 1.5.17
- Corrected the workflow to prefer the exact 1.5.17 source archive, even when an older Android project exists at the repository root.
- Updated the Android version metadata to 1.5.17 (versionCode 17).
- Added server-side Realtime filters for the active conversation's INSERT and UPDATE events.
- Wait for the Realtime subscription before loading initial chat history (with an 8-second fallback when the network is unavailable).

## 1.5.19
- Realtime channel is now unsubscribed/removed when the chat is left or the subscription restarts (it previously leaked forever).
- Each subscription uses a unique channel topic, so re-entering a chat cannot hit a stale channel.
- Realtime rows are decoded with ignoreUnknownKeys, so an unmodelled column can no longer silently drop message events.
- Verified: 1.5.18 source has no `.content` usage; "Unresolved reference: content" came from an older source, not this archive.
Build status: NOT compiled (no Android SDK/network in the review environment).

## 1.5.20
- Fix compile error: PostgresChangeFilter.filter is private in supabase-kt 3.2.3; use filter(column, FilterOperator.EQ, value).
Build status: NOT compiled locally.

## 1.5.21
- New UI following the design mockups: chat list (search, All/Personal/Groups tabs, last message, time, ticks, unread badge, online dot), bottom navigation (Chats / Calls / Profile), chat screen (bubbles, avatars, ticks, typing bubble, reactions + action menu on tap and long-press, pin banner, emoji bar, attach button, round send button), profile, appearance (wallpapers + themes + Apply), notifications settings.
- Groups and calls are placeholders ("coming soon"): there is no backend for them yet.
- Timestamps are parsed with OffsetDateTime first (PostgREST returns "+00:00"), which fixes blank message times / online / typing on runtimes where Instant.parse rejects offsets.
- supabase/update_v8.sql lets the "+" button in the reaction bar use any emoji. Run it once in the Supabase SQL editor.
- System push notifications are still not implemented; the toggles are stored for later.
Build status: NOT compiled locally.

## 1.5.22
- Messenger-style delivery: the sender broadcasts the message over the open Realtime socket (Broadcast) while the INSERT runs in parallel. Message id is generated on the phone, so both copies are deduplicated.
- Read receipts and typing indicator also go over Broadcast (typing no longer writes to the database).
- Realtime status dot in the chat header: green = subscribed, orange = not connected (messages then arrive via the 5 s fallback refresh instead of 15 s).
- Chat history no longer waits up to 8 s for the Realtime subscription (1.5 s).
- Note: Broadcast topics are public to anyone who knows the (random UUID) channel name; the database copy remains protected by RLS.
Build status: NOT compiled locally.

## 1.5.23
- System notifications with sound for new messages, also when the app is closed (no Firebase needed): a foreground service (`MessageService`) keeps one Realtime subscription to all incoming messages; unread messages from the last 30 min are shown silently after a reconnect.
- Sounds: `palka_forest` (Лесной звонок), `palka_knock` (Стук палки), «Тихий». One notification channel per sound/vibration combination. The sound is previewed when you switch it in Settings.
- No notification for the chat that is currently open; notifications of a chat are cleared when it is opened. Tap on a notification opens that chat.
- Settings: notifications toggle starts/stops the service; shortcuts to system notification settings and battery optimisation.
- Restarts after reboot/update (BootReceiver). Stops on sign-out.
- Workflow now picks the newest PALKA_FIXED_SOURCE_<version>.zip and checks its version against build.gradle.kts.
Build status: NOT compiled locally (no Android SDK/network here); verify with GitHub Actions.

## 1.5.24
- Groups and channels. Create via the green "+" button (New chat / New group / New channel). Members are picked from people you already chat with; the owner can add more later via the chat header (members dialog).
- Group: everyone writes. Channel: only the owner writes, subscribers can only react (input is replaced by a banner; reply/forward/pin hidden for them).
- Groups show sender names and avatars in bubbles; unread counters use a per-member read marker (conversation_members.last_read_at). Direct chats are unchanged (read_at ticks).
- Notifications show the group title and "sender: text".
- Chat-list filter "Личные" now shows direct chats only, "Группы" shows groups and channels.
- REQUIRED: run supabase/update_v9.sql once in the Supabase SQL Editor. Without it the app works as before, but creating groups fails.
- Calls: not part of this release.
Build status: NOT compiled locally.

## 1.5.25
- Voice calls (1-to-1, from a direct chat: phone button in the header). Incoming call screen (answer / decline), in-call screen with mute microphone, speaker on/off, hang up and a timer. "Calls" tab shows history and lets you call back. Incoming calls ring also when the app is in the background (notification, uses the existing background service). Audio goes peer-to-peer (WebRTC, library io.getstream:stream-webrtc-android); signalling goes through the RLS-protected table `call_signals`.
- Only people you already have a direct chat with can call you (and not if you blocked them).
- Only Google STUN servers are built in. If calls do not connect on some mobile networks, add a TURN server: GitHub secrets TURN_URL, TURN_USER, TURN_PASS (optional).
- Public groups and channels: when creating, switch "Публичный" and choose a unique @handle. "+" -> "Найти канал или группу" (or the "Каналы и группы" tab in search) lists/searches public chats by title or @handle; anyone can join without having written to the owner.
- REQUIRED: run supabase/update_v10.sql once in the Supabase SQL Editor (after update_v9.sql).
- Not included: video calls, group calls.
Build status: NOT compiled locally (no Android SDK/network in the review environment); verify with GitHub Actions.

## 1.5.26
- Fix compile error in Calls.kt (CallService): `flags` inside Intent.apply referred to onStartCommand's parameter; now uses addFlags().

## 1.5.27
- Incoming calls were not delivered on some phones: added a backup path. Signals addressed to the user are polled every 1 s during a call, 2.5 s while the app is open and 5 s in the background, in addition to Realtime (each signal is handled once). Calls tab shows "Приём звонков: онлайн / резервный режим".
- Incoming-call notification now has a "Отклонить" button; tapping it opens the answer screen.

## 1.5.28
Messages
- Sending never loses a message: the bubble shows a clock while sending, a red "!" if the network is down, and is re-sent automatically (every 3 s and the moment the network returns). A re-send that already reached the server is recognised (same id), no duplicates. Sending continues even if you leave the chat.
- Realtime reconnects immediately when the phone switches Wi-Fi <-> mobile data.
- "Диагностика связи": tap the small status dot in a chat header to see real numbers (channel connect time, INSERT time, echo time, lag from the peer). Use it to measure instead of guessing.
- Voice messages: tap the microphone (when the text field is empty), tap send/cancel. Recorded as m4a, played in the bubble with progress; only one plays at a time.
- Stickers: open the emoji panel, 16 "PALKA" stickers below the emoji row.
- GIF: send from the paperclip menu; GIFs now animate (coil-gif).
- Polls in groups: paperclip -> "Опрос" (2-6 options). Votes use the existing reactions table ("poll:N"), no new SQL needed. Results refresh every ~5 s.
- Message edit already existed ("изменено" label); unchanged.
Look
- 13 wallpapers (4 photos + drawn scenes: night forest, fog, rain, sunset, snow, fireflies, crystal cave, sticks, leaves; rain/snow/fireflies/leaves are animated) + your own photo from the gallery with dimming and blur sliders.
- Per-chat wallpaper: chat menu -> "Обои чата".
- 7 themes (Лесная, Тёмная, Светлая, Осень, Зима, Хэллоуин, Закат), 6 accent colours, 3 bubble shapes, font size. Live preview in Settings -> Оформление.
- REQUIRED SQL: none. (update_v8.sql from 1.5.21 must already be applied: it lets reactions hold "poll:N".)
Build status: NOT compiled locally (no Android SDK/network in the review environment); verify with GitHub Actions.

## 1.5.29
- Messages: 0.8 s cheap polling of the newest message id as a safety net next to Realtime/Broadcast; chat history now loads the NEWEST 200 messages (was the oldest 200).
- Profile card on avatar tap (chat header and message avatars): name, @nick, status, total messages, messages in this chat, rank, join date. Tap the avatar inside the card for a full-screen zoomable photo. Needs supabase/update_v11.sql.
- Whole-app translation (en/uk) through a Text wrapper + dictionary (I18n.kt).
- 13 new wallpapers (aurora, galaxy, ocean, star rain, neon, summer, spring, sakura, New Year, Xmas tree, Halloween, Feb 14, March 8), all animated.
- 6 new themes (Ёлка, Сакура, Любовь, Аврора, Неон, Океан); animated particle overlay for 10 themes.
Build status: NOT compiled locally.

## 1.5.30 (часть 1)
- Костёр дружбы: чат -> меню "⋮" -> "Костёр дружбы 🔥". День засчитывается, когда в чате написали оба. Дерево растёт на 3 / 7 / 20 / 50 / 100 / 200 / 365 днях подряд.
- Подарки: магазин (меню "⋮" в чате или карточка профиля -> "Подарить 🎁"), текст к подарку, сообщение-подарок в чате, полка подарков в профиле. Валюта — шишки 🌰 (старт 300, +50 в день). Профиль -> "Мои подарки".
- REQUIRED: run supabase/update_v12.sql once in the Supabase SQL Editor (after update_v11.sql).
Build status: NOT compiled locally.

## 1.5.31 (часть 2)
- Погода друга в профиле (Open-Meteo, город и переключатель в Профиль -> "Рамка, пузыри, город").
- Мини-игры в личном чате: скрепка -> "Игра 🎮": крестики-нолики, камень-ножницы-бумага, виселица.
- Рамки аватарок (листья, огонь, снег, золото, неон; анимированные) и свой стиль пузырей (бумага, дерево, неон, стекло) - их видят все.
- День рождения: конфетти при открытии чата в день рождения друга (или свой).
- REQUIRED: run supabase/update_v13.sql once (after update_v12.sql).
Build status: NOT compiled locally.

## 1.5.32
- Fix compile error: missing MaterialTheme import in Gifts.kt and Social.kt.

## 1.5.33
- Шишки обнулены; 1 шишка в день только для аккаунтов старше 50 дней.
- Восстановление огонька: 5 в месяц на человека.
- Рамка/пузыри/город перенесены в Профиль -> Оформление.
- REQUIRED: supabase/update_v14.sql (после v13).

## 1.5.34
- Подарки дешевле 25 убраны из магазина (update_v15.sql).

## 1.5.35
- Платные фото/видео в каналах за шишки (владелец канала: скрепка -> "Платное фото/видео"). Шишки получает владелец. REQUIRED: update_v16.sql.

## 1.5.36
- Таймеры шишек (до начала получения и до следующей шишки), продажа подарков за 20% цены. REQUIRED: update_v17.sql.

## 1.5.37
- Игры: шахматы (подсказки ходов, ходы соперника, угрозы), морской бой, угадай число; ставки до 3 шишек. REQUIRED: update_v18.sql.
