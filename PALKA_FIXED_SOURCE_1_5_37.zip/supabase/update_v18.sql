-- PALKA 1.5.37: морской бой, шахматы, угадай число + ставки шишками (до 3). Запусти после update_v17.sql.

alter table public.palka_games drop constraint if exists palka_games_kind_check;
alter table public.palka_games add constraint palka_games_kind_check check (kind in ('ttt', 'rps', 'hang', 'bs', 'chess', 'guess'));
alter table public.palka_games add column if not exists stake int not null default 0 check (stake between 0 and 3);
alter table public.palka_games add column if not exists accepted boolean not null default true;
alter table public.palka_games add column if not exists settled boolean not null default false;

drop function if exists public.palka_game_create(uuid, text, jsonb);
create or replace function public.palka_game_create(p_conversation uuid, p_kind text, p_state jsonb default '{}'::jsonb, p_stake int default 0)
returns json language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid(); v_other uuid; v_turn uuid; v_id uuid; v_coins int;
begin
  if v_me is null then raise exception 'not signed in'; end if;
  select case when c.member_one = v_me then c.member_two else c.member_one end into v_other
    from public.conversations c
    where c.id = p_conversation and c.kind = 'direct' and v_me in (c.member_one, c.member_two);
  if v_other is null then raise exception 'Игры доступны только в личных чатах'; end if;
  if exists (select 1 from public.user_blocks b
             where (b.blocker_id = v_other and b.blocked_id = v_me) or (b.blocker_id = v_me and b.blocked_id = v_other)) then
    raise exception 'Пользователь заблокирован';
  end if;
  if p_kind not in ('ttt', 'rps', 'hang', 'bs', 'chess', 'guess') then raise exception 'Неизвестная игра'; end if;
  if p_stake < 0 or p_stake > 3 then raise exception 'Ставка от 0 до 3 шишек'; end if;
  v_turn := case p_kind when 'ttt' then v_me when 'chess' then v_me when 'hang' then v_other when 'guess' then v_other else null end;
  if p_stake > 0 then
    insert into public.palka_wallet (user_id) values (v_me) on conflict do nothing;
    update public.palka_wallet set coins = coins - p_stake where user_id = v_me and coins >= p_stake returning coins into v_coins;
    if v_coins is null then raise exception 'Не хватает шишек'; end if;
  end if;
  insert into public.palka_games (conversation_id, kind, p1, p2, state, turn, stake, accepted)
    values (p_conversation, p_kind, v_me, v_other, coalesce(p_state, '{}'::jsonb), v_turn, p_stake, p_stake = 0) returning id into v_id;
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'game:' || p_kind || '|' || v_id::text, 'game');
  return json_build_object('id', v_id);
end $$;

create or replace function public.palka_game_update(p_id uuid, p_state jsonb, p_turn uuid, p_status text)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_games;
begin
  select * into g from public.palka_games where id = p_id for update;
  if g.id is null or auth.uid() not in (g.p1, g.p2) then raise exception 'Нет доступа к игре'; end if;
  if not g.accepted or g.settled then raise exception 'Игра недоступна'; end if;
  if g.turn is not null and g.turn <> auth.uid() then raise exception 'Сейчас не твой ход'; end if;
  update public.palka_games
     set state = g.state || coalesce(p_state, '{}'::jsonb), turn = p_turn,
         status = coalesce(p_status, g.status), updated_at = now()
   where id = p_id;
end $$;

-- Соперник принимает ставку (списывается его ставка).
create or replace function public.palka_game_accept(p_id uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare g public.palka_games; v_coins int;
begin
  select * into g from public.palka_games where id = p_id for update;
  if g.id is null or auth.uid() <> g.p2 then raise exception 'Нет доступа к игре'; end if;
  if g.settled then raise exception 'Игра отменена'; end if;
  if g.accepted then return json_build_object('ok', true); end if;
  insert into public.palka_wallet (user_id) values (auth.uid()) on conflict do nothing;
  update public.palka_wallet set coins = coins - g.stake where user_id = auth.uid() and coins >= g.stake returning coins into v_coins;
  if v_coins is null then raise exception 'Не хватает шишек'; end if;
  update public.palka_games set accepted = true, updated_at = now() where id = p_id;
  return json_build_object('ok', true);
end $$;

-- Создатель отменяет игру, пока ставку не приняли: ставка возвращается.
create or replace function public.palka_game_cancel(p_id uuid)
returns json language plpgsql security definer set search_path = '' as $$
declare g public.palka_games;
begin
  select * into g from public.palka_games where id = p_id for update;
  if g.id is null or auth.uid() <> g.p1 then raise exception 'Нет доступа к игре'; end if;
  if g.accepted or g.settled then raise exception 'Отменить нельзя'; end if;
  update public.palka_wallet set coins = coins + g.stake where user_id = g.p1;
  update public.palka_games set settled = true, status = 'done', updated_at = now() where id = p_id;
  return json_build_object('ok', true);
end $$;

-- Расчёт ставки: проигравший сам признаёт поражение ('concede') -> победитель получает обе ставки; ничья ('draw') -> ставки возвращаются.
create or replace function public.palka_game_settle(p_id uuid, p_result text)
returns json language plpgsql security definer set search_path = '' as $$
declare g public.palka_games; v_winner uuid;
begin
  select * into g from public.palka_games where id = p_id for update;
  if g.id is null or auth.uid() not in (g.p1, g.p2) then raise exception 'Нет доступа к игре'; end if;
  if g.stake = 0 or g.settled or not g.accepted then return json_build_object('settled', false); end if;
  if p_result = 'draw' then
    update public.palka_wallet set coins = coins + g.stake where user_id in (g.p1, g.p2);
  elsif p_result = 'concede' then
    v_winner := case when auth.uid() = g.p1 then g.p2 else g.p1 end;
    insert into public.palka_wallet (user_id) values (v_winner) on conflict do nothing;
    update public.palka_wallet set coins = coins + g.stake * 2 where user_id = v_winner;
  else
    raise exception 'Неверный результат';
  end if;
  update public.palka_games set settled = true, status = 'done', updated_at = now() where id = p_id;
  return json_build_object('settled', true);
end $$;

revoke all on function public.palka_game_create(uuid, text, jsonb, int) from public;
revoke all on function public.palka_game_update(uuid, jsonb, uuid, text) from public;
revoke all on function public.palka_game_accept(uuid) from public;
revoke all on function public.palka_game_cancel(uuid) from public;
revoke all on function public.palka_game_settle(uuid, text) from public;
grant execute on function public.palka_game_create(uuid, text, jsonb, int) to authenticated;
grant execute on function public.palka_game_update(uuid, jsonb, uuid, text) to authenticated;
grant execute on function public.palka_game_accept(uuid) to authenticated;
grant execute on function public.palka_game_cancel(uuid) to authenticated;
grant execute on function public.palka_game_settle(uuid, text) to authenticated;
