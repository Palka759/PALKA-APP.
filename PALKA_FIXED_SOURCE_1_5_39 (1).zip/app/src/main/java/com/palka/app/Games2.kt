package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

// ================================================================== УГАДАЙ ЧИСЛО

private const val GUESS_MAX_TRIES = 7

@Composable
internal fun GuessView(g: GameRow, me: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val secret = g.str("secret")?.toIntOrNull() ?: 0
    val tries = g.str("tries").orEmpty().split(",").mapNotNull { it.trim().toIntOrNull() }
    val iGuess = me == g.p2
    val won = secret in tries
    val lost = !won && tries.size >= GUESS_MAX_TRIES
    val done = won || lost
    var input by remember(g.id) { mutableStateOf("") }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (iGuess) "Загадано число от 1 до 100" else "Ты загадал(а): $secret", color = textColor, fontSize = 13.sp)
        Text("Попыток осталось: ${(GUESS_MAX_TRIES - tries.size).coerceAtLeast(0)}", color = textColor, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        tries.forEach { t ->
            val okT = t == secret
            Text("$t  " + when { okT -> "✅ верно!"; t < secret -> "⬆ больше"; else -> "⬇ меньше" }, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 2.dp).width(170.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (okT) Color(0x333DDC84) else Color.White.copy(alpha = 0.08f)).padding(vertical = 5.dp))
        }
        Spacer(Modifier.height(4.dp))
        if (!done && iGuess) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it.filter { c -> c.isDigit() }.take(3) }, singleLine = true, label = { Text("Число") }, modifier = Modifier.width(110.dp))
                TextButton(enabled = input.toIntOrNull()?.let { it in 1..100 } == true, onClick = {
                    val n = input.toInt()
                    val d = n == secret || tries.size + 1 >= GUESS_MAX_TRIES
                    move(buildJsonObject { put("tries", (tries + n).joinToString(",")) }, if (d) null else me, if (d) "done" else "active")
                    input = ""
                }) { Text("Ок", color = accent) }
            }
        }
        Text(
            when {
                won -> if (iGuess) "Ты угадал! 🎉" else "$friendName угадал(а) число"
                lost -> if (iGuess) "Не угадал. Было: $secret" else "$friendName не угадал(а) 😈"
                iGuess -> "Угадывай!"
                else -> "$friendName угадывает…"
            }, color = textColor, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

// ================================================================== МОРСКОЙ БОЙ

private val BS_SIZES = listOf(4, 3, 3, 2, 2)

private fun randomFleet(): String {
    val rnd = kotlin.random.Random(System.nanoTime())
    while (true) {
        val b = CharArray(64) { '.' }
        var ok = true
        for ((id, len) in BS_SIZES.withIndex()) {
            var placed = false
            var tries = 0
            while (!placed && tries < 200) {
                tries++
                val horiz = rnd.nextBoolean()
                val r = rnd.nextInt(if (horiz) 8 else 9 - len)
                val c = rnd.nextInt(if (horiz) 9 - len else 8)
                val cells = (0 until len).map { if (horiz) r * 8 + c + it else (r + it) * 8 + c }
                if (cells.all { b[it] == '.' }) { cells.forEach { b[it] = '0' + id }; placed = true }
            }
            if (!placed) { ok = false; break }
        }
        if (ok) return String(b)
    }
}

@Composable
private fun BsBoard(cell: (Int) -> Pair<String, Color>, cellSize: Dp, fontSp: Int, onClick: ((Int) -> Unit)?) {
    Column(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(10.dp)), verticalArrangement = Arrangement.spacedBy(1.dp)) {
        for (r in 0 until 8) Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
            for (c in 0 until 8) {
                val i = r * 8 + c
                val (t, bg) = cell(i)
                Box(Modifier.size(cellSize).background(bg).then(if (onClick != null) Modifier.clickable { onClick(i) } else Modifier), contentAlignment = Alignment.Center) {
                    Text(t, color = Color.White, fontSize = fontSp.sp)
                }
            }
        }
    }
}

private val WATER = Color(0xFF1E3A5F)
private val SHIP = Color(0xFF78909C)
private val HIT = Color(0xFFC62828)

@Composable
internal fun BsView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val slot = if (me == g.p1) "1" else "2"
    val oslot = if (slot == "1") "2" else "1"
    val myShips = g.str("sp$slot")
    val theirShips = g.str("sp$oslot")
    val winner = g.str("winner")
    var cand by remember(g.id) { mutableStateOf(randomFleet()) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (myShips == null) {
            Text("Расставь корабли", color = textColor, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            BsBoard({ i -> (if (cand[i] != '.') "" to SHIP else "" to WATER) }, 28.dp, 14, null)
            Row {
                TextButton(onClick = { cand = randomFleet() }) { Text("🎲 Перемешать", color = accent) }
                TextButton(onClick = { move(buildJsonObject { put("sp$slot", cand) }, if (theirShips != null) g.p1 else null, "active") }) { Text("✅ Готов", color = accent) }
            }
        } else if (theirShips == null) {
            BsBoard({ i -> (if (myShips[i] != '.') "" to SHIP else "" to WATER) }, 28.dp, 14, null)
            Text("Флот готов. Ждём $friendName…", color = textColor, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        } else {
            val myShots = g.str("sh$slot") ?: ".".repeat(64)
            val theirShots = g.str("sh$oslot") ?: ".".repeat(64)
            val myTurn = winner == null && (g.turn ?: g.p1) == me
            val sunk = BS_SIZES.indices.map { '0' + it }.filter { id -> theirShips.indices.none { theirShips[it] == id && myShots[it] != 'x' } }.toSet()
            Text(if (winner != null) "" else if (myTurn) "Твой выстрел по флоту $friendName" else "Стреляет $friendName…", color = textColor, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
            BsBoard({ i ->
                when {
                    myShots[i] == 'x' && theirShips[i] in sunk -> "☠" to Color(0xFF4E1010)
                    myShots[i] == 'x' -> "💥" to HIT
                    myShots[i] == 'o' -> "•" to WATER
                    else -> "" to WATER
                }
            }, 28.dp, 14, if (myTurn) ({ i: Int ->
                if (myShots[i] == '.') {
                    val hit = theirShips[i] != '.'
                    val ns = myShots.substring(0, i) + (if (hit) 'x' else 'o') + myShots.substring(i + 1)
                    val total = theirShips.count { it != '.' }
                    val hits = theirShips.indices.count { theirShips[it] != '.' && ns[it] == 'x' }
                    if (hits == total) move(buildJsonObject { put("sh$slot", ns); put("winner", me) }, null, "done")
                    else move(buildJsonObject { put("sh$slot", ns) }, if (hit) me else other, "active")
                }
            }) else null)
            Text("Твой флот", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
            BsBoard({ i ->
                when {
                    myShips[i] != '.' && theirShots[i] == 'x' -> "💥" to HIT
                    myShips[i] != '.' -> "" to SHIP
                    theirShots[i] == 'o' -> "•" to WATER
                    else -> "" to WATER
                }
            }, 16.dp, 9, null)
            if (winner != null) Text(if (winner == me) "Ты потопил весь флот! 🎉" else "Победил $friendName", color = textColor, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            else Text("Попал — стреляешь ещё раз", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

// ================================================================== ШАХМАТЫ

internal const val CHESS_START = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR"

private data class ChessState(val board: String, val castle: String, val ep: Int)

private object ChessEngine {
    private val KN = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
    private val KG = listOf(-1 to -1, -1 to 0, -1 to 1, 0 to -1, 0 to 1, 1 to -1, 1 to 0, 1 to 1)
    private val DIAG = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
    private val ORTH = listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)

    fun isWhite(c: Char) = c.isUpperCase()

    /** Клетки, которые фигура атакует (для пешки только диагонали). */
    fun attacks(b: String, i: Int): List<Int> {
        val p = b[i]
        if (p == '.') return emptyList()
        val r = i / 8
        val c = i % 8
        val out = ArrayList<Int>()
        fun add(rr: Int, cc: Int) { if (rr in 0..7 && cc in 0..7) out.add(rr * 8 + cc) }
        when (p.lowercaseChar()) {
            'p' -> { val d = if (isWhite(p)) -1 else 1; add(r + d, c - 1); add(r + d, c + 1) }
            'n' -> KN.forEach { add(r + it.first, c + it.second) }
            'k' -> KG.forEach { add(r + it.first, c + it.second) }
            else -> {
                val dirs = when (p.lowercaseChar()) { 'b' -> DIAG; 'r' -> ORTH; else -> DIAG + ORTH }
                for ((dr, dc) in dirs) {
                    var rr = r + dr
                    var cc = c + dc
                    while (rr in 0..7 && cc in 0..7) {
                        out.add(rr * 8 + cc)
                        if (b[rr * 8 + cc] != '.') break
                        rr += dr; cc += dc
                    }
                }
            }
        }
        return out
    }

    fun attackedBy(b: String, sq: Int, white: Boolean): Boolean {
        for (i in 0 until 64) { val p = b[i]; if (p != '.' && isWhite(p) == white && sq in attacks(b, i)) return true }
        return false
    }

    fun threatened(b: String, byWhite: Boolean): Set<Int> {
        val s = HashSet<Int>()
        for (i in 0 until 64) { val p = b[i]; if (p != '.' && isWhite(p) == byWhite) s.addAll(attacks(b, i)) }
        return s
    }

    fun inCheck(b: String, white: Boolean): Boolean {
        val k = b.indexOf(if (white) 'K' else 'k')
        return k >= 0 && attackedBy(b, k, !white)
    }

    private fun pseudo(st: ChessState, i: Int): List<Int> {
        val b = st.board
        val p = b[i]
        if (p == '.') return emptyList()
        val white = isWhite(p)
        val r = i / 8
        val c = i % 8
        val out = ArrayList<Int>()
        when (p.lowercaseChar()) {
            'p' -> {
                val d = if (white) -1 else 1
                val startR = if (white) 6 else 1
                if (r + d in 0..7 && b[(r + d) * 8 + c] == '.') {
                    out.add((r + d) * 8 + c)
                    if (r == startR && b[(r + 2 * d) * 8 + c] == '.') out.add((r + 2 * d) * 8 + c)
                }
                for (dc in listOf(-1, 1)) {
                    val rr = r + d
                    val cc = c + dc
                    if (rr in 0..7 && cc in 0..7) {
                        val t = rr * 8 + cc
                        if ((b[t] != '.' && isWhite(b[t]) != white) || t == st.ep) out.add(t)
                    }
                }
            }
            'n', 'k' -> {
                attacks(b, i).forEach { if (b[it] == '.' || isWhite(b[it]) != white) out.add(it) }
                if (p.lowercaseChar() == 'k') {
                    val base = if (white) 56 else 0
                    val rook = if (white) 'R' else 'r'
                    val kc = if (white) 'K' else 'k'
                    val qc = if (white) 'Q' else 'q'
                    if (i == base + 4) {
                        if (st.castle.contains(kc) && b[base + 5] == '.' && b[base + 6] == '.' && b[base + 7] == rook &&
                            !attackedBy(b, base + 4, !white) && !attackedBy(b, base + 5, !white) && !attackedBy(b, base + 6, !white)) out.add(base + 6)
                        if (st.castle.contains(qc) && b[base + 3] == '.' && b[base + 2] == '.' && b[base + 1] == '.' && b[base] == rook &&
                            !attackedBy(b, base + 4, !white) && !attackedBy(b, base + 3, !white) && !attackedBy(b, base + 2, !white)) out.add(base + 2)
                    }
                }
            }
            else -> attacks(b, i).forEach { if (b[it] == '.' || isWhite(b[it]) != white) out.add(it) }
        }
        return out
    }

    fun apply(st: ChessState, from: Int, to: Int): ChessState {
        val b = st.board.toCharArray()
        val p = b[from]
        val white = isWhite(p)
        var ep = -1
        var castle = st.castle
        b[to] = p
        b[from] = '.'
        if (p.lowercaseChar() == 'p') {
            if (to == st.ep && from % 8 != to % 8) b[if (white) to + 8 else to - 8] = '.'
            if (kotlin.math.abs(to - from) == 16) ep = (from + to) / 2
            if (to / 8 == 0 || to / 8 == 7) b[to] = if (white) 'Q' else 'q'
        }
        if (p.lowercaseChar() == 'k') {
            if (to - from == 2) { b[to - 1] = b[to + 1]; b[to + 1] = '.' }
            if (from - to == 2) { b[to + 1] = b[to - 2]; b[to - 2] = '.' }
            castle = castle.filterNot { if (white) it.isUpperCase() else it.isLowerCase() }
        }
        for (sq in listOf(from, to)) {
            when (sq) { 63 -> castle = castle.replace("K", ""); 56 -> castle = castle.replace("Q", ""); 7 -> castle = castle.replace("k", ""); 0 -> castle = castle.replace("q", "") }
        }
        return ChessState(String(b), castle, ep)
    }

    fun legal(st: ChessState, i: Int): List<Int> {
        val p = st.board[i]
        if (p == '.') return emptyList()
        val white = isWhite(p)
        return pseudo(st, i).filter { !inCheck(apply(st, i, it).board, white) }
    }

    fun hasAnyMove(st: ChessState, white: Boolean): Boolean =
        (0 until 64).any { st.board[it] != '.' && isWhite(st.board[it]) == white && legal(st, it).isNotEmpty() }
}

/** Фигура рисуется кружком с буквой: не зависит от шрифта телефона (K король, Q ферзь, R ладья, B слон, N конь, P пешка). */
@Composable
private fun ChessPiece(p: Char) {
    val white = ChessEngine.isWhite(p)
    val king = p.lowercaseChar() == 'k'
    Box(
        Modifier.size(27.dp).clip(CircleShape).background(if (white) Color(0xFFFAFAFA) else Color(0xFF212121))
            .border(if (king) 2.dp else 1.dp, if (king) Color(0xFFFFB300) else if (white) Color(0xFF424242) else Color(0xFFBDBDBD), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(p.uppercaseChar().toString(), color = if (white) Color(0xFF111111) else Color(0xFFF5F5F5), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
    }
}

@Composable
internal fun ChessView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val st = ChessState(g.str("board") ?: CHESS_START, g.str("castle") ?: "KQkq", g.str("ep")?.toIntOrNull() ?: -1)
    val myWhite = me == g.p1
    val result = g.str("result")
    val myTurn = result == null && g.turn == me
    var sel by remember(g.id) { mutableStateOf<Int?>(null) }
    var showThreat by remember(g.id) { mutableStateOf(false) }
    val selMoves = remember(st, sel) { sel?.let { ChessEngine.legal(st, it) } ?: emptyList() }
    val selIsMine = sel?.let { st.board[it] != '.' && ChessEngine.isWhite(st.board[it]) == myWhite } ?: false
    val threats = remember(st.board, showThreat) { if (showThreat) ChessEngine.threatened(st.board, !myWhite) else emptySet() }
    val whiteCheck = remember(st.board) { ChessEngine.inCheck(st.board, true) }
    val blackCheck = remember(st.board) { ChessEngine.inCheck(st.board, false) }

    fun doMove(from: Int, to: Int) {
        val ns = ChessEngine.apply(st, from, to)
        val oppWhite = !myWhite
        val over = !ChessEngine.hasAnyMove(ns, oppWhite)
        val res = if (!over) null else if (ChessEngine.inCheck(ns.board, oppWhite)) (if (myWhite) "white" else "black") else "draw"
        move(buildJsonObject {
            put("board", ns.board); put("castle", ns.castle); put("ep", ns.ep.toString())
            if (res != null) put("result", res)
        }, if (res == null) other else null, if (res == null) "active" else "done")
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.clip(RoundedCornerShape(8.dp)).border(2.dp, Color(0xFF3E5A2A), RoundedCornerShape(8.dp)), verticalArrangement = Arrangement.spacedBy(0.dp)) {
            for (dr in 0 until 8) Row {
                for (dc in 0 until 8) {
                    val di = dr * 8 + dc
                    val sq = if (myWhite) di else 63 - di
                    val p = st.board[sq]
                    val base = if ((sq / 8 + sq % 8) % 2 == 0) Color(0xFFEEEED2) else Color(0xFF769656)
                    val isSel = sel == sq
                    val isMove = sq in selMoves
                    val kingInCheck = (p == 'K' && whiteCheck) || (p == 'k' && blackCheck)
                    val overlay: Color? = when {
                        isSel -> Color(0xAAF6F669)
                        kingInCheck -> Color(0xAAFF1744)
                        isMove && p != '.' -> Color(0xAAFF5252)
                        sq in threats -> Color(0x55FF0000)
                        else -> null
                    }
                    Box(Modifier.size(30.dp).background(base).clickable {
                        val cur = sel
                        if (cur != null && selIsMine && myTurn && sq in selMoves) { doMove(cur, sq); sel = null }
                        else if (p != '.') sel = if (cur == sq) null else sq
                        else sel = null
                    }, contentAlignment = Alignment.Center) {
                        if (overlay != null) Box(Modifier.fillMaxSize().background(overlay))
                        if (p != '.') ChessPiece(p)
                        if (isMove && p == '.') Text("●", fontSize = 11.sp, color = if (selIsMine) Color(0xAA1B5E20) else Color(0xAAD32F2F))
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { showThreat = !showThreat }) { Text(if (showThreat) "👁 Угрозы ✓" else "👁 Угрозы", color = accent, fontSize = 11.sp, maxLines = 1, softWrap = false) }
            if (myTurn) TextButton(onClick = {
                move(buildJsonObject { put("result", if (myWhite) "black" else "white") }, null, "done")
            }) { Text("🏳 Сдаться", color = Color(0xFFFF9B86), fontSize = 11.sp, maxLines = 1, softWrap = false) }
        }
        val myColor = if (myWhite) "white" else "black"
        val inChk = if (myWhite) whiteCheck else blackCheck
        Text(
            when {
                result == "draw" -> "Ничья 🤝"
                result != null -> if (result == myColor) "Ты победил! 🎉" else "Победил $friendName"
                myTurn -> "Твой ход (${if (myWhite) "белые" else "чёрные"})" + if (inChk) " · ⚠ Шах!" else ""
                else -> "Ход $friendName…"
            }, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center
        )
        Text("Нажми свою фигуру — увидишь её ходы. Нажми фигуру соперника — увидишь, куда ходит она.", color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}
