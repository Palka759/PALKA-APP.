package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

// ------------------------------------------------------------------ данные

@Serializable data class GameRow(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    val kind: String,
    val p1: String,
    val p2: String,
    val state: JsonObject = JsonObject(emptyMap()),
    val turn: String? = null,
    val status: String = "active",
    val stake: Int = 0,
    val accepted: Boolean = true,
    val settled: Boolean = false
) {
    fun str(key: String): String? = state[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }
}

/** Создать игру в личном чате (сервер также добавляет карточку-сообщение). */
suspend fun Backend.createGame(conversationId: String, kind: String, state: JsonObject, stake: Int = 0) {
    client!!.postgrest.rpc("palka_game_create", buildJsonObject {
        put("p_conversation", conversationId)
        put("p_kind", kind)
        put("p_state", state)
        put("p_stake", stake)
    })
}

suspend fun Backend.acceptGame(id: String) { client!!.postgrest.rpc("palka_game_accept", buildJsonObject { put("p_id", id) }) }
suspend fun Backend.cancelGame(id: String) { client!!.postgrest.rpc("palka_game_cancel", buildJsonObject { put("p_id", id) }) }
suspend fun Backend.settleGame(id: String, result: String) { client!!.postgrest.rpc("palka_game_settle", buildJsonObject { put("p_id", id); put("p_result", result) }) }

/** Итог партии: id победителя, "draw" или null, если игра ещё идёт. */
fun outcomeOf(g: GameRow): String? = when (g.kind) {
    "ttt" -> {
        val b = (g.str("board") ?: "---------").padEnd(9, '-')
        when (tttWinner(b)) { 'X' -> g.p1; 'O' -> g.p2; else -> if (!b.contains('-')) "draw" else null }
    }
    "rps" -> {
        val a = g.str("a"); val b = g.str("b")
        if (a == null || b == null) null else if (a == b) "draw" else if (rpsBeats(a, b)) g.p1 else g.p2
    }
    "hang" -> {
        val word = g.str("word").orEmpty(); val guess = g.str("guess").orEmpty()
        if (word.isNotEmpty() && word.all { it in guess }) g.p2 else if (guess.count { it !in word } >= 6) g.p1 else null
    }
    "guess" -> {
        val secret = g.str("secret")?.toIntOrNull(); val tries = g.str("tries").orEmpty().split(",").mapNotNull { it.trim().toIntOrNull() }
        if (secret != null && secret in tries) g.p2 else if (tries.size >= 7) g.p1 else null
    }
    "chess" -> when (g.str("result")) { "white" -> g.p1; "black" -> g.p2; "draw" -> "draw"; else -> null }
    "bs" -> g.str("winner")
    else -> null
}

suspend fun Backend.gameById(id: String): GameRow? =
    client!!.from("palka_games").select { filter { eq("id", id) } }.decodeList<GameRow>().firstOrNull()

suspend fun Backend.gameMove(id: String, state: JsonObject, nextTurn: String?, status: String) {
    client!!.postgrest.rpc("palka_game_update", buildJsonObject {
        put("p_id", id)
        put("p_state", state)
        put("p_turn", nextTurn)
        put("p_status", status)
    })
}

fun parseGameBody(body: String): Pair<String, String> {
    val raw = body.removePrefix("game:")
    val i = raw.indexOf('|')
    return if (i < 0) raw to "" else raw.substring(0, i) to raw.substring(i + 1)
}

fun gameTitle(kind: String) = when (kind) {
    "ttt" -> "Крестики-нолики"; "rps" -> "Камень-ножницы-бумага"; "hang" -> "Виселица"
    "bs" -> "Морской бой"; "chess" -> "Шахматы"; "guess" -> "Угадай число"; else -> "Игра"
}

// ------------------------------------------------------------------ запуск игры

@Composable
fun GameStartDialog(friendName: String, conversationId: String, onCreated: () -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf<String?>(null) }
    var word by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var stake by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val okInput = kind != null && (kind != "hang" || word.trim().length in 3..12) && (kind != "guess" || secret.toIntOrNull()?.let { it in 1..100 } == true)
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Игра с $friendName") },
        confirmButton = {
            TextButton(enabled = !busy && okInput, onClick = {
                val k = kind ?: return@TextButton
                busy = true; error = ""
                val state = when (k) {
                    "ttt" -> buildJsonObject { put("board", "---------") }
                    "hang" -> buildJsonObject { put("word", word.trim().uppercase().replace('Ё', 'Е')); put("guess", "") }
                    "guess" -> buildJsonObject { put("secret", secret.trim().toInt().toString()); put("tries", "") }
                    "chess" -> buildJsonObject { put("board", CHESS_START); put("castle", "KQkq"); put("ep", "-1") }
                    else -> buildJsonObject { }
                }
                scope.launch {
                    runCatching { Backend.createGame(conversationId, k, state, stake) }
                        .onSuccess { onCreated(); onDismiss() }
                        .onFailure { t ->
                            val m = generateSequence(t) { it.cause }.joinToString(" ") { it.message.orEmpty() }
                            error = if (m.contains("Не хватает шишек")) "Не хватает шишек для ставки 🌰" else "Не удалось начать игру. Выполнен ли update_v18.sql?"
                        }
                    busy = false
                }
            }) { Text("Начать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "chess" to "♟ Шахматы (с подсказками ходов)", "bs" to "🚢 Морской бой", "guess" to "🔢 Угадай число",
                    "ttt" to "✖ Крестики-нолики", "rps" to "✊✋✌️ Камень-ножницы-бумага", "hang" to "🔤 Виселица"
                ).forEach { (k, label) ->
                    val sel = kind == k
                    Text(label, color = if (sel) MaterialTheme3Primary() else Color.Gray, fontSize = 15.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (sel) Color(0x223DDC84) else Color(0x14FFFFFF))
                            .border(1.dp, if (sel) MaterialTheme3Primary() else Color.Transparent, RoundedCornerShape(14.dp))
                            .clickable { kind = k }.padding(horizontal = 14.dp, vertical = 13.dp))
                }
                if (kind == "hang") {
                    OutlinedTextField(word, { word = it.filter { c -> c.isLetter() }.take(12) }, label = { Text("Слово (3–12 букв)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                if (kind == "guess") {
                    OutlinedTextField(secret, { secret = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("Загадай число 1–100") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text("Ставка шишками (победитель забирает обе)", color = Color.Gray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (0..3).forEach { n ->
                        val sel = stake == n
                        Text(if (n == 0) "Без ставки" else "$n 🌰", color = if (sel) MaterialTheme3Primary() else Color.Gray, fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (sel) Color(0x223DDC84) else Color(0x14FFFFFF))
                                .clickable { stake = n }.padding(horizontal = 10.dp, vertical = 8.dp))
                    }
                }
                if (stake > 0) Text("Друг должен принять ставку. До этого твои шишки заморожены; игру можно отменить.", color = Color.Gray, fontSize = 11.sp)
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp)
            }
        }
    )
}

@Composable private fun MaterialTheme3Primary(): Color = androidx.compose.material3.MaterialTheme.colorScheme.primary

// ------------------------------------------------------------------ карточка игры в чате

@Composable
fun GameCard(body: String, myId: String?, friendName: String, accent: Color, textColor: Color) {
    val (kind, id) = parseGameBody(body)
    val scope = rememberCoroutineScope()
    var game by remember(id) { mutableStateOf<GameRow?>(null) }
    var error by remember(id) { mutableStateOf("") }

    LaunchedEffect(id) {
        while (id.isNotBlank()) {
            val g = runCatching { Backend.gameById(id) }.getOrNull()
            if (g != null) game = g
            if (g != null && (outcomeOf(g) != null || g.status == "done") && (g.stake == 0 || g.settled)) break
            delay(2000)
        }
    }

    val gg = game
    val out = gg?.let { outcomeOf(it) }
    // Ставка: проигравший сам подтверждает поражение, при ничьей ставки возвращаются.
    LaunchedEffect(gg?.id, out, gg?.settled) {
        if (gg != null && gg.stake > 0 && gg.accepted && !gg.settled && out != null && myId != null) {
            if (out == "draw") runCatching { Backend.settleGame(gg.id, "draw") }
            else if (out != myId) runCatching { Backend.settleGame(gg.id, "concede") }
            runCatching { Backend.gameById(gg.id) }.getOrNull()?.let { game = it }
        }
    }

    fun move(state: JsonObject, nextTurn: String?, status: String) {
        val g = game ?: return
        scope.launch {
            error = ""
            runCatching { Backend.gameMove(g.id, state, nextTurn, status) }
                .onSuccess { runCatching { Backend.gameById(g.id) }.getOrNull()?.let { game = it } }
                .onFailure { error = "Ход не принят" }
        }
    }

    Column(Modifier.width(264.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.18f))
        .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎮 " + gameTitle(kind) + (if ((gg?.stake ?: 0) > 0) " · ставка ${gg?.stake} 🌰" else ""), color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        val g = gg
        if (g == null || myId == null) {
            Text("Загрузка игры…", color = textColor, fontSize = 13.sp)
        } else if (!g.accepted) {
            if (g.settled) Text("Игра отменена, ставка возвращена", color = textColor, fontSize = 13.sp)
            else if (myId == g.p2) {
                Text("$friendName предлагает сыграть на ${g.stake} 🌰", color = textColor, fontSize = 13.sp, textAlign = TextAlign.Center)
                TextButton(onClick = {
                    scope.launch {
                        runCatching { Backend.acceptGame(g.id) }
                            .onSuccess { runCatching { Backend.gameById(g.id) }.getOrNull()?.let { game = it } }
                            .onFailure { t -> error = if (generateSequence(t) { it.cause }.any { it.message.orEmpty().contains("Не хватает шишек") }) "Не хватает шишек 🌰" else "Не удалось принять" }
                    }
                }) { Text("Принять ставку ${g.stake} 🌰", color = accent, fontWeight = FontWeight.Bold) }
            } else {
                Text("Ждём, пока $friendName примет ставку ${g.stake} 🌰", color = textColor, fontSize = 13.sp, textAlign = TextAlign.Center)
                TextButton(onClick = {
                    scope.launch {
                        runCatching { Backend.cancelGame(g.id) }
                            .onSuccess { runCatching { Backend.gameById(g.id) }.getOrNull()?.let { game = it } }
                            .onFailure { error = "Не удалось отменить" }
                    }
                }) { Text("Отменить", color = Color(0xFFFF9B86)) }
            }
        } else {
            val other = if (myId == g.p1) g.p2 else g.p1
            when (g.kind) {
                "ttt" -> TttView(g, myId, other, friendName, accent, textColor, ::move)
                "rps" -> RpsView(g, myId, friendName, accent, textColor, ::move)
                "hang" -> HangView(g, myId, other, friendName, accent, textColor, ::move)
                "guess" -> GuessView(g, myId, friendName, accent, textColor, ::move)
                "bs" -> BsView(g, myId, other, friendName, accent, textColor, ::move)
                "chess" -> ChessView(g, myId, other, friendName, accent, textColor, ::move)
            }
            if (out == myId) WinBadge(accent)
            if (out != null && g.stake == 0 && g.kind in setOf("ttt", "rps", "chess", "bs")) {
                var sent by remember(g.id) { mutableStateOf(false) }
                TextButton(enabled = !sent, onClick = {
                    sent = true
                    scope.launch {
                        runCatching { Backend.createGame(g.conversationId, g.kind, rematchState(g.kind), 0) }
                            .onFailure { sent = false; error = "Не удалось начать реванш" }
                    }
                }) { Text(if (sent) "Реванш отправлен ✓" else "🔄 Реванш", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            }
            if (g.stake > 0 && out != null) {
                Text(
                    when {
                        !g.settled -> "Идёт расчёт ставки…"
                        out == "draw" -> "Ничья: ставки возвращены"
                        out == myId -> "Ты выиграл ${g.stake * 2} 🌰"
                        else -> "Ты проиграл ${g.stake} 🌰"
                    }, color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 11.sp)
    }
}

private fun rematchState(kind: String): JsonObject = when (kind) {
    "ttt" -> buildJsonObject { put("board", "---------") }
    "chess" -> buildJsonObject { put("board", CHESS_START); put("castle", "KQkq"); put("ep", "-1") }
    else -> buildJsonObject { }
}

/** Небольшая анимация победы: кубок слегка подпрыгивает и пульсирует. */
@Composable
private fun WinBadge(accent: Color) {
    val tr = androidx.compose.animation.core.rememberInfiniteTransition(label = "win")
    val k by tr.animateFloat(1f, 1.18f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(700), androidx.compose.animation.core.RepeatMode.Reverse), label = "k")
    Text("🏆", fontSize = 30.sp, modifier = Modifier.padding(top = 6.dp).graphicsLayer { scaleX = k; scaleY = k; rotationZ = (k - 1.09f) * 40f })
}

// ---- крестики-нолики

private val TTT_LINES = listOf(
    intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
    intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
    intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
)

private fun tttWinner(b: String): Char? = TTT_LINES.firstOrNull { l -> b[l[0]] != '-' && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]] }?.let { b[it[0]] }

@Composable
private fun TttView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val board = (g.str("board") ?: "---------").padEnd(9, '-')
    val mySym = if (me == g.p1) 'X' else 'O'
    val win = tttWinner(board)
    val full = !board.contains('-')
    val done = win != null || full || g.status == "done"
    val myTurn = !done && g.turn == me
    val winLine = TTT_LINES.firstOrNull { l -> board[l[0]] != '-' && board[l[0]] == board[l[1]] && board[l[1]] == board[l[2]] }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (r in 0 until 3) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (c in 0 until 3) {
                val i = r * 3 + c
                val ch = board[i]
                val inWin = winLine?.contains(i) == true
                val col = if (ch == 'X') Color(0xFFFF6B6B) else Color(0xFF64B5F6)
                Box(Modifier.size(64.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (inWin) col.copy(alpha = 0.28f) else Color.Black.copy(alpha = 0.28f))
                    .border(if (inWin) 2.dp else 1.dp, if (inWin) col else Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                    .clickable(enabled = myTurn && ch == '-') {
                        val nb = board.substring(0, i) + mySym + board.substring(i + 1)
                        val w = tttWinner(nb)
                        val f = !nb.contains('-')
                        if (w != null || f) move(buildJsonObject { put("board", nb); put("winner", if (w != null) me else "draw") }, null, "done")
                        else move(buildJsonObject { put("board", nb) }, other, "active")
                    }, contentAlignment = Alignment.Center) {
                    Text(when (ch) { 'X' -> "X"; 'O' -> "O"; else -> "" }, color = col, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
    val status = when {
        win != null -> if (win == mySym) "Ты победил! 🎉" else "Победил $friendName"
        full -> "Ничья 🤝"
        myTurn -> "Твой ход ($mySym)"
        else -> "Ход $friendName…"
    }
    Text(status, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
}

// ---- камень-ножницы-бумага

private fun rpsEmoji(c: String?) = when (c) { "R" -> "✊"; "P" -> "✋"; "S" -> "✌️"; else -> "❔" }
private fun rpsBeats(a: String, b: String) = (a == "R" && b == "S") || (a == "S" && b == "P") || (a == "P" && b == "R")

@Composable
private fun RpsView(g: GameRow, me: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val slot = if (me == g.p1) "a" else "b"
    val otherSlot = if (slot == "a") "b" else "a"
    val mine = g.str(slot)
    val theirs = g.str(otherSlot)
    if (mine != null && theirs != null) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(72.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Text(rpsEmoji(mine), fontSize = 38.sp) }
            Text("vs", color = textColor.copy(alpha = 0.7f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) { Text(rpsEmoji(theirs), fontSize = 38.sp) }
        }
        Text(when { mine == theirs -> "Ничья 🤝"; rpsBeats(mine, theirs) -> "Ты победил! 🎉"; else -> "Победил $friendName" }, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
    } else if (mine != null) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Text(rpsEmoji(mine), fontSize = 38.sp) }
        Text("Выбор сделан. Ждём $friendName…", color = textColor, fontSize = 13.sp)
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("R", "P", "S").forEach { pick ->
                Box(Modifier.size(72.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)).border(1.dp, accent.copy(alpha = 0.4f), CircleShape).clickable {
                    move(buildJsonObject { put(slot, pick) }, null, if (theirs != null) "done" else "active")
                }, contentAlignment = Alignment.Center) { Text(rpsEmoji(pick), fontSize = 34.sp) }
            }
        }
        Text(if (theirs != null) "$friendName уже выбрал(а). Твой ход!" else "Сделай выбор — соперник не увидит его", color = textColor, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
    }
}

// ---- виселица

private const val ALPHABET = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
private const val MAX_MISTAKES = 6

@Composable
private fun HangView(g: GameRow, me: String, other: String, friendName: String, accent: Color, textColor: Color, move: (JsonObject, String?, String) -> Unit) {
    val word = g.str("word").orEmpty()
    val guess = g.str("guess").orEmpty()
    val iGuess = me == g.p2
    val mistakes = guess.count { it !in word }
    val won = word.isNotEmpty() && word.all { it in guess }
    val lost = mistakes >= MAX_MISTAKES
    val done = won || lost || g.status == "done"
    val shown = word.map { if (it in guess || (!iGuess && done)) it else '_' }.joinToString(" ")
    Text(shown, color = textColor, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, textAlign = TextAlign.Center)
    Text("❤️".repeat((MAX_MISTAKES - mistakes).coerceAtLeast(0)) + "🖤".repeat(mistakes.coerceAtMost(MAX_MISTAKES)), fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp))
    if (!done && iGuess) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            ALPHABET.chunked(9).forEach { rowLetters ->
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowLetters.forEach { ch ->
                        val used = ch in guess
                        Box(Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (used) Color.Black.copy(alpha = 0.25f) else accent.copy(alpha = 0.2f))
                            .clickable(enabled = !used) {
                                val ng = guess + ch
                                val nm = ng.count { it !in word }
                                val w = word.all { it in ng }
                                if (w || nm >= MAX_MISTAKES) move(buildJsonObject { put("guess", ng) }, null, "done")
                                else move(buildJsonObject { put("guess", ng) }, me, "active")
                            }, contentAlignment = Alignment.Center) {
                            Text(ch.toString(), color = if (used) Color.Gray else textColor, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
    Text(
        when {
            won -> if (iGuess) "Ты угадал слово! 🎉" else "$friendName угадал(а) слово"
            lost -> if (iGuess) "Проиграл. Слово было: $word" else "$friendName не угадал(а) 😈"
            iGuess -> "Угадай слово по буквам"
            else -> "Ты загадал(а) «$word». $friendName угадывает…"
        }, color = textColor, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp)
    )
}
