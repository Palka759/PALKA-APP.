package com.palka.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Подарки нарисованы векторно (без эмодзи), в одном стиле: объёмные, с мягкими градиентами и бликами. */
private val GIFT_ART_IDS = setOf("heart", "star", "rose", "cake", "bear", "rocket", "trophy", "diamond")

@Composable
private fun rememberGiftPhase(animate: Boolean): Float {
    if (!animate) return 0.25f
    val tr = rememberInfiniteTransition(label = "giftPhase")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "p")
    return p
}

@Composable
fun GiftArt(id: String, dim: Dp, animate: Boolean = false, fallbackEmoji: String = "🎁") {
    val ph = rememberGiftPhase(animate)
    val s = if (animate) sin(2.0 * PI * ph).toFloat() else 0f
    if (id !in GIFT_ART_IDS) {
        Box(Modifier.size(dim).graphicsLayer { rotationZ = 3f * s }, contentAlignment = Alignment.Center) {
            Text(fallbackEmoji, fontSize = (dim.value * 0.62f).sp)
        }
        return
    }
    val pulse = if (animate) (sin(4.0 * PI * ph).toFloat() + 1f) / 2f else 0f
    Canvas(
        Modifier.size(dim).graphicsLayer {
            val h = this.size.height
            when (id) {
                "heart" -> { val k = 1f + 0.06f * pulse; scaleX = k; scaleY = k }
                "bear" -> rotationZ = 4f * s
                "rose" -> { rotationZ = 3f * s; translationY = -h * 0.025f * s }
                "star" -> { rotationZ = 6f * s; val k = 1f + 0.04f * s; scaleX = k; scaleY = k }
                "rocket" -> { translationY = -h * 0.04f * s; rotationZ = 2f * s }
                "trophy" -> { val k = 1f + 0.03f * pulse; scaleX = k; scaleY = k }
                "diamond" -> { val k = 1f + 0.035f * s; scaleX = k; scaleY = k }
                else -> { }
            }
        }
    ) {
        val u = this.size.minDimension
        when (id) {
            "heart" -> drawHeartGift(u)
            "star" -> drawStarGift(u)
            "rose" -> drawRoseGift(u)
            "cake" -> drawCakeGift(u, s)
            "bear" -> drawBearGift(u)
            "rocket" -> drawRocketGift(u, s)
            "trophy" -> drawTrophyGift(u)
            "diamond" -> drawDiamondGift(u)
        }
        if (animate) {
            val spots = listOf(Offset(0.14f, 0.2f) to 0f, Offset(0.86f, 0.3f) to 0.33f, Offset(0.8f, 0.86f) to 0.66f)
            spots.forEach { (p, off) ->
                val a = max(0f, sin(2.0 * PI * (ph + off)).toFloat())
                if (a > 0.02f) drawSpark(Offset(p.x * u, p.y * u), u * 0.07f * (0.5f + a), Color.White.copy(alpha = a * 0.9f))
            }
        }
    }
}

private fun DrawScope.drawSpark(c: Offset, r: Float, color: Color) {
    val path = Path()
    val pts = 8
    for (i in 0 until pts) {
        val ang = (PI * 2 * i / pts - PI / 2).toFloat()
        val rr = if (i % 2 == 0) r else r * 0.3f
        val x = c.x + cos(ang) * rr
        val y = c.y + sin(ang) * rr
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color)
}

private fun DrawScope.poly(u: Float, pts: List<Pair<Float, Float>>): Path {
    val p = Path()
    pts.forEachIndexed { i, (x, y) -> if (i == 0) p.moveTo(x * u, y * u) else p.lineTo(x * u, y * u) }
    p.close()
    return p
}

private fun DrawScope.shadow(u: Float, cx: Float = 0.5f, y: Float = 0.94f, w: Float = 0.5f) {
    drawOval(Color.Black.copy(alpha = 0.22f), Offset((cx - w / 2) * u, (y - 0.03f) * u), Size(w * u, 0.06f * u))
}

// ---------------------------------------------------------------- сердце (с зелёным листком)
private fun DrawScope.drawHeartGift(u: Float) {
    shadow(u, y = 0.95f, w = 0.4f)
    val heart = Path().apply {
        moveTo(0.5f * u, 0.9f * u)
        cubicTo(0.1f * u, 0.62f * u, 0.02f * u, 0.3f * u, 0.22f * u, 0.17f * u)
        cubicTo(0.36f * u, 0.08f * u, 0.5f * u, 0.16f * u, 0.5f * u, 0.3f * u)
        cubicTo(0.5f * u, 0.16f * u, 0.64f * u, 0.08f * u, 0.78f * u, 0.17f * u)
        cubicTo(0.98f * u, 0.3f * u, 0.9f * u, 0.62f * u, 0.5f * u, 0.9f * u)
        close()
    }
    drawPath(heart, Brush.linearGradient(listOf(Color(0xFFFF6B7D), Color(0xFFD81B45), Color(0xFF8E0F33)), Offset(0.2f * u, 0.1f * u), Offset(0.8f * u, 0.9f * u)))
    drawPath(heart, Color(0x33FFFFFF), style = Stroke(0.012f * u))
    drawOval(Color.White.copy(alpha = 0.38f), Offset(0.17f * u, 0.2f * u), Size(0.16f * u, 0.09f * u))
    val leaf = Path().apply {
        moveTo(0.5f * u, 0.19f * u)
        cubicTo(0.52f * u, 0.03f * u, 0.72f * u, 0.01f * u, 0.76f * u, 0.07f * u)
        cubicTo(0.72f * u, 0.15f * u, 0.57f * u, 0.22f * u, 0.5f * u, 0.19f * u)
        close()
    }
    drawPath(leaf, Brush.linearGradient(listOf(Color(0xFF7BE495), Color(0xFF1E8E4E)), Offset(0.5f * u, 0.05f * u), Offset(0.75f * u, 0.2f * u)))
}

// ---------------------------------------------------------------- звезда
private fun DrawScope.drawStarGift(u: Float) {
    shadow(u, y = 0.95f, w = 0.45f)
    fun star(cx: Float, cy: Float, ro: Float, ri: Float): Path {
        val p = Path()
        for (i in 0 until 10) {
            val ang = (PI * i / 5 - PI / 2).toFloat()
            val r = if (i % 2 == 0) ro else ri
            val x = (cx + cos(ang) * r) * u
            val y = (cy + sin(ang) * r) * u
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }
    val outer = star(0.5f, 0.52f, 0.43f, 0.2f)
    drawPath(outer, Brush.linearGradient(listOf(Color(0xFFFFE680), Color(0xFFFFB300), Color(0xFFE67E00)), Offset(0.2f * u, 0.1f * u), Offset(0.8f * u, 0.95f * u)))
    drawPath(outer, Color(0x55FFFFFF), style = Stroke(0.012f * u))
    drawPath(star(0.5f, 0.52f, 0.28f, 0.12f), Color.White.copy(alpha = 0.22f))
}

// ---------------------------------------------------------------- роза
private fun DrawScope.drawRoseGift(u: Float) {
    shadow(u, y = 0.97f, w = 0.3f)
    drawLine(Color(0xFF2E8B57), Offset(0.5f * u, 0.5f * u), Offset(0.5f * u, 0.95f * u), strokeWidth = 0.05f * u)
    drawOval(Brush.linearGradient(listOf(Color(0xFF7BE495), Color(0xFF1E8E4E)), Offset(0.5f * u, 0.7f * u), Offset(0.75f * u, 0.8f * u)), Offset(0.52f * u, 0.72f * u), Size(0.22f * u, 0.1f * u))
    drawOval(Brush.linearGradient(listOf(Color(0xFF7BE495), Color(0xFF1E8E4E)), Offset(0.25f * u, 0.6f * u), Offset(0.48f * u, 0.7f * u)), Offset(0.26f * u, 0.64f * u), Size(0.22f * u, 0.1f * u))
    val c = Offset(0.5f * u, 0.33f * u)
    drawCircle(Brush.radialGradient(listOf(Color(0xFFFF5A6E), Color(0xFFA3122F)), c, 0.3f * u), 0.27f * u, c)
    val dark = Color(0x66600015)
    listOf(Offset(0.38f, 0.3f), Offset(0.62f, 0.3f), Offset(0.5f, 0.46f)).forEach { p ->
        val pc = Offset(p.x * u, p.y * u)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFF7A8A), Color(0xFFC21A3C)), pc, 0.14f * u), 0.14f * u, pc)
        drawCircle(dark, 0.14f * u, pc, style = Stroke(0.01f * u))
    }
    drawCircle(Color(0xFF8E0F33), 0.075f * u, Offset(0.5f * u, 0.33f * u), style = Stroke(0.02f * u))
    drawCircle(Color(0xFF8E0F33), 0.03f * u, Offset(0.52f * u, 0.34f * u))
    drawOval(Color.White.copy(alpha = 0.3f), Offset(0.3f * u, 0.14f * u), Size(0.13f * u, 0.07f * u))
}

// ---------------------------------------------------------------- торт
private fun DrawScope.drawCakeGift(u: Float, s: Float) {
    drawRoundRect(Color(0xFFB0BEC5), Offset(0.08f * u, 0.84f * u), Size(0.84f * u, 0.07f * u), CornerRadius(0.035f * u))
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF8D5A3B), Color(0xFF5A3822)), 0.55f * u, 0.85f * u), Offset(0.14f * u, 0.55f * u), Size(0.72f * u, 0.3f * u), CornerRadius(0.06f * u))
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFFFF8E7), Color(0xFFF1D9B0)), 0.36f * u, 0.56f * u), Offset(0.22f * u, 0.37f * u), Size(0.56f * u, 0.2f * u), CornerRadius(0.06f * u))
    // глазурь-капли
    listOf(0.22f, 0.36f, 0.5f, 0.64f, 0.78f).forEachIndexed { i, x ->
        drawCircle(Color(0xFFFFF8E7), 0.045f * u, Offset((x + 0.0f) * u, (0.56f + (if (i % 2 == 0) 0.02f else 0f)) * u))
    }
    listOf(0.34f, 0.66f).forEach { x -> drawCircle(Color(0xFFD81B45), 0.04f * u, Offset(x * u, 0.37f * u)) }
    drawCircle(Color(0xFF3DDC84), 0.03f * u, Offset(0.5f * u, 0.395f * u))
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF7BE495), Color(0xFF1E8E4E)), 0.2f * u, 0.38f * u), Offset(0.47f * u, 0.21f * u), Size(0.06f * u, 0.17f * u), CornerRadius(0.02f * u))
    val fw = (0.05f + 0.012f * s) * u
    val fh = (0.11f + 0.015f * s) * u
    drawOval(Brush.verticalGradient(listOf(Color(0xFFFFF59D), Color(0xFFFF9800)), 0.1f * u, 0.22f * u), Offset(0.5f * u - fw, 0.2f * u - fh), Size(fw * 2, fh))
}

// ---------------------------------------------------------------- мишка (шарф цвета леса)
private fun DrawScope.drawBearGift(u: Float) {
    shadow(u, y = 0.96f, w = 0.5f)
    val fur = Brush.radialGradient(listOf(Color(0xFFC08A55), Color(0xFF7A4B26)), Offset(0.4f * u, 0.3f * u), 0.5f * u)
    drawCircle(fur, 0.11f * u, Offset(0.24f * u, 0.22f * u))
    drawCircle(fur, 0.11f * u, Offset(0.76f * u, 0.22f * u))
    drawCircle(Color(0xFFE8B98C), 0.06f * u, Offset(0.24f * u, 0.22f * u))
    drawCircle(Color(0xFFE8B98C), 0.06f * u, Offset(0.76f * u, 0.22f * u))
    drawOval(Brush.radialGradient(listOf(Color(0xFFB77C48), Color(0xFF6E4222)), Offset(0.45f * u, 0.7f * u), 0.35f * u), Offset(0.22f * u, 0.58f * u), Size(0.56f * u, 0.36f * u))
    drawCircle(Brush.radialGradient(listOf(Color(0xFFC99562), Color(0xFF7A4B26)), Offset(0.42f * u, 0.32f * u), 0.34f * u), 0.28f * u, Offset(0.5f * u, 0.42f * u))
    drawOval(Color(0xFFEBCFA6), Offset(0.37f * u, 0.43f * u), Size(0.26f * u, 0.2f * u))
    drawOval(Color(0xFF2B1A10), Offset(0.455f * u, 0.455f * u), Size(0.09f * u, 0.06f * u))
    listOf(0.4f, 0.6f).forEach { x ->
        drawCircle(Color(0xFF1E120B), 0.03f * u, Offset(x * u, 0.37f * u))
        drawCircle(Color.White, 0.01f * u, Offset((x - 0.008f) * u, 0.36f * u))
    }
    drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF3DDC84), Color(0xFF1E8E4E)), 0.28f * u, 0.72f * u), Offset(0.28f * u, 0.65f * u), Size(0.44f * u, 0.08f * u), CornerRadius(0.04f * u))
    drawRoundRect(Color(0xFF1E8E4E), Offset(0.58f * u, 0.69f * u), Size(0.08f * u, 0.17f * u), CornerRadius(0.025f * u))
    drawOval(Color.White.copy(alpha = 0.22f), Offset(0.3f * u, 0.2f * u), Size(0.14f * u, 0.07f * u))
}

// ---------------------------------------------------------------- ракета
private fun DrawScope.drawRocketGift(u: Float, s: Float) {
    val flameLen = (0.2f + 0.04f * s) * u
    val flame = Path().apply {
        moveTo(0.4f * u, 0.7f * u); lineTo(0.6f * u, 0.7f * u); lineTo(0.5f * u, 0.7f * u + flameLen); close()
    }
    drawPath(flame, Brush.verticalGradient(listOf(Color(0xFFFFF59D), Color(0xFFFF6D00)), 0.7f * u, 0.7f * u + flameLen))
    val fins = Brush.linearGradient(listOf(Color(0xFFFF6B6B), Color(0xFFB71C1C)), Offset(0.2f * u, 0.5f * u), Offset(0.4f * u, 0.75f * u))
    drawPath(poly(u, listOf(0.34f to 0.48f, 0.16f to 0.74f, 0.34f to 0.68f)), fins)
    drawPath(poly(u, listOf(0.66f to 0.48f, 0.84f to 0.74f, 0.66f to 0.68f)), fins)
    val body = Path().apply {
        moveTo(0.5f * u, 0.04f * u)
        cubicTo(0.74f * u, 0.2f * u, 0.74f * u, 0.5f * u, 0.67f * u, 0.7f * u)
        lineTo(0.33f * u, 0.7f * u)
        cubicTo(0.26f * u, 0.5f * u, 0.26f * u, 0.2f * u, 0.5f * u, 0.04f * u)
        close()
    }
    drawPath(body, Brush.horizontalGradient(listOf(Color(0xFFF5F7FA), Color(0xFFCFD8DC), Color(0xFF90A4AE)), 0.3f * u, 0.7f * u))
    val nose = Path().apply {
        moveTo(0.5f * u, 0.04f * u)
        cubicTo(0.6f * u, 0.1f * u, 0.66f * u, 0.18f * u, 0.68f * u, 0.27f * u)
        lineTo(0.32f * u, 0.27f * u)
        cubicTo(0.34f * u, 0.18f * u, 0.4f * u, 0.1f * u, 0.5f * u, 0.04f * u)
        close()
    }
    drawPath(nose, Brush.horizontalGradient(listOf(Color(0xFFFF6B6B), Color(0xFFB71C1C)), 0.3f * u, 0.7f * u))
    drawCircle(Color(0xFF455A64), 0.095f * u, Offset(0.5f * u, 0.44f * u))
    drawCircle(Brush.radialGradient(listOf(Color(0xFF9BE7FF), Color(0xFF1976D2)), Offset(0.48f * u, 0.42f * u), 0.08f * u), 0.075f * u, Offset(0.5f * u, 0.44f * u))
    drawOval(Color.White.copy(alpha = 0.45f), Offset(0.44f * u, 0.39f * u), Size(0.04f * u, 0.025f * u))
    drawRoundRect(Color(0xFF3DDC84), Offset(0.36f * u, 0.6f * u), Size(0.28f * u, 0.03f * u), CornerRadius(0.015f * u))
}

// ---------------------------------------------------------------- кубок
private fun DrawScope.drawTrophyGift(u: Float) {
    shadow(u, y = 0.96f, w = 0.5f)
    val gold = Brush.linearGradient(listOf(Color(0xFFFFE680), Color(0xFFFFB300), Color(0xFFC77800)), Offset(0.2f * u, 0.1f * u), Offset(0.8f * u, 0.7f * u))
    drawCircle(Color(0xFFE6A100), 0.1f * u, Offset(0.2f * u, 0.3f * u), style = Stroke(0.035f * u))
    drawCircle(Color(0xFFE6A100), 0.1f * u, Offset(0.8f * u, 0.3f * u), style = Stroke(0.035f * u))
    val cup = Path().apply {
        moveTo(0.26f * u, 0.12f * u); lineTo(0.74f * u, 0.12f * u)
        cubicTo(0.74f * u, 0.5f * u, 0.64f * u, 0.62f * u, 0.5f * u, 0.62f * u)
        cubicTo(0.36f * u, 0.62f * u, 0.26f * u, 0.5f * u, 0.26f * u, 0.12f * u)
        close()
    }
    drawPath(cup, gold)
    drawRoundRect(Color(0xFFD99100), Offset(0.45f * u, 0.6f * u), Size(0.1f * u, 0.15f * u), CornerRadius(0.02f * u))
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFE6A100), Color(0xFF9E6A00)), 0.74f * u, 0.86f * u), Offset(0.3f * u, 0.74f * u), Size(0.4f * u, 0.12f * u), CornerRadius(0.025f * u))
    drawRoundRect(Color(0xFF3DDC84), Offset(0.36f * u, 0.78f * u), Size(0.28f * u, 0.03f * u), CornerRadius(0.015f * u))
    drawOval(Color.White.copy(alpha = 0.38f), Offset(0.33f * u, 0.17f * u), Size(0.06f * u, 0.28f * u))
    drawRoundRect(Color(0xFFFFE680), Offset(0.26f * u, 0.1f * u), Size(0.48f * u, 0.04f * u), CornerRadius(0.02f * u))
}

// ---------------------------------------------------------------- кристалл
private fun DrawScope.drawDiamondGift(u: Float) {
    shadow(u, y = 0.95f, w = 0.4f)
    val gem = poly(u, listOf(0.3f to 0.22f, 0.7f to 0.22f, 0.92f to 0.42f, 0.5f to 0.9f, 0.08f to 0.42f))
    drawPath(gem, Brush.linearGradient(listOf(Color(0xFFB4F0FF), Color(0xFF3FA9F5), Color(0xFF1565C0)), Offset(0.1f * u, 0.2f * u), Offset(0.9f * u, 0.9f * u)))
    drawPath(poly(u, listOf(0.08f to 0.42f, 0.3f to 0.22f, 0.5f to 0.42f)), Color.White.copy(alpha = 0.28f))
    drawPath(poly(u, listOf(0.3f to 0.22f, 0.7f to 0.22f, 0.5f to 0.42f)), Color.White.copy(alpha = 0.5f))
    drawPath(poly(u, listOf(0.7f to 0.22f, 0.92f to 0.42f, 0.5f to 0.42f)), Color.White.copy(alpha = 0.16f))
    drawPath(poly(u, listOf(0.08f to 0.42f, 0.5f to 0.42f, 0.5f to 0.9f)), Color.Black.copy(alpha = 0.1f))
    drawPath(poly(u, listOf(0.92f to 0.42f, 0.5f to 0.42f, 0.5f to 0.9f)), Color.Black.copy(alpha = 0.24f))
    drawPath(gem, Color.White.copy(alpha = 0.45f), style = Stroke(0.012f * u))
}
