-- Новые подарки в стиле PALKA. Старые (кроме ёлочки) скрываются из магазина,
-- но уже подаренные остаются в профилях и продаются по старой цене.
update public.palka_gift_catalog set active = false where id <> 'pine';

insert into public.palka_gift_catalog (id, emoji, title, price, sort, active) values
  ('pine',    '🌲', 'Ёлочка',        25,  1, true),
  ('heart',   '❤️', 'Сердце леса',   50,  2, true),
  ('star',    '⭐', 'Звезда',        75,  3, true),
  ('rose',    '🌹', 'Роза',         100,  4, true),
  ('cake',    '🎂', 'Торт',         150,  5, true),
  ('bear',    '🧸', 'Мишка',        200,  6, true),
  ('rocket',  '🚀', 'Ракета',       300,  7, true),
  ('trophy',  '🏆', 'Кубок',        500,  8, true),
  ('diamond', '💎', 'Кристалл',     800,  9, true)
on conflict (id) do update set emoji = excluded.emoji, title = excluded.title, price = excluded.price, sort = excluded.sort, active = true;
