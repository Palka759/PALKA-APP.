package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import kotlinx.coroutines.delay
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

// ------------------------------------------------------------------ данные

@Serializable data class GiftDef(val id: String, val emoji: String, val title: String, val price: Int, val sort: Int = 0, val active: Boolean = true)

@Serializable data class GiftRow(
    val id: String,
    @SerialName("from_user") val fromUser: String,
    @SerialName("to_user") val toUser: String,
    @SerialName("gift_id") val giftId: String,
    val note: String = "",
    @SerialName("created_at") val createdAt: String? = null
)

data class Wallet(val coins: Int, val canClaim: Boolean, val daysLeft: Int = 0, val nextInSec: Long = 0)

/** Каталог на случай, если сервер ещё не отвечает (цены всё равно проверяет сервер). */
private val FALLBACK_GIFTS = listOf(
    GiftDef("pine", "🌲", "Ёлочка", 25, 1), GiftDef("heart", "❤️", "Сердце леса", 50, 2), GiftDef("star", "⭐", "Звезда", 75, 3),
    GiftDef("rose", "🌹", "Роза", 100, 4), GiftDef("cake", "🎂", "Торт", 150, 5), GiftDef("bear", "🧸", "Мишка", 200, 6),
    GiftDef("rocket", "🚀", "Ракета", 300, 7), GiftDef("trophy", "🏆", "Кубок", 500, 8), GiftDef("diamond", "💎", "Кристалл", 800, 9)
)

/** Старые подарки: убраны из магазина, но уже подаренные продолжают показываться в чатах и профилях. */
private val LEGACY_GIFTS = listOf(
    GiftDef("mushroom", "🍄", "Гриб", 10), GiftDef("leaf", "🍃", "Листик", 15), GiftDef("stick", "🪵", "Палка", 30),
    GiftDef("fox", "🦊", "Лисёнок", 50), GiftDef("owl", "🦉", "Сова", 80), GiftDef("spark", "🔥", "Искра костра", 100),
    GiftDef("deer", "🦌", "Олень", 250), GiftDef("rainbow", "🌈", "Радуга", 400), GiftDef("crown", "👑", "Корона леса", 1000),
    GiftDef("snowflake", "❄️", "Снежинка", 60), GiftDef("ornament", "🔮", "Ёлочный шар", 120),
    GiftDef("pumpkin", "🎃", "Тыква", 90), GiftDef("valentine", "💌", "Валентинка", 110)
)

private var catalogCache: List<GiftDef>? = null

/** Сезонные подарки: id -> (с месяца-дня, по месяц-день), формат ММДД. Вне сезона не показываются в магазине. */
private val SEASONS = mapOf(
    "snowflake" to (1201 to 115), "ornament" to (1201 to 115),
    "pumpkin" to (1010 to 1102), "valentine" to (201 to 216)
)
private val SEASON_LABEL = mapOf("snowflake" to "Новый год", "ornament" to "Новый год", "pumpkin" to "Хэллоуин", "valentine" to "14 февраля")

private fun inSeason(id: String): Boolean {
    val (from, to) = SEASONS[id] ?: return true
    val d = java.time.LocalDate.now()
    val md = d.monthValue * 100 + d.dayOfMonth
    return if (from <= to) md in from..to else md >= from || md <= to
}

fun giftById(id: String): GiftDef? = (catalogCache ?: FALLBACK_GIFTS).firstOrNull { it.id == id } ?: FALLBACK_GIFTS.firstOrNull { it.id == id } ?: LEGACY_GIFTS.firstOrNull { it.id == id }

suspend fun Backend.giftCatalog(): List<GiftDef> {
    catalogCache?.let { c -> return c.filter { inSeason(it.id) } }
    val list = client!!.from("palka_gift_catalog").select { order("sort", Order.ASCENDING) }.decodeList<GiftDef>().filter { it.active && it.price >= 25 }
    if (list.isNotEmpty()) catalogCache = list
    return list.ifEmpty { FALLBACK_GIFTS.filter { it.price >= 25 } }.filter { inSeason(it.id) }
}

private fun parseWallet(data: String): Wallet {
    val o = Json.parseToJsonElement(data).jsonObject
    return Wallet(o["coins"]?.jsonPrimitive?.intOrNull ?: 0, o["can_claim"]?.jsonPrimitive?.booleanOrNull ?: false, o["days_left"]?.jsonPrimitive?.intOrNull ?: 0, o["next_in_sec"]?.jsonPrimitive?.longOrNull ?: 0L)
}

suspend fun Backend.wallet(): Wallet = parseWallet(client!!.postgrest.rpc("palka_wallet_get", buildJsonObject { }).data)

suspend fun Backend.claimDailyBonus(): Wallet = parseWallet(client!!.postgrest.rpc("palka_wallet_claim", buildJsonObject { }).data)

/** Купить и отправить подарок в личный чат. Возвращает остаток шишек. */
suspend fun Backend.sendGift(conversationId: String, giftId: String, note: String): Int {
    val r = client!!.postgrest.rpc("palka_send_gift", buildJsonObject {
        put("p_conversation", conversationId)
        put("p_gift", giftId)
        put("p_note", note)
    })
    return Json.parseToJsonElement(r.data).jsonObject["coins"]?.jsonPrimitive?.intOrNull ?: 0
}

suspend fun Backend.giftsOf(userId: String): List<GiftRow> =
    client!!.from("palka_gifts").select {
        filter { eq("to_user", userId) }
        order("created_at", Order.DESCENDING)
        limit(100)
    }.decodeList<GiftRow>()

/** Продать подарок из своего профиля: возвращает (остаток шишек, сколько получено). */
suspend fun Backend.sellGift(giftRowId: String): Pair<Int, Int> {
    val o = Json.parseToJsonElement(client!!.postgrest.rpc("palka_sell_gift", buildJsonObject { put("p_gift_row", giftRowId) }).data).jsonObject
    return (o["coins"]?.jsonPrimitive?.intOrNull ?: 0) to (o["got"]?.jsonPrimitive?.intOrNull ?: 0)
}

/** За сколько шишек можно продать подарок: 20% от цены (25 -> 5). */
fun giftSellPrice(g: GiftDef?): Int = if (g == null) 0 else maxOf(1, g.price * 20 / 100)

@Composable
fun WalletStatus(w: Wallet, color: Color) {
    var left by remember(w) { mutableStateOf(w.nextInSec) }
    LaunchedEffect(w) { while (left > 0) { delay(1000); left -= 1 } }
    val text = when {
        w.daysLeft > 0 -> "До начала получения шишек: ${w.daysLeft} ${if (w.daysLeft % 10 == 1 && w.daysLeft % 100 != 11) "день" else if (w.daysLeft % 10 in 2..4 && w.daysLeft % 100 !in 12..14) "дня" else "дней"}. Потом по 1 шишке в день."
        w.canClaim -> "Шишку за сегодня можно забрать прямо сейчас!"
        else -> "До следующей шишки: ${left / 3600} ч ${(left % 3600) / 60} мин"
    }
    Text(text, color = color, fontSize = 12.sp)
}

/** Понятное сообщение об ошибке из ответа сервера. */
private fun giftError(t: Throwable): String {
    val m = generateSequence(t) { it.cause }.joinToString(" ") { it.message.orEmpty() }
    return when {
        m.contains("Не хватает шишек") -> "Не хватает шишек 🌰"
        m.contains("заблокирован") -> "Нельзя отправить подарок: пользователь заблокирован"
        m.contains("личный чат") -> "Подарки отправляются только в личных чатах"
        m.contains("palka_send_gift") || m.contains("PGRST202") || m.contains("42883") -> "Сервер не обновлён: выполни update_v12.sql в Supabase"
        else -> "Не удалось отправить подарок. Проверь интернет."
    }
}

// ------------------------------------------------------------------ сообщение-подарок в чате

/** Разбор тела сообщения "gift:<id>|<текст>". */
fun parseGiftBody(body: String): Pair<String, String> {
    val raw = body.removePrefix("gift:")
    val i = raw.indexOf('|')
    return if (i < 0) raw to "" else raw.substring(0, i) to raw.substring(i + 1)
}

@Composable
fun GiftBubble(body: String, mine: Boolean, otherName: String, accent: Color, textColor: Color) {
    val (id, note) = parseGiftBody(body)
    val gift = giftById(id)
    Column(Modifier.width(180.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (mine) "Вы подарили подарок" else "$otherName дарит подарок", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.size(96.dp).clip(RoundedCornerShape(26.dp))
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.26f), accent.copy(alpha = 0.08f))))
            .border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) {
            GiftArt(id, 72.dp, animate = true, fallbackEmoji = gift?.emoji ?: "🎁")
        }
        Text(gift?.title ?: "Подарок", color = textColor, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        if (note.isNotBlank()) Text(note, color = textColor, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}

// ------------------------------------------------------------------ магазин / отправка

@Composable
fun GiftShopDialog(friendName: String, conversationId: String, onSent: () -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var catalog by remember { mutableStateOf<List<GiftDef>>(emptyList()) }
    var wallet by remember { mutableStateOf<Wallet?>(null) }
    var selected by remember { mutableStateOf<GiftDef?>(null) }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        catalog = runCatching { Backend.giftCatalog() }.getOrDefault(FALLBACK_GIFTS)
        runCatching { Backend.wallet() }.onSuccess { wallet = it }.onFailure { error = giftError(it) }
    }
    val green = Color(0xFF3DDC84)
    val panel = Color(0xFF1A241D)
    val cream = Color(0xFFEEF2EA)

    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(panel).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Подарок для $friendName", color = cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Баланс: ${wallet?.coins ?: "…"} 🌰", color = green, fontSize = 13.sp)
                }
                TextButton(enabled = !busy, onClick = onDismiss) { Text("Закрыть", color = Color.Gray) }
            }
            if (wallet?.canClaim == true) {
                TextButton(onClick = {
                    scope.launch {
                        runCatching { Backend.claimDailyBonus() }
                            .onSuccess { wallet = it; info = "Получена 1 шишка 🌰" }
                            .onFailure { error = giftError(it) }
                    }
                }) { Text("🎁 Забрать шишку за день (+1 🌰)", color = Color(0xFFFFB74D)) }
            } else wallet?.let { WalletStatus(it, Color.Gray) }
            Spacer(Modifier.height(4.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3), modifier = Modifier.heightIn(max = 290.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(catalog) { g ->
                    val sel = selected?.id == g.id
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (sel) green.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.06f))
                            .border(if (sel) 2.dp else 0.dp, if (sel) green else Color.Transparent, RoundedCornerShape(16.dp))
                            .clickable { selected = g; error = ""; info = "" }
                            .padding(vertical = 12.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GiftArt(g.id, 52.dp, animate = sel, fallbackEmoji = g.emoji)
                        Text(g.title, color = cream, fontSize = 12.sp, maxLines = 1)
                        SEASON_LABEL[g.id]?.let { Text("❄ $it".replace("❄", if (g.id == "pumpkin") "🎃" else if (g.id == "valentine") "💌" else "❄"), color = Color(0xFF9BE7FF), fontSize = 9.sp, maxLines = 1) }
                        Text("${g.price} 🌰", color = Color(0xFFFFB74D), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            selected?.let { g ->
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = note, onValueChange = { if (it.length <= 200) note = it },
                    label = { Text("Текст к подарку (необязательно)") }, modifier = Modifier.fillMaxWidth(), maxLines = 3
                )
                Spacer(Modifier.height(8.dp))
                val enough = (wallet?.coins ?: 0) >= g.price
                androidx.compose.material3.Button(
                    enabled = !busy && wallet != null && enough, modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        busy = true; error = ""
                        scope.launch {
                            runCatching { Backend.sendGift(conversationId, g.id, note.trim()) }
                                .onSuccess { left -> wallet = (wallet ?: Wallet(left, false)).copy(coins = left); onSent(); onDismiss() }
                                .onFailure { error = giftError(it) }
                            busy = false
                        }
                    }
                ) { Text(if (enough) "Подарить за ${g.price} 🌰" else "Не хватает шишек") }
            }
            if (info.isNotBlank()) Text(info, color = green, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

// ------------------------------------------------------------------ полка подарков в профиле

@Composable
fun GiftsShelf(userId: String, isMe: Boolean, onGive: (() -> Unit)?) {
    var gifts by remember(userId) { mutableStateOf<List<GiftRow>?>(null) }
    var openGift by remember(userId) { mutableStateOf<GiftRow?>(null) }
    var openFrom by remember(userId) { mutableStateOf<Profile?>(null) }
    var wallet by remember(userId) { mutableStateOf<Wallet?>(null) }
    val shelfScope = rememberCoroutineScope()
    var sellError by remember(userId) { mutableStateOf("") }
    LaunchedEffect(userId) {
        gifts = runCatching { Backend.giftsOf(userId) }.getOrDefault(emptyList())
        if (isMe) wallet = runCatching { Backend.wallet() }.getOrNull()
    }
    val cream = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Подарки ${gifts?.size?.takeIf { it > 0 }?.let { "· $it" } ?: ""}", color = cream, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            if (isMe) Text("${wallet?.coins ?: "…"} 🌰", color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            else if (onGive != null) TextButton(onClick = onGive) { Text("Подарить 🎁", color = accent) }
        }
        if (isMe) wallet?.let { w ->
            WalletStatus(w, Color.Gray)
            if (w.canClaim) TextButton(onClick = {
                shelfScope.launch { runCatching { Backend.claimDailyBonus() }.onSuccess { wallet = it } }
            }) { Text("🎁 Забрать шишку (+1 🌰)", color = accent) }
        }
        val list = gifts
        if (list.isNullOrEmpty()) {
            Text(if (list == null) "Загрузка…" else if (isMe) "Пока нет подарков. Друзья могут подарить тебе что-нибудь из леса." else "Пока нет подарков", color = Color.Gray, fontSize = 12.sp)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list) { row ->
                    val g = giftById(row.giftId)
                    Box(
                        Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(accent.copy(alpha = 0.14f))
                            .clickable { openGift = row },
                        contentAlignment = Alignment.Center
                    ) { GiftArt(row.giftId, 42.dp, animate = false, fallbackEmoji = g?.emoji ?: "🎁") }
                }
            }
        }
    }
    openGift?.let { row ->
        LaunchedEffect(row.id) { openFrom = runCatching { Backend.profileById(row.fromUser) }.getOrNull() }
        val g = giftById(row.giftId)
        AlertDialog(
            onDismissRequest = { openGift = null; openFrom = null },
            confirmButton = { TextButton(onClick = { openGift = null; openFrom = null; sellError = "" }) { Text("Закрыть") } },
            dismissButton = if (isMe && g != null) ({
                TextButton(onClick = {
                    shelfScope.launch {
                        runCatching { Backend.sellGift(row.id) }
                            .onSuccess { (coins, _) -> gifts = gifts?.filter { it.id != row.id }; wallet = wallet?.copy(coins = coins); openGift = null; openFrom = null; sellError = "" }
                            .onFailure { sellError = "Не удалось продать. Выполнен ли update_v17.sql?" }
                    }
                }) { Text("Продать за ${giftSellPrice(g)} 🌰", color = Color(0xFFFFB74D)) }
            }) else null,
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    GiftArt(row.giftId, 88.dp, animate = true, fallbackEmoji = g?.emoji ?: "🎁")
                    Text(g?.title ?: "Подарок", modifier = Modifier.padding(top = 6.dp))
                }
            },
            text = {
                Column {
                    Text("От: " + (openFrom?.let { it.displayName.ifBlank { "@" + it.username } } ?: "…"))
                    if (row.note.isNotBlank()) Text("«${row.note}»", modifier = Modifier.padding(top = 8.dp))
                    if (isMe && g != null) Text("Продажа: ${giftSellPrice(g)} 🌰 (20% от цены ${g.price}). Подарок исчезнет из профиля.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    if (sellError.isNotBlank()) Text(sellError, color = Color(0xFFFF9B86), fontSize = 12.sp)
                }
            }
        )
    }
}
