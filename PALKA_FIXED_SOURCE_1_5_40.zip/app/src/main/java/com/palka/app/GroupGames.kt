package com.palka.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

// ------------------------------------------------------------------ данные

@Serializable data class GGame(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    val kind: String,
    val host: String,
    val players: List<String> = emptyList(),
    @SerialName("max_players") val maxPlayers: Int = 4,
    val state: JsonObject = JsonObject(emptyMap()),
    val turn: String? = null,
    val status: String = "lobby",
    val winner: String? = null
) {
    fun str(key: String): String? = state[key]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }
}

suspend fun Backend.ggameCreate(conversationId: String, kind: String, max: Int) {
    client!!.postgrest.rpc("palka_ggame_create", buildJsonObject { put("p_conversation", conversationId); put("p_kind", kind); put("p_max", max) })
}
suspend fun Backend.ggameJoin(id: String) { client!!.postgrest.rpc("palka_ggame_join", buildJsonObject { put("p_id", id) }) }
suspend fun Backend.ggameCancel(id: String) { client!!.postgrest.rpc("palka_ggame_cancel", buildJsonObject { put("p_id", id) }) }
suspend fun Backend.ggameStart(id: String, state: JsonObject) {
    client!!.postgrest.rpc("palka_ggame_start", buildJsonObject { put("p_id", id); put("p_state", state) })
}
suspend fun Backend.ggameMove(id: String, state: JsonObject, nextTurn: String?, status: String, winner: String?) {
    client!!.postgrest.rpc("palka_ggame_update", buildJsonObject {
        put("p_id", id); put("p_state", state); put("p_turn", nextTurn); put("p_status", status); put("p_winner", winner)
    })
}
suspend fun Backend.ggameById(id: String): GGame? =
    client!!.from("palka_group_games").select { filter { eq("id", id) } }.decodeList<GGame>().firstOrNull()
suspend fun Backend.ggamesActive(conversationId: String): List<GGame> =
    client!!.from("palka_group_games").select {
        filter { eq("conversation_id", conversationId); neq("status", "done") }
        order("created_at", Order.DESCENDING)
        limit(10)
    }.decodeList<GGame>()

fun parseGroupGameBody(body: String): Pair<String, String> {
    val raw = body.removePrefix("ggame:")
    val i = raw.indexOf('|')
    return if (i < 0) raw to "" else raw.substring(0, i) to raw.substring(i + 1)
}

fun ggTitle(kind: String) = when (kind) {
    "connect4" -> "Четыре в ряд"; "memory" -> "Мемори"; "dice21" -> "Кубики 21"; "hotcold" -> "Холодно-горячо"; else -> "Игра"
}

private val GG_COLORS = listOf(Color(0xFF3DDC84), Color(0xFFFFB74D), Color(0xFF64B5F6), Color(0xFFF48FB1))

private class GCtx(
    val g: GGame, val me: String, val names: Map<String, String>,
    val move: (JsonObject, String?, String, String?) -> Unit
) {
    val n get() = g.players.size
    val myIdx get() = g.players.indexOf(me)
    val myTurn get() = g.status == "active" && g.turn == me
    fun next(from: Int = myIdx) = g.players[(from + 1) % n]
    fun nameOf(id: String) = if (id == me) "Ты" else names[id] ?: "…"
}

/** Стартовое состояние игры; его создаёт хозяин при нажатии «Начать». */
private fun ggStartState(kind: String, n: Int): JsonObject = when (kind) {
    "connect4" -> buildJsonObject { put("b", ".".repeat(42)) }
    "memory" -> buildJsonObject {
        put("c", (0 until 8).flatMap { listOf(it, it) }.shuffled().joinToString("") { it.toString() })
        put("m", ".".repeat(16)); put("o1", "-1"); put("o2", "-1")
    }
    "dice21" -> buildJsonObject { put("s", List(n) { "0" }.joinToString(",")); put("d", List(n) { "0" }.joinToString(",")); put("last", "") }
    else -> buildJsonObject { put("secret", (1..100).random().toString()); put("tries", "") }
}

// ------------------------------------------------------------------ карточка в чате

@Composable
fun GroupGameCard(body: String, myId: String?, accent: Color, textColor: Color) {
    val (kind, id) = parseGroupGameBody(body)
    GroupGameCardById(kind, id, myId, accent, textColor)
}

@Composable
fun GroupGameCardById(kind: String, id: String, myId: String?, accent: Color, textColor: Color) {
    val scope = rememberCoroutineScope()
    var game by remember(id) { mutableStateOf<GGame?>(null) }
    var error by remember(id) { mutableStateOf("") }
    val names = remember { mutableStateMapOf<String, String>() }

    LaunchedEffect(id) {
        while (id.isNotBlank()) {
            val g = runCatching { Backend.ggameById(id) }.getOrNull()
            if (g != null) game = g
            if (g != null && g.status == "done") break
            delay(2000)
        }
    }
    LaunchedEffect(game?.players) {
        game?.players?.forEach { pid ->
            if (pid !in names) runCatching { Backend.profileById(pid) }.getOrNull()?.let { names[pid] = it.displayName.ifBlank { "@" + it.username } }
        }
    }
    fun refresh() { scope.launch { runCatching { Backend.ggameById(id) }.getOrNull()?.let { game = it } } }

    Column(Modifier.width(264.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.18f))
        .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎮 " + ggTitle(kind) + " · 2–4 игрока", color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        val g = game
        if (g == null || myId == null) {
            Text("Загрузка игры…", color = textColor, fontSize = 13.sp)
        } else {
            val ctx = GCtx(g, myId, names) { st, next, status, winner ->
                scope.launch {
                    error = ""
                    runCatching { Backend.ggameMove(g.id, st, next, status, winner) }
                        .onSuccess { refresh() }
                        .onFailure { error = "Ход не принят" }
                }
            }
            when (g.status) {
                "lobby" -> {
                    Text("Набор игроков: ${g.players.size}/${g.maxPlayers}", color = textColor, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    g.players.forEachIndexed { i, p ->
                        Text("● " + ctx.nameOf(p), color = GG_COLORS[i % 4], fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                    val joined = myId in g.players
                    if (!joined && g.players.size < g.maxPlayers) {
                        TextButton(onClick = {
                            scope.launch { runCatching { Backend.ggameJoin(g.id) }.onSuccess { refresh() }.onFailure { error = "Не удалось присоединиться" } }
                        }) { Text("Присоединиться", color = accent, fontWeight = FontWeight.Bold) }
                    } else if (!joined) Text("Мест нет", color = Color.Gray, fontSize = 12.sp)
                    if (myId == g.host) {
                        Row {
                            TextButton(enabled = g.players.size >= 2, onClick = {
                                scope.launch { runCatching { Backend.ggameStart(g.id, ggStartState(g.kind, g.players.size)) }.onSuccess { refresh() }.onFailure { error = "Не удалось начать" } }
                            }) { Text("▶ Начать", color = if (g.players.size >= 2) accent else Color.Gray, fontWeight = FontWeight.Bold) }
                            TextButton(onClick = {
                                scope.launch { runCatching { Backend.ggameCancel(g.id) }.onSuccess { refresh() } }
                            }) { Text("Отмена", color = Color(0xFFFF9B86)) }
                        }
                        if (g.players.size < 2) Text("Нужно минимум 2 игрока", color = Color.Gray, fontSize = 11.sp)
                    } else if (joined) Text("Ждём, пока ${ctx.nameOf(g.host)} начнёт", color = Color.Gray, fontSize = 11.sp)
                }
                else -> {
                    if (myId !in g.players) Text("Ты наблюдаешь за игрой", color = Color.Gray, fontSize = 11.sp)
                    PlayersRow(ctx)
                    Spacer(Modifier.height(8.dp))
                    when (g.kind) {
                        "connect4" -> Connect4View(ctx)
                        "memory" -> MemoryView(ctx)
                        "dice21" -> Dice21View(ctx)
                        "hotcold" -> HotColdView(ctx, textColor, accent)
                    }
                    if (g.status == "done") {
                        val w = g.winner
                        if (w == myId) WinBadge(accent)
                        Text(
                            when { g.state.isEmpty() && w == null -> "Игра отменена"; w == null -> "Ничья 🤝"; w == myId -> "Ты победил! 🎉"; else -> "Победил ${ctx.nameOf(w)}" },
                            color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp)
                        )
                    } else if (myId in g.players) {
                        Text(if (ctx.myTurn) "Твой ход" else "Ход: ${g.turn?.let { ctx.nameOf(it) } ?: "…"}", color = textColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 11.sp)
    }
}

@Composable
private fun PlayersRow(c: GCtx) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        c.g.players.forEachIndexed { i, p ->
            val turn = c.g.status == "active" && c.g.turn == p
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (turn) GG_COLORS[i % 4].copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f))
                    .border(if (turn) 1.dp else 0.dp, if (turn) GG_COLORS[i % 4] else Color.Transparent, RoundedCornerShape(10.dp))
                    .padding(vertical = 5.dp, horizontal = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(GG_COLORS[i % 4]))
                Text(c.nameOf(p), color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ------------------------------------------------------------------ Четыре в ряд

private fun c4Win(b: String, r: Int, c: Int, ch: Char): Boolean {
    for ((dr, dc) in listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)) {
        var cnt = 1
        for (sign in listOf(1, -1)) {
            var rr = r + dr * sign
            var cc = c + dc * sign
            while (rr in 0..5 && cc in 0..6 && b[rr * 7 + cc] == ch) { cnt++; rr += dr * sign; cc += dc * sign }
        }
        if (cnt >= 4) return true
    }
    return false
}

@Composable
private fun Connect4View(c: GCtx) {
    val b = (c.g.str("b") ?: ".".repeat(42)).padEnd(42, '.')
    fun drop(col: Int) {
        var r = 5
        while (r >= 0 && b[r * 7 + col] != '.') r--
        if (r < 0) return
        val ch = '0' + c.myIdx
        val arr = b.toCharArray()
        arr[r * 7 + col] = ch
        val s = String(arr)
        val st = buildJsonObject { put("b", s) }
        when {
            c4Win(s, r, col, ch) -> c.move(st, null, "done", c.me)
            !s.contains('.') -> c.move(st, null, "done", null)
            else -> c.move(st, c.next(), "active", null)
        }
    }
    Column(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF1D3A5A)).padding(5.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (r in 0 until 6) Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (col in 0 until 7) {
                val ch = b[r * 7 + col]
                Box(Modifier.size(30.dp).clip(CircleShape)
                    .background(if (ch == '.') Color(0xFF0E2236) else GG_COLORS[(ch - '0').coerceIn(0, 3)])
                    .clickable(enabled = c.myTurn) { drop(col) })
            }
        }
    }
}

// ------------------------------------------------------------------ Мемори

private val MEM_EMOJI = listOf("🍄", "🌲", "🦊", "🦉", "🐻", "🔥", "🌙", "🍂")

@Composable
private fun MemoryView(c: GCtx) {
    val g = c.g
    val cards = (g.str("c") ?: "0".repeat(16)).padEnd(16, '0')
    val m = (g.str("m") ?: ".".repeat(16)).padEnd(16, '.')
    val o1 = g.str("o1")?.toIntOrNull() ?: -1
    val o2 = g.str("o2")?.toIntOrNull() ?: -1
    fun click(i: Int) {
        if (m[i] != '.' || i == o1 || i == o2) return
        if (o2 != -1) { c.move(buildJsonObject { put("o1", i.toString()); put("o2", "-1") }, c.me, "active", null); return }
        if (o1 == -1) { c.move(buildJsonObject { put("o1", i.toString()) }, c.me, "active", null); return }
        if (cards[o1] == cards[i]) {
            val arr = m.toCharArray()
            arr[o1] = '0' + c.myIdx
            arr[i] = '0' + c.myIdx
            val s = String(arr)
            val st = buildJsonObject { put("m", s); put("o1", "-1"); put("o2", "-1") }
            if (!s.contains('.')) {
                val counts = (0 until c.n).map { k -> s.count { it == '0' + k } }
                val mx = counts.maxOrNull() ?: 0
                val w = if (counts.count { it == mx } == 1) g.players[counts.indexOf(mx)] else null
                c.move(st, null, "done", w)
            } else c.move(st, c.me, "active", null)
        } else c.move(buildJsonObject { put("o2", i.toString()) }, c.next(), "active", null)
    }
    Text(g.players.indices.joinToString("   ") { k -> "${c.nameOf(g.players[k]).take(6)}: ${m.count { it == '0' + k } / 2}" }, color = Color.White, fontSize = 11.sp)
    Spacer(Modifier.height(6.dp))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (r in 0 until 4) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (col in 0 until 4) {
                val i = r * 4 + col
                val owner = m[i]
                val shown = owner != '.' || i == o1 || i == o2
                val border = if (owner != '.') GG_COLORS[(owner - '0').coerceIn(0, 3)] else Color.Transparent
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (shown) Color.White.copy(alpha = 0.14f) else Color(0xFF2E7A45))
                    .border(2.dp, border, RoundedCornerShape(12.dp))
                    .clickable(enabled = c.myTurn && !shown) { click(i) }, contentAlignment = Alignment.Center) {
                    Text(if (shown) MEM_EMOJI[(cards[i] - '0').coerceIn(0, 7)] else "🌿", fontSize = 26.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Кубики 21

@Composable
private fun Dice21View(c: GCtx) {
    val g = c.g
    val n = c.n
    fun ints(key: String): List<Int> {
        val l = (g.str(key) ?: "").split(",").map { it.trim().toIntOrNull() ?: 0 }
        return l + List((n - l.size).coerceAtLeast(0)) { 0 }
    }
    val totals = ints("s")
    val done = ints("d").map { it == 1 }
    fun act(roll: Boolean) {
        val nt = totals.toMutableList()
        val nd = done.toMutableList()
        var last = ""
        if (roll) {
            val r = (1..6).random()
            nt[c.myIdx] = nt[c.myIdx] + r
            last = "${c.myIdx}:$r"
            if (nt[c.myIdx] > 21) nd[c.myIdx] = true
        } else nd[c.myIdx] = true
        val st = buildJsonObject {
            put("s", nt.joinToString(","))
            put("d", nd.joinToString(",") { if (it) "1" else "0" })
            put("last", last)
        }
        if (nd.all { it }) {
            val ok = nt.indices.filter { nt[it] <= 21 }
            val best = ok.maxOfOrNull { nt[it] }
            val ws = ok.filter { nt[it] == best }
            c.move(st, null, "done", if (best != null && ws.size == 1) g.players[ws[0]] else null)
        } else {
            var nx = (c.myIdx + 1) % n
            while (nd[nx]) nx = (nx + 1) % n
            c.move(st, g.players[nx], "active", null)
        }
    }
    Text("Набери 21 или ближе, но не больше", color = Color.Gray, fontSize = 10.sp)
    Spacer(Modifier.height(4.dp))
    g.players.forEachIndexed { i, p ->
        val t = totals[i]
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(c.nameOf(p), color = GG_COLORS[i % 4], fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
            Text("$t" + when { t > 21 -> " · перебор"; done[i] -> " · стоп"; else -> "" }, color = if (t > 21) Color(0xFFFF9B86) else Color.White, fontSize = 13.sp)
        }
    }
    val last = (g.str("last") ?: "").split(":")
    if (last.size == 2) Text("🎲 ${c.nameOf(g.players.getOrElse(last[0].toIntOrNull() ?: 0) { "" })} выбросил(а) ${last[1]}", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    if (c.myTurn && c.myIdx >= 0 && !done[c.myIdx]) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { act(true) }) { Text("🎲 Бросить", color = Color(0xFF3DDC84), fontWeight = FontWeight.Bold) }
            TextButton(onClick = { act(false) }) { Text("✋ Стоп", color = Color(0xFFFFB74D), fontWeight = FontWeight.Bold) }
        }
    }
}

// ------------------------------------------------------------------ Холодно-горячо (угадай число)

private const val HC_TRIES_EACH = 7

@Composable
private fun HotColdView(c: GCtx, textColor: Color, accent: Color) {
    val g = c.g
    val secret = g.str("secret")?.toIntOrNull() ?: 0
    val tries = (g.str("tries") ?: "").split(",").mapNotNull {
        val p = it.split(":")
        val a = p.getOrNull(0)?.toIntOrNull()
        val v = p.getOrNull(1)?.toIntOrNull()
        if (a != null && v != null) a to v else null
    }
    var input by remember(g.id) { mutableStateOf("") }
    Text("Загадано число от 1 до 100. У каждого по $HC_TRIES_EACH попыток.", color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
    Spacer(Modifier.height(4.dp))
    tries.takeLast(6).forEach { (a, v) ->
        val who = g.players.getOrNull(a)
        Text("${who?.let { c.nameOf(it) } ?: "?"}: $v  " + when { v == secret -> "✅ верно!"; v < secret -> "⬆ больше"; else -> "⬇ меньше" },
            color = textColor, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp))
                .background(if (v == secret) Color(0x333DDC84) else Color.White.copy(alpha = 0.08f)).padding(vertical = 5.dp))
    }
    if (c.myTurn && c.myIdx >= 0) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it.filter { ch -> ch.isDigit() }.take(3) }, singleLine = true, label = { Text("Число") }, modifier = Modifier.width(110.dp))
            TextButton(enabled = input.toIntOrNull()?.let { it in 1..100 } == true, onClick = {
                val v = input.toInt()
                val st = buildJsonObject { put("tries", (tries + (c.myIdx to v)).joinToString(",") { "${it.first}:${it.second}" }) }
                when {
                    v == secret -> c.move(st, null, "done", c.me)
                    tries.size + 1 >= HC_TRIES_EACH * c.n -> c.move(st, null, "done", null)
                    else -> c.move(st, c.next(), "active", null)
                }
                input = ""
            }) { Text("Ок", color = accent, fontWeight = FontWeight.Bold) }
        }
    }
    if (g.status == "done" && g.winner == null) Text("Число было: $secret", color = Color.Gray, fontSize = 11.sp)
}

// ------------------------------------------------------------------ вкладка «Игры группы»

@Composable
fun GroupGamesDialog(conversationId: String, myId: String?, onCreated: () -> Unit, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var maxP by remember { mutableStateOf(2) }
    var active by remember { mutableStateOf<List<GGame>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { active = runCatching { Backend.ggamesActive(conversationId) }.getOrDefault(emptyList()) }
    val green = Color(0xFF3DDC84)
    val cream = Color(0xFFEEF2EA)
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1A241D)).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("🎮 Игры группы", color = cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onDismiss) { Text("Закрыть", color = Color.Gray) }
            }
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Сколько игроков?", color = Color.Gray, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (2..4).forEach { n ->
                        val sel = maxP == n
                        Text("$n", color = if (sel) green else Color.Gray, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                            modifier = Modifier.width(52.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (sel) Color(0x223DDC84) else Color(0x14FFFFFF))
                                .border(1.dp, if (sel) green else Color.Transparent, RoundedCornerShape(12.dp))
                                .clickable { maxP = n }.padding(vertical = 10.dp))
                    }
                }
                listOf(
                    Triple("connect4", "🔴 Четыре в ряд", "Собери 4 в линию"),
                    Triple("memory", "🃏 Мемори", "Найди больше пар"),
                    Triple("dice21", "🎲 Кубики 21", "Набери 21, не перебери"),
                    Triple("hotcold", "🔢 Холодно-горячо", "Угадай число быстрее всех")
                ).forEach { (k, title, sub) ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x14FFFFFF))
                        .clickable(enabled = !busy) {
                            busy = true; error = ""
                            scope.launch {
                                runCatching { Backend.ggameCreate(conversationId, k, maxP) }
                                    .onSuccess { onCreated(); onDismiss() }
                                    .onFailure { error = "Не удалось начать игру. Выполнен ли update_v20.sql?" }
                                busy = false
                            }
                        }.padding(horizontal = 14.dp, vertical = 12.dp)) {
                        Text(title, color = cream, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(sub, color = Color.Gray, fontSize = 12.sp)
                    }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B86), fontSize = 12.sp)
                if (active.isNotEmpty()) {
                    Text("Идут сейчас", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    active.forEach { gg -> GroupGameCardById(gg.kind, gg.id, myId, green, cream) }
                }
            }
        }
    }
}
