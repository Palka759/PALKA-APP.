package com.palka.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.sin

/**
 * Appearance settings that are not part of the colour theme: accent colour, font size,
 * bubble shape, wallpaper dimming/blur. Stored in SharedPreferences "palka_look".
 */
object Look {
    var accent by mutableStateOf("theme")
    var fontScale by mutableStateOf(1f)
    var bubble by mutableStateOf("round")
    var dim by mutableStateOf(0f)
    var blur by mutableStateOf(0)
    var customVersion by mutableStateOf(0)

    private const val PREFS = "palka_look"

    fun load(c: Context) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        accent = p.getString("accent", "theme") ?: "theme"
        fontScale = p.getFloat("font", 1f)
        bubble = p.getString("bubble", "round") ?: "round"
        dim = p.getFloat("dim", 0f)
        blur = p.getInt("blur", 0)
    }

    fun save(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("accent", accent).putFloat("font", fontScale).putString("bubble", bubble)
            .putFloat("dim", dim).putInt("blur", blur).apply()
    }

    val accentColors: List<Pair<String, Color>> = listOf(
        "green" to Color(0xFF3DDC84), "amber" to Color(0xFFFFB84D), "teal" to Color(0xFF2EC4B6),
        "pink" to Color(0xFFFF7EB6), "blue" to Color(0xFF6CB4FF), "violet" to Color(0xFFB794F6)
    )

    /** null = use the accent colour of the current theme. */
    fun accentOverride(key: String = accent): Color? = accentColors.firstOrNull { it.first == key }?.second

    fun bubbleShape(mine: Boolean, style: String = bubble): RoundedCornerShape = when (style) {
        "soft" -> RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomStart = if (mine) 26.dp else 8.dp, bottomEnd = if (mine) 8.dp else 26.dp)
        "square" -> RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = if (mine) 8.dp else 2.dp, bottomEnd = if (mine) 2.dp else 8.dp)
        else -> RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (mine) 18.dp else 5.dp, bottomEnd = if (mine) 5.dp else 18.dp)
    }

    fun defaultWallpaper(c: Context): String {
        val p = c.getSharedPreferences("palka_wallpaper_default", Context.MODE_PRIVATE)
        return p.getString("wp", null) ?: "img${p.getInt("wallpaper", 0)}"
    }

    fun chatWallpaper(c: Context, conversationId: String): String {
        val p = c.getSharedPreferences("palka_wallpaper_$conversationId", Context.MODE_PRIVATE)
        return p.getString("wp", null) ?: p.getInt("wallpaper", -1).let { if (it >= 0) "img$it" else defaultWallpaper(c) }
    }
}

/** Simple counters shown in the hidden "Диагностика связи" dialog (tap the status dot in a chat). */
object NetStats {
    @Volatile var lastInsertMs = -1L       // HTTP INSERT round trip of our last message
    @Volatile var lastEchoMs = -1L         // from sending until our own row came back through Realtime
    @Volatile var lastPeerLagMs = Long.MIN_VALUE // peer's send clock -> our receive clock (needs equal phone clocks)
    @Volatile var lastSubscribeMs = -1L    // time to open the Realtime channel
    @Volatile var reconnects = 0
    val sendStart = java.util.concurrent.ConcurrentHashMap<String, Long>()
}

/** Outlives the chat screen: a message being sent is not cancelled when the user leaves the chat. */
val deliveryScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.Main.immediate)

data class WpInfo(val id: String, val title: String, val animated: Boolean = false)

val PalkaWallpapers = listOf(
    WpInfo("img0", "Чаща"), WpInfo("img1", "Тропа"), WpInfo("img2", "Поляна"), WpInfo("img3", "Опушка"),
    WpInfo("night", "Ночной лес"), WpInfo("fog", "Туман"), WpInfo("rain", "Дождь", true), WpInfo("sunset", "Закат"),
    WpInfo("snow", "Снегопад", true), WpInfo("fireflies", "Светлячки", true), WpInfo("crystal", "Кристаллы"),
    WpInfo("sticks", "Палки"), WpInfo("leaves", "Листопад", true),
    WpInfo("aurora", "Северное сияние", true), WpInfo("galaxy", "Галактика", true), WpInfo("ocean", "Океан волн", true),
    WpInfo("starrain", "Дождь из звёзд", true), WpInfo("neon", "Неон-город", true), WpInfo("summer", "Лето", true),
    WpInfo("spring", "Весна", true), WpInfo("sakura", "Сакура", true),
    WpInfo("newyear", "Новый год", true), WpInfo("xmas", "Ёлка", true), WpInfo("halloween", "Хэллоуин", true),
    WpInfo("valentine", "14 февраля", true), WpInfo("women8", "8 Марта", true),
    WpInfo("custom", "Своё")
)

fun saveCustomWallpaper(ctx: Context, uri: Uri): Boolean {
    return try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
        java.io.File(ctx.filesDir, "wp_custom.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        Look.customVersion++
        true
    } catch (_: Throwable) { false }
}

fun hasCustomWallpaper(ctx: Context): Boolean = java.io.File(ctx.filesDir, "wp_custom.jpg").exists()

/** blur 0..100. Cheap blur: scale down and back up with filtering. */
fun loadCustomWallpaper(ctx: Context, blur: Int): ImageBitmap? {
    return try {
        val f = java.io.File(ctx.filesDir, "wp_custom.jpg")
        if (!f.exists()) return null
        val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        if (blur <= 0) return src.asImageBitmap()
        val factor = 1f / (1f + blur / 6f)
        val w = (src.width * factor).toInt().coerceAtLeast(8)
        val h = (src.height * factor).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        Bitmap.createScaledBitmap(small, src.width, src.height, true).asImageBitmap()
    } catch (_: Throwable) { null }
}

/** Chat/preview background: resource photo, user's picture or a drawn (optionally animated) scene, plus dimming. */
@Composable
fun WallpaperBackdrop(id: String, dim: Float, blur: Int, modifier: Modifier = Modifier, animate: Boolean = true) {
    val ctx = LocalContext.current
    Box(modifier) {
        if (id.startsWith("img")) {
            val res = when (id) {
                "img1" -> R.drawable.palka_forest_wallpaper_2
                "img2" -> R.drawable.palka_forest_wallpaper_3
                "img3" -> R.drawable.palka_forest_wallpaper_4
                else -> R.drawable.palka_forest_wallpaper_1
            }
            Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else if (id == "custom") {
            val bmp by produceState<ImageBitmap?>(null, blur, Look.customVersion) {
                value = withContext(Dispatchers.IO) { loadCustomWallpaper(ctx, blur) }
            }
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxSize().background(Color(0xFF0F1A12)))
        } else {
            SceneWallpaper(id, animate)
        }
        if (dim > 0f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim.coerceIn(0f, 0.85f))))
    }
}

@Composable
private fun SceneWallpaper(id: String, animate: Boolean) {
    val animated = animate && PalkaWallpapers.firstOrNull { it.id == id }?.animated == true
    var t by remember { mutableFloatStateOf(0f) }
    if (animated) {
        LaunchedEffect(id) {
            val start = withFrameNanos { it }
            while (true) {
                withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
            }
        }
    }
    Canvas(Modifier.fillMaxSize()) { drawScene(id, t) }
}

private fun DrawScope.pines(color: Color, baseY: Float, count: Int, hMin: Float, hMax: Float, seed: Int) {
    val rnd = java.util.Random(seed.toLong())
    for (i in 0 until count) {
        val slot = size.width / count
        val cx = slot * (i + 0.5f) + (rnd.nextFloat() - 0.5f) * slot * 0.8f
        val h = hMin + rnd.nextFloat() * (hMax - hMin)
        val w = h * 0.34f
        drawRect(color, Offset(cx - w * 0.06f, baseY - h * 0.12f), Size(w * 0.12f, h * 0.14f))
        for (k in 0..2) {
            val top = baseY - h + k * h * 0.27f
            val bottom = top + h * 0.42f
            val half = w * (0.5f + 0.3f * k)
            val p = Path()
            p.moveTo(cx, top)
            p.lineTo(cx + half, bottom)
            p.lineTo(cx - half, bottom)
            p.close()
            drawPath(p, color)
        }
    }
}

private fun DrawScope.vgrad(vararg colors: Long) {
    drawRect(Brush.verticalGradient(colors.map { Color(it) }))
}


private fun sf(x: Float): Float = sin(x.toDouble()).toFloat()
private fun cf(x: Float): Float = kotlin.math.cos(x.toDouble()).toFloat()
private fun af(x: Float): Float = kotlin.math.abs(x)

private fun DrawScope.heart(c: Offset, s: Float, color: Color) {
    val p = Path()
    p.moveTo(c.x, c.y + s * 0.9f)
    p.cubicTo(c.x - s * 1.6f, c.y - s * 0.1f, c.x - s * 0.8f, c.y - s * 1.2f, c.x, c.y - s * 0.4f)
    p.cubicTo(c.x + s * 0.8f, c.y - s * 1.2f, c.x + s * 1.6f, c.y - s * 0.1f, c.x, c.y + s * 0.9f)
    p.close()
    drawPath(p, color)
}

private fun DrawScope.fallingDots(t: Float, count: Int, seed: Int, color: Color, rMin: Float, rMax: Float, spMin: Float, spMax: Float, sway: Float) {
    val rnd = java.util.Random(seed.toLong())
    for (i in 0 until count) {
        val r = rMin + rnd.nextFloat() * (rMax - rMin)
        val sp = spMin + rnd.nextFloat() * (spMax - spMin)
        val x = rnd.nextFloat() * size.width + sf(t * 0.8f + i) * sway
        val y = ((rnd.nextFloat() + t * sp) % 1f) * (size.height + r * 4f) - r * 2f
        drawCircle(color.copy(alpha = color.alpha * (0.55f + 0.45f * ((i % 3) / 2f))), r, Offset(x, y))
    }
}

private fun DrawScope.fallingPetals(t: Float, count: Int, seed: Int, colors: List<Color>, szMin: Float, szMax: Float, spMin: Float, spMax: Float, alpha: Float) {
    val rnd = java.util.Random(seed.toLong())
    for (i in 0 until count) {
        val sz = szMin + rnd.nextFloat() * (szMax - szMin)
        val sp = spMin + rnd.nextFloat() * (spMax - spMin)
        val x = rnd.nextFloat() * size.width + sf(t * 0.7f + i) * 26f
        val y = ((rnd.nextFloat() + t * sp) % 1f) * (size.height + sz * 3f) - sz * 1.5f
        val deg = t * (30f + (i % 5) * 12f) + i * 47f
        val c = Offset(x, y)
        rotate(deg, c) { drawOval(colors[i % colors.size].copy(alpha = alpha), Offset(x - sz / 2f, y - sz / 3f), Size(sz, sz * 0.66f)) }
    }
}

private fun DrawScope.risingHearts(t: Float, count: Int, seed: Int, alpha: Float) {
    val rnd = java.util.Random(seed.toLong())
    val cols = listOf(Color(0xFFFF4F7B), Color(0xFFFF8FB0), Color(0xFFFFB3C6), Color(0xFFE0245E))
    for (i in 0 until count) {
        val s = 8f + rnd.nextFloat() * 16f
        val sp = 0.03f + rnd.nextFloat() * 0.05f
        val x = rnd.nextFloat() * size.width + sf(t * 0.6f + i) * 18f
        val y = size.height + s * 2f - ((rnd.nextFloat() + t * sp) % 1f) * (size.height + s * 4f)
        heart(Offset(x, y), s, cols[i % cols.size].copy(alpha = alpha * (0.5f + 0.5f * ((i % 4) / 3f))))
    }
}

private fun DrawScope.twinkleStars(t: Float, count: Int, seed: Int, areaH: Float) {
    val rnd = java.util.Random(seed.toLong())
    for (i in 0 until count) {
        val x = rnd.nextFloat() * size.width
        val y = rnd.nextFloat() * areaH
        val r = 0.8f + rnd.nextFloat() * 1.8f
        val sp = 0.6f + rnd.nextFloat() * 1.6f
        val ph = rnd.nextFloat() * 6.28f
        val a = 0.25f + 0.65f * ((sf(t * sp + ph) + 1f) / 2f)
        drawCircle(Color.White.copy(alpha = a), r, Offset(x, y))
    }
}

/** Festive/animated scenes added in 1.5.29. Returns true when [id] was drawn. */
private fun DrawScope.drawNewScene(id: String, t: Float): Boolean {
    val w = size.width
    val h = size.height
    when (id) {
        "aurora" -> {
            vgrad(0xFF030812, 0xFF071A2A, 0xFF0A2630)
            twinkleStars(t, 70, 71, h * 0.6f)
            val cols = listOf(Color(0xFF3DFFB0), Color(0xFF5C8CFF), Color(0xFFB45CFF))
            for (k in 0..2) {
                val base = h * (0.16f + k * 0.1f)
                val ribbon = Path()
                val steps = 28
                for (i in 0..steps) {
                    val x = w * i / steps
                    val y = base + sf(i * 0.45f + t * (0.35f + k * 0.12f) + k * 1.7f) * h * 0.06f
                    if (i == 0) ribbon.moveTo(x, y) else ribbon.lineTo(x, y)
                }
                for (i in steps downTo 0) {
                    val x = w * i / steps
                    ribbon.lineTo(x, base + h * 0.24f + sf(i * 0.3f + t * 0.4f + k) * h * 0.05f)
                }
                ribbon.close()
                drawPath(ribbon, Brush.verticalGradient(
                    colors = listOf(cols[k].copy(alpha = 0f), cols[k].copy(alpha = 0.5f), cols[k].copy(alpha = 0f)),
                    startY = base - h * 0.08f, endY = base + h * 0.32f))
            }
            pines(Color(0xFF020A0A), h * 0.86f, 8, h * 0.18f, h * 0.3f, 22)
            pines(Color(0xFF010505), h * 1.02f, 5, h * 0.3f, h * 0.46f, 23)
        }
        "galaxy" -> {
            vgrad(0xFF05030F, 0xFF140A2E, 0xFF0A1030)
            val n1 = Offset(w * 0.35f + sf(t * 0.1f) * 20f, h * 0.4f)
            drawCircle(Brush.radialGradient(listOf(Color(0x668E5CFF), Color.Transparent), n1, w * 0.7f), w * 0.7f, n1)
            val n2 = Offset(w * 0.8f, h * 0.72f + cf(t * 0.1f) * 20f)
            drawCircle(Brush.radialGradient(listOf(Color(0x55FF5CAA), Color.Transparent), n2, w * 0.6f), w * 0.6f, n2)
            twinkleStars(t, 130, 81, h)
            for (i in 0..1) {
                val ph = (t * 0.22f + i * 0.5f) % 1f
                if (ph < 0.3f) {
                    val k = ph / 0.3f
                    val start = Offset(w * (0.95f - 0.4f * i) - k * w * 0.5f, h * (0.08f + 0.2f * i) + k * h * 0.22f)
                    drawLine(Color.White.copy(alpha = 1f - k), start, start + Offset(w * 0.12f, -h * 0.045f), strokeWidth = 3f)
                }
            }
        }
        "ocean" -> {
            drawRect(Brush.verticalGradient(0f to Color(0xFF0B2A4A), 0.48f to Color(0xFF2C86B5), 0.5f to Color(0xFF1A6A9A), 1f to Color(0xFF031B2E)))
            val sun = Offset(w * 0.72f, h * 0.28f)
            drawCircle(Brush.radialGradient(listOf(Color(0x88FFE9B0), Color.Transparent), sun, w * 0.35f), w * 0.35f, sun)
            drawCircle(Color(0xFFFFF1C8), w * 0.07f, sun)
            for (k in 0..3) {
                val y0 = h * (0.52f + k * 0.12f)
                val amp = h * (0.012f + 0.006f * k)
                val wave = Path()
                wave.moveTo(0f, h)
                for (i in 0..30) {
                    val x = w * i / 30
                    wave.lineTo(x, y0 + sf(i * 0.55f + t * (0.6f + 0.2f * k) + k * 2f) * amp)
                }
                wave.lineTo(w, h)
                wave.close()
                drawPath(wave, Color(0xFF0B4F78).copy(alpha = 0.35f + 0.12f * k))
            }
        }
        "starrain" -> {
            vgrad(0xFF020510, 0xFF081236, 0xFF0B1E4A)
            twinkleStars(t, 90, 91, h)
            val rnd = java.util.Random(92)
            for (i in 0 until 16) {
                val x0 = rnd.nextFloat() * w * 1.4f
                val sp = 0.12f + rnd.nextFloat() * 0.18f
                val len = h * (0.06f + rnd.nextFloat() * 0.08f)
                val y = ((rnd.nextFloat() + t * sp) % 1f) * (h + len * 2f) - len
                val x = x0 - y * 0.35f
                drawLine(Color(0xFFBFD8FF).copy(alpha = 0.55f), Offset(x + len * 0.35f, y - len), Offset(x, y), strokeWidth = 2.5f)
                drawCircle(Color.White.copy(alpha = 0.9f), 3f, Offset(x, y))
            }
        }
        "neon" -> {
            vgrad(0xFF12062A, 0xFF3A0F5A, 0xFFB0206A)
            val horizon = h * 0.62f
            twinkleStars(t, 40, 101, horizon * 0.6f)
            val c = Offset(w / 2f, horizon)
            drawCircle(Brush.verticalGradient(listOf(Color(0xFFFFE15A), Color(0xFFFF3D8A)), startY = horizon - w * 0.28f, endY = horizon), w * 0.28f, c)
            for (i in 0..5) {
                val y = horizon - w * 0.28f * (0.12f + i * 0.14f)
                drawRect(Color(0xFF3A0F5A), Offset(0f, y), Size(w, 3f + i * 3f))
            }
            drawRect(Color(0xFF0A0418), Offset(0f, horizon), Size(w, h - horizon))
            val line = Color(0xFFFF3DDC)
            for (i in 0..9) {
                val f = ((i + t * 0.6f) % 10f) / 10f
                val y = horizon + f * f * (h - horizon)
                drawLine(line.copy(alpha = 0.25f + 0.5f * f), Offset(0f, y), Offset(w, y), strokeWidth = 2f)
            }
            for (i in -8..8) drawLine(line.copy(alpha = 0.5f), Offset(w / 2f + i * w * 0.02f, horizon), Offset(w / 2f + i * w * 0.35f, h), strokeWidth = 2f)
            drawLine(Color(0xFF3DF2FF), Offset(0f, horizon), Offset(w, horizon), strokeWidth = 3f)
        }
        "summer" -> {
            vgrad(0xFF3FA7F0, 0xFF8FD0FF, 0xFFD8F1FF)
            val sun = Offset(w * 0.8f, h * 0.14f)
            for (r in 0 until 12) rotate(t * 8f + r * 30f, sun) {
                drawLine(Color(0x66FFF3A0), sun + Offset(0f, -w * 0.12f), sun + Offset(0f, -w * 0.21f), strokeWidth = 6f)
            }
            drawCircle(Brush.radialGradient(listOf(Color(0x88FFF3A0), Color.Transparent), sun, w * 0.3f), w * 0.3f, sun)
            drawCircle(Color(0xFFFFE97A), w * 0.09f, sun)
            for (i in 0..3) {
                val cx = ((0.2f * i + t * (0.006f + 0.003f * i)) % 1.3f - 0.15f) * w
                val cy = h * (0.12f + 0.09f * i)
                val r = w * (0.05f + 0.01f * (i % 2))
                drawCircle(Color.White.copy(alpha = 0.88f), r, Offset(cx, cy))
                drawCircle(Color.White.copy(alpha = 0.88f), r * 0.8f, Offset(cx + r, cy + r * 0.2f))
                drawCircle(Color.White.copy(alpha = 0.88f), r * 0.8f, Offset(cx - r, cy + r * 0.2f))
            }
            drawOval(Color(0xFF58B85A), Offset(-w * 0.3f, h * 0.76f), Size(w * 1.2f, h * 0.5f))
            drawOval(Color(0xFF3E9A48), Offset(w * 0.15f, h * 0.84f), Size(w * 1.3f, h * 0.5f))
            val rnd = java.util.Random(111)
            val fc = listOf(Color(0xFFFF6B8A), Color(0xFFFFE066), Color(0xFFFFFFFF), Color(0xFFB794F6))
            for (i in 0 until 26) drawCircle(fc[i % fc.size], 4f + rnd.nextFloat() * 3f, Offset(rnd.nextFloat() * w, h * (0.84f + rnd.nextFloat() * 0.15f)))
        }
        "spring" -> {
            vgrad(0xFF8FD3FF, 0xFFD6F0C8, 0xFF9AD27A)
            drawOval(Color(0xFF6DBB5A), Offset(-w * 0.2f, h * 0.74f), Size(w * 1.1f, h * 0.5f))
            drawOval(Color(0xFF4FA24A), Offset(w * 0.2f, h * 0.82f), Size(w * 1.2f, h * 0.5f))
            val rnd = java.util.Random(121)
            val fc = listOf(Color(0xFFFFFFFF), Color(0xFFFFD84D), Color(0xFFFF8FB8), Color(0xFFB794F6))
            for (i in 0 until 30) drawCircle(fc[i % fc.size], 3.5f + rnd.nextFloat() * 3f, Offset(rnd.nextFloat() * w, h * (0.8f + rnd.nextFloat() * 0.19f)))
            for (i in 0..3) {
                val bx = w * (0.2f + 0.2f * i) + sf(t * 0.6f + i) * w * 0.1f
                val by = h * (0.3f + 0.1f * i) + sf(t * 0.9f + i * 2f) * h * 0.04f
                val flap = 0.35f + 0.65f * af(sf(t * 9f + i))
                val col = if (i % 2 == 0) Color(0xFFFF8A3D) else Color(0xFF6C8CFF)
                drawOval(col, Offset(bx - 16f * flap, by - 10f), Size(16f * flap, 18f))
                drawOval(col, Offset(bx, by - 10f), Size(16f * flap, 18f))
                drawRect(Color(0xFF332211), Offset(bx - 1.5f, by - 8f), Size(3f, 16f))
            }
            fallingPetals(t, 14, 122, listOf(Color(0xFFFFFFFF), Color(0xFFFFC2D9)), 8f, 14f, 0.04f, 0.08f, 0.8f)
        }
        "sakura" -> {
            vgrad(0xFF2A1630, 0xFF5A2A4A, 0xFFB5607A)
            drawLine(Color(0xFF2A1410), Offset(-10f, h * 0.1f), Offset(w * 0.8f, h * 0.2f), strokeWidth = 12f)
            drawLine(Color(0xFF2A1410), Offset(w * 0.4f, h * 0.15f), Offset(w * 0.55f, h * 0.32f), strokeWidth = 7f)
            val rnd = java.util.Random(131)
            for (i in 0 until 26) {
                val f = rnd.nextFloat()
                val bx = w * (0.8f * f)
                val by = h * (0.1f + 0.1f * f) + (rnd.nextFloat() - 0.3f) * h * 0.1f
                drawCircle(Color(0xFFFFB7D0).copy(alpha = 0.9f), 9f + rnd.nextFloat() * 8f, Offset(bx, by))
                drawCircle(Color(0xFFFFE0EC), 4f, Offset(bx, by))
            }
            fallingPetals(t, 32, 132, listOf(Color(0xFFFFB7D0), Color(0xFFFFD6E4), Color(0xFFFF8FB8)), 9f, 17f, 0.04f, 0.09f, 0.9f)
        }
        "newyear" -> {
            vgrad(0xFF050A1E, 0xFF0E1840, 0xFF1A1030)
            twinkleStars(t, 60, 141, h * 0.6f)
            pines(Color(0xFF0A1226), h * 0.9f, 8, h * 0.2f, h * 0.34f, 142)
            pines(Color(0xFF050A16), h * 1.02f, 5, h * 0.3f, h * 0.46f, 143)
            val cols = listOf(Color(0xFFFFD36E), Color(0xFFFF5C8A), Color(0xFF5CD6FF), Color(0xFFB45CFF), Color(0xFF7CFF8A))
            for (i in 0 until 5) {
                val cyc = (t * 0.3f + i * 0.2f) % 1f
                val cx = w * (0.15f + 0.7f * ((i * 37) % 10) / 10f)
                val cy = h * (0.15f + 0.3f * ((i * 53) % 10) / 10f)
                if (cyc < 0.75f) {
                    val k = cyc / 0.75f
                    val rad = w * 0.22f * k
                    for (j in 0 until 16) {
                        val ang = j * (6.2832f / 16f)
                        drawCircle(cols[i % cols.size].copy(alpha = 1f - k), 1f + 3.5f * (1f - k), Offset(cx + cf(ang) * rad, cy + sf(ang) * rad + k * k * h * 0.05f))
                    }
                }
            }
            fallingDots(t, 40, 144, Color.White.copy(alpha = 0.8f), 1.2f, 2.6f, 0.04f, 0.09f, 12f)
        }
        "xmas" -> {
            vgrad(0xFF06121C, 0xFF0B2A2A, 0xFF0A1F18)
            twinkleStars(t, 40, 151, h * 0.4f)
            drawOval(Color(0xFFEAF4FF), Offset(-w * 0.2f, h * 0.9f), Size(w * 1.4f, h * 0.3f))
            val cx = w * 0.5f
            drawRect(Color(0xFF5A3A1E), Offset(cx - w * 0.03f, h * 0.8f), Size(w * 0.06f, h * 0.08f))
            val lights = listOf(Color(0xFFFF4D4D), Color(0xFFFFD36E), Color(0xFF5CD6FF), Color(0xFFB45CFF))
            for (k in 0..3) {
                val top = h * 0.3f + k * h * 0.12f
                val bottom = top + h * 0.2f
                val half = w * (0.14f + 0.1f * k)
                val tier = Path()
                tier.moveTo(cx, top); tier.lineTo(cx + half, bottom); tier.lineTo(cx - half, bottom); tier.close()
                drawPath(tier, Color(0xFF1E7A3C))
                for (j in 0..4) {
                    val lx = cx + (j - 2) * half * 0.42f
                    val ly = bottom - h * 0.012f - af((j - 2).toFloat()) * h * 0.004f
                    val a = 0.35f + 0.65f * ((sf(t * 2.2f + j * 1.3f + k * 2f) + 1f) / 2f)
                    val lc = lights[(j + k) % lights.size]
                    drawCircle(lc.copy(alpha = a * 0.35f), 12f, Offset(lx, ly))
                    drawCircle(lc.copy(alpha = a), 4.5f, Offset(lx, ly))
                }
            }
            val pulse = 0.8f + 0.2f * sf(t * 3f)
            val st = Offset(cx, h * 0.285f)
            drawCircle(Brush.radialGradient(listOf(Color(0x99FFE97A), Color.Transparent), st, w * 0.12f * pulse), w * 0.12f * pulse, st)
            drawCircle(Color(0xFFFFE97A), w * 0.025f, st)
            drawRect(Color(0xFFD63B3B), Offset(w * 0.12f, h * 0.9f), Size(w * 0.14f, h * 0.06f))
            drawRect(Color(0xFF3B8AD6), Offset(w * 0.72f, h * 0.91f), Size(w * 0.16f, h * 0.05f))
            drawRect(Color(0xFFFFD36E), Offset(w * 0.17f, h * 0.9f), Size(w * 0.02f, h * 0.06f))
            drawRect(Color(0xFFFFD36E), Offset(w * 0.79f, h * 0.91f), Size(w * 0.02f, h * 0.05f))
            fallingDots(t, 60, 152, Color.White.copy(alpha = 0.85f), 1.4f, 3.2f, 0.05f, 0.11f, 14f)
        }
        "halloween" -> {
            drawRect(Brush.verticalGradient(0f to Color(0xFF1A0B2E), 0.6f to Color(0xFF4A1A4A), 1f to Color(0xFF140A1E)))
            val moon = Offset(w * 0.7f, h * 0.2f)
            drawCircle(Brush.radialGradient(listOf(Color(0x88FFB347), Color.Transparent), moon, w * 0.35f), w * 0.35f, moon)
            drawCircle(Color(0xFFFFC266), w * 0.13f, moon)
            pines(Color(0xFF0D0614), h * 0.84f, 7, h * 0.2f, h * 0.34f, 161)
            val px = listOf(0.2f, 0.55f, 0.85f)
            val pr = listOf(0.1f, 0.13f, 0.09f)
            for (i in 0..2) {
                val c = Offset(w * px[i], h * 0.91f)
                val r = w * pr[i]
                val glow = 0.7f + 0.3f * sf(t * 3f + i)
                drawOval(Color(0xFFE8731A), Offset(c.x - r * 1.15f, c.y - r), Size(r * 2.3f, r * 2f))
                drawOval(Color(0xFFC75A0E), Offset(c.x - r * 0.55f, c.y - r), Size(r * 1.1f, r * 2f))
                val eyeL = Path(); eyeL.moveTo(c.x - r * 0.6f, c.y - r * 0.1f); eyeL.lineTo(c.x - r * 0.2f, c.y - r * 0.1f); eyeL.lineTo(c.x - r * 0.4f, c.y - r * 0.45f); eyeL.close()
                val eyeR = Path(); eyeR.moveTo(c.x + r * 0.6f, c.y - r * 0.1f); eyeR.lineTo(c.x + r * 0.2f, c.y - r * 0.1f); eyeR.lineTo(c.x + r * 0.4f, c.y - r * 0.45f); eyeR.close()
                drawPath(eyeL, Color(0xFFFFE066).copy(alpha = glow)); drawPath(eyeR, Color(0xFFFFE066).copy(alpha = glow))
                drawRoundRect(Color(0xFFFFE066).copy(alpha = glow), Offset(c.x - r * 0.55f, c.y + r * 0.25f), Size(r * 1.1f, r * 0.3f), CornerRadius(8f, 8f))
            }
            for (i in 0..4) {
                val f = (t * 0.05f * (0.7f + i * 0.15f) + i * 0.2f) % 1f
                val x = f * (w + 80f) - 40f
                val y = h * (0.1f + 0.07f * i) + sf(t * 2f + i) * h * 0.02f
                val wing = 12f + 8f * sf(t * 10f + i)
                val bat = Path()
                bat.moveTo(x, y); bat.lineTo(x - wing * 1.8f, y - wing * 0.9f); bat.lineTo(x - wing * 0.7f, y + 3f)
                bat.lineTo(x, y + 9f)
                bat.lineTo(x + wing * 0.7f, y + 3f); bat.lineTo(x + wing * 1.8f, y - wing * 0.9f); bat.lineTo(x, y)
                bat.close()
                drawPath(bat, Color(0xFF0A0510))
            }
        }
        "valentine" -> {
            vgrad(0xFF2A0A1E, 0xFF6A1A3A, 0xFFB5305A)
            val pulse = 1f + 0.05f * sf(t * 2.5f)
            heart(Offset(w * 0.5f, h * 0.45f), w * 0.22f * pulse, Color(0x33FF4F7B))
            risingHearts(t, 24, 171, 0.85f)
        }
        "women8" -> {
            vgrad(0xFF3A1A48, 0xFFB5527A, 0xFFFFB0B8)
            val tc = listOf(Color(0xFFFF5C8A), Color(0xFFE0245E), Color(0xFFFFD84D), Color(0xFFFFFFFF), Color(0xFFFF8FB8))
            for (i in 0 until 7) {
                val x = w * (i + 0.5f) / 7f
                val top = h * (0.7f + 0.05f * (i % 3)) + sf(t * 0.8f + i) * 3f
                drawLine(Color(0xFF2E8B4A), Offset(x, h), Offset(x, top), strokeWidth = 6f)
                drawOval(Color(0xFF3FA85E), Offset(x - 20f, top + (h - top) * 0.45f), Size(20f, 46f))
                drawOval(tc[i % tc.size], Offset(x - 15f, top - 28f), Size(30f, 38f))
                val tip = Path(); tip.moveTo(x - 15f, top - 14f); tip.lineTo(x - 8f, top - 36f); tip.lineTo(x, top - 18f); tip.lineTo(x + 8f, top - 36f); tip.lineTo(x + 15f, top - 14f); tip.close()
                drawPath(tip, tc[i % tc.size])
            }
            fallingPetals(t, 26, 181, listOf(Color(0xFFFFFFFF), Color(0xFFFFC2D9), Color(0xFFFFE066)), 9f, 16f, 0.04f, 0.09f, 0.85f)
        }
        else -> return false
    }
    return true
}

private fun DrawScope.drawFx(kind: String, t: Float) {
    val w = size.width
    val h = size.height
    when (kind) {
        "snow" -> fallingDots(t, 36, 201, Color.White.copy(alpha = 0.6f), 1.2f, 3f, 0.04f, 0.1f, 12f)
        "leaves" -> fallingPetals(t, 14, 202, listOf(Color(0xFFD9822B), Color(0xFFB5451B), Color(0xFFE0A526)), 14f, 24f, 0.04f, 0.08f, 0.6f)
        "petals" -> fallingPetals(t, 20, 203, listOf(Color(0xFFFFB7D0), Color(0xFFFFD6E4), Color(0xFFFF8FB8)), 8f, 14f, 0.04f, 0.08f, 0.6f)
        "hearts" -> risingHearts(t, 14, 204, 0.5f)
        "embers" -> {
            val rnd = java.util.Random(205)
            for (i in 0 until 24) {
                val sp = 0.04f + rnd.nextFloat() * 0.07f
                val x = rnd.nextFloat() * w + sf(t + i) * 14f
                val y = h - ((rnd.nextFloat() + t * sp) % 1f) * h
                val c = Offset(x, y)
                drawCircle(Brush.radialGradient(listOf(Color(0x88FF8A2B), Color.Transparent), c, 10f), 10f, c)
                drawCircle(Color(0xFFFFC266).copy(alpha = 0.8f), 1.8f, c)
            }
        }
        "glow" -> {
            val c1 = Offset(w * (0.3f + 0.1f * sf(t * 0.25f)), h * 0.18f)
            val c2 = Offset(w * (0.7f + 0.1f * cf(t * 0.2f)), h * 0.3f)
            drawCircle(Brush.radialGradient(listOf(Color(0x3326FFB0), Color.Transparent), c1, w * 0.6f), w * 0.6f, c1)
            drawCircle(Brush.radialGradient(listOf(Color(0x335C8CFF), Color.Transparent), c2, w * 0.55f), w * 0.55f, c2)
        }
        "bokeh" -> {
            val rnd = java.util.Random(206)
            val cols = listOf(Color(0xFFFF3DDC), Color(0xFF3DF2FF), Color(0xFFB45CFF))
            for (i in 0 until 12) {
                val r = 14f + rnd.nextFloat() * 30f
                val x = rnd.nextFloat() * w + sf(t * 0.3f + i) * 20f
                val y = rnd.nextFloat() * h + cf(t * 0.25f + i) * 20f
                drawCircle(cols[i % cols.size].copy(alpha = 0.06f + 0.06f * ((sf(t + i) + 1f) / 2f)), r, Offset(x, y))
            }
        }
        "bubbles" -> {
            val rnd = java.util.Random(207)
            for (i in 0 until 20) {
                val r = 3f + rnd.nextFloat() * 8f
                val sp = 0.03f + rnd.nextFloat() * 0.06f
                val x = rnd.nextFloat() * w + sf(t * 0.7f + i) * 10f
                val y = h + r - ((rnd.nextFloat() + t * sp) % 1f) * (h + r * 2f)
                drawCircle(Color(0xFFBFF3FF).copy(alpha = 0.22f), r, Offset(x, y))
            }
        }
    }
}

val ThemeFx: Map<String, String> = mapOf(
    "Зима" to "snow", "Ёлка" to "snow", "Осень" to "leaves", "Хэллоуин" to "embers", "Закат" to "embers",
    "Сакура" to "petals", "Любовь" to "hearts", "Аврора" to "glow", "Неон" to "bokeh", "Океан" to "bubbles"
)

/** Soft animated particles drawn over the whole app for animated themes. Does not intercept touches. */
@Composable
fun ThemeParticles(theme: String) {
    val kind = ThemeFx[theme]
    if (kind != null) {
        var t by remember(kind) { mutableFloatStateOf(0f) }
        LaunchedEffect(kind) {
            val start = withFrameNanos { it }
            while (true) {
                withFrameNanos { now -> t = (now - start) / 1_000_000_000f }
            }
        }
        Canvas(Modifier.fillMaxSize()) { drawFx(kind, t) }
    }
}

private fun DrawScope.drawScene(id: String, t: Float) {
    val w = size.width
    val h = size.height
    when (id) {
        "night" -> {
            vgrad(0xFF050B12, 0xFF0B2218, 0xFF0F2E1F)
            val rnd = java.util.Random(7)
            for (i in 0 until 70) drawCircle(Color.White.copy(alpha = 0.25f + rnd.nextFloat() * 0.5f), 1f + rnd.nextFloat() * 1.6f, Offset(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.55f))
            val moon = Offset(w * 0.76f, h * 0.13f)
            drawCircle(Brush.radialGradient(listOf(Color(0x66FFF3D0), Color.Transparent), moon, w * 0.22f), w * 0.22f, moon)
            drawCircle(Color(0xFFFFF3D0), w * 0.065f, moon)
            pines(Color(0xFF0C1F17), h * 0.80f, 8, h * 0.22f, h * 0.36f, 1)
            pines(Color(0xFF06110C), h * 1.02f, 5, h * 0.32f, h * 0.52f, 2)
        }
        "fog" -> {
            vgrad(0xFF1A2A24, 0xFF2C3F36, 0xFF1B2B24)
            pines(Color(0xFF22362D), h * 0.72f, 9, h * 0.2f, h * 0.32f, 3)
            for (i in 0..5) {
                val y = h * (0.25f + i * 0.13f)
                drawOval(Color(0xFFCFE3D6).copy(alpha = 0.09f), Offset(-w * 0.2f + (i % 2) * w * 0.25f, y), Size(w * 1.1f, h * 0.12f))
            }
            pines(Color(0xFF14211B), h * 1.0f, 6, h * 0.3f, h * 0.5f, 4)
            drawRect(Color(0xFFCFE3D6).copy(alpha = 0.06f))
        }
        "rain" -> {
            vgrad(0xFF0B1A1A, 0xFF123027, 0xFF0B1D17)
            for (i in 0..3) {
                rotate(-30f + i * 22f, Offset(w * (0.1f + i * 0.3f), h)) {
                    drawOval(Color(0xFF1E5A38).copy(alpha = 0.75f), Offset(w * (0.1f + i * 0.3f) - w * 0.1f, h - h * 0.12f), Size(w * 0.2f, h * 0.3f))
                }
            }
            val rnd = java.util.Random(11)
            for (i in 0 until 70) {
                val x = rnd.nextFloat() * w
                val len = 18f + rnd.nextFloat() * 26f
                val speed = 0.5f + rnd.nextFloat() * 0.7f
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + len) - len
                drawLine(Color(0xFFBFE8D8).copy(alpha = 0.32f), Offset(x, y), Offset(x - len * 0.18f, y + len), strokeWidth = 2f)
            }
        }
        "sunset" -> {
            drawRect(Brush.verticalGradient(0f to Color(0xFF2B1B3D), 0.35f to Color(0xFFB5476B), 0.62f to Color(0xFFFF9E5E), 0.8f to Color(0xFF3A2A2E), 1f to Color(0xFF140E17)))
            val sun = Offset(w * 0.5f, h * 0.6f)
            drawCircle(Brush.radialGradient(listOf(Color(0x88FFD08A), Color.Transparent), sun, w * 0.5f), w * 0.5f, sun)
            drawCircle(Color(0xFFFFD08A), w * 0.14f, sun)
            pines(Color(0xFF241420), h * 0.86f, 9, h * 0.18f, h * 0.3f, 5)
            pines(Color(0xFF140E17), h * 1.02f, 5, h * 0.3f, h * 0.48f, 6)
        }
        "snow" -> {
            vgrad(0xFF0E1A2B, 0xFF1E3350, 0xFF2A4260)
            pines(Color(0xFF14243A), h * 0.82f, 8, h * 0.22f, h * 0.36f, 8)
            pines(Color(0xFF0B1523), h * 1.02f, 5, h * 0.32f, h * 0.5f, 9)
            val rnd = java.util.Random(21)
            for (i in 0 until 80) {
                val r = 1.4f + rnd.nextFloat() * 2.6f
                val speed = 0.05f + rnd.nextFloat() * 0.09f
                val x = (rnd.nextFloat() * w + sin((t * 0.8f + i).toDouble()).toFloat() * 14f)
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + 10f) - 5f
                drawCircle(Color.White.copy(alpha = 0.55f + rnd.nextFloat() * 0.4f), r, Offset(x, y))
            }
        }
        "fireflies" -> {
            vgrad(0xFF04100A, 0xFF0A2214, 0xFF0F2C19)
            pines(Color(0xFF07170E), h * 0.85f, 8, h * 0.2f, h * 0.34f, 12)
            pines(Color(0xFF030B06), h * 1.02f, 5, h * 0.3f, h * 0.5f, 13)
            val rnd = java.util.Random(31)
            for (i in 0 until 30) {
                val bx = rnd.nextFloat() * w
                val by = h * (0.25f + rnd.nextFloat() * 0.65f)
                val sp = 0.25f + rnd.nextFloat() * 0.5f
                val ph = rnd.nextFloat() * 6.28f
                val x = bx + sin((t * sp + ph).toDouble()).toFloat() * w * 0.05f
                val y = by + sin((t * sp * 1.3f + ph * 2f).toDouble()).toFloat() * h * 0.03f
                val glow = (0.5f + 0.5f * sin((t * (0.8f + sp) + ph).toDouble()).toFloat()).coerceIn(0f, 1f)
                val c = Offset(x, y)
                drawCircle(Brush.radialGradient(listOf(Color(0xFFD7FF6A).copy(alpha = 0.55f * glow), Color.Transparent), c, 22f), 22f, c)
                drawCircle(Color(0xFFF4FFB0).copy(alpha = 0.4f + 0.6f * glow), 2.6f, c)
            }
        }
        "crystal" -> {
            vgrad(0xFF120A24, 0xFF1B1038, 0xFF0A1428)
            val glow = Offset(w * 0.5f, h * 0.85f)
            drawCircle(Brush.radialGradient(listOf(Color(0x552EC4B6), Color.Transparent), glow, w * 0.8f), w * 0.8f, glow)
            val rnd = java.util.Random(41)
            val cols = listOf(Color(0xFF2EC4B6), Color(0xFFFF7EB6), Color(0xFF8E7CFF))
            for (i in 0 until 11) {
                val x = w * (i + 0.5f) / 11f + (rnd.nextFloat() - 0.5f) * w * 0.05f
                val ch = h * (0.1f + rnd.nextFloat() * 0.26f)
                val cw = w * (0.035f + rnd.nextFloat() * 0.04f)
                val base = h * 1.0f
                val c = cols[i % cols.size]
                val p = Path()
                p.moveTo(x, base - ch)
                p.lineTo(x + cw, base - ch * 0.72f)
                p.lineTo(x + cw * 0.8f, base)
                p.lineTo(x - cw * 0.8f, base)
                p.lineTo(x - cw, base - ch * 0.72f)
                p.close()
                drawPath(p, c.copy(alpha = 0.5f))
                drawLine(Color.White.copy(alpha = 0.25f), Offset(x, base - ch), Offset(x - cw * 0.3f, base), strokeWidth = 2f)
            }
            val st = java.util.Random(43)
            for (i in 0 until 40) drawCircle(Color.White.copy(alpha = 0.2f + st.nextFloat() * 0.4f), 1f + st.nextFloat() * 1.4f, Offset(st.nextFloat() * w, st.nextFloat() * h * 0.7f))
        }
        "sticks" -> {
            drawRect(Color(0xFF0E1A12))
            val rnd = java.util.Random(51)
            for (i in 0 until 46) {
                val cx = rnd.nextFloat() * w
                val cy = rnd.nextFloat() * h
                val len = w * (0.18f + rnd.nextFloat() * 0.22f)
                val th = 10f + rnd.nextFloat() * 8f
                val deg = rnd.nextFloat() * 180f
                rotate(deg, Offset(cx, cy)) {
                    drawRoundRect(Color(0xFF3B2A1A).copy(alpha = 0.7f), Offset(cx - len / 2, cy - th / 2), Size(len, th), CornerRadius(th / 2, th / 2))
                    drawRoundRect(Color(0xFF6B4A2A).copy(alpha = 0.45f), Offset(cx - len / 2 + th, cy - th / 2 + 2f), Size(len - th * 2, 2.5f), CornerRadius(2f, 2f))
                }
                if (i % 3 == 0) drawCircle(Color(0xFF2E7A45).copy(alpha = 0.35f), 7f + rnd.nextFloat() * 6f, Offset(cx + len * 0.2f, cy))
            }
            drawRect(Brush.verticalGradient(listOf(Color(0xAA0E1A12), Color.Transparent, Color(0xAA0E1A12))))
        }
        "leaves" -> {
            vgrad(0xFF2A1A0E, 0xFF4A2A12, 0xFF1C130B)
            val cols = listOf(Color(0xFFD9822B), Color(0xFFB5451B), Color(0xFFE0A526), Color(0xFF8C5A1E))
            val rnd = java.util.Random(61)
            for (i in 0 until 26) {
                val sz = 18f + rnd.nextFloat() * 22f
                val speed = 0.04f + rnd.nextFloat() * 0.06f
                val x = rnd.nextFloat() * w + sin((t * 0.7f + i).toDouble()).toFloat() * 30f
                val y = ((rnd.nextFloat() + t * speed) % 1f) * (h + sz * 2) - sz
                val deg = t * (20f + rnd.nextFloat() * 50f) + i * 40f
                rotate(deg, Offset(x, y)) {
                    drawOval(cols[i % cols.size].copy(alpha = 0.85f), Offset(x - sz / 2, y - sz / 3), Size(sz, sz * 0.66f))
                    drawLine(Color(0x55000000), Offset(x - sz / 2, y), Offset(x + sz / 2, y), strokeWidth = 1.5f)
                }
            }
        }
        else -> if (!drawNewScene(id, t)) drawRect(Color(0xFF0F1A12))
    }
}

// ---------------------------------------------------------------- stickers

data class StickerDef(val id: String, val emoji: String, val caption: String, val color: Long)

val PalkaStickers = listOf(
    StickerDef("stick", "🪵", "Палка!", 0xFF8A5A2B), StickerDef("pine", "🌲", "Ёлки-палки", 0xFF2E7A45),
    StickerDef("fire", "🔥", "Горячо!", 0xFFD9531E), StickerDef("mushroom", "🍄", "Гриб-молодец", 0xFFB5451B),
    StickerDef("owl", "🦉", "Не сплю", 0xFF6B4A2A), StickerDef("wolf", "🐺", "Ауф", 0xFF4A5560),
    StickerDef("moon", "🌙", "Спокойной ночи", 0xFF3A4A8A), StickerDef("tent", "⛺", "Я в походе", 0xFF2E7A6A),
    StickerDef("bear", "🐻", "Обнимаю", 0xFF8A5A2B), StickerDef("heart", "💚", "Люблю", 0xFF2E9A55),
    StickerDef("ok", "👌", "Ок", 0xFF3D8A5A), StickerDef("lol", "🤣", "Ржу", 0xFFC98B1E),
    StickerDef("wow", "😮", "Ого", 0xFF8E5AB5), StickerDef("sad", "😢", "Грустно", 0xFF3A6A9A),
    StickerDef("angry", "😡", "Злюсь", 0xFFB53A3A), StickerDef("hi", "👋", "Привет", 0xFF3D8A5A)
)

@Composable
fun StickerView(id: String, size: Dp = 128.dp) {
    val def = PalkaStickers.firstOrNull { it.id == id } ?: PalkaStickers[0]
    Column(Modifier.width(size), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(def.emoji, fontSize = (size.value * 0.5f).sp)
        Text(
            def.caption, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(def.color)).padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}

/** One-line text for the chat list, pinned bar, replies and notifications. */
fun previewText(m: ChatMessage): String = when (m.mediaType) {
    "video" -> "🎥 Видео"
    "image" -> if (m.mediaUrl?.contains(".gif", true) == true) "GIF" else "📷 Фото"
    "audio" -> "🎤 Голосовое сообщение"
    "sticker" -> PalkaStickers.firstOrNull { it.id == m.body.removePrefix("sticker:") }?.let { "${it.emoji} Стикер" } ?: "Стикер"
    "poll" -> "📊 " + m.body.lineSequence().firstOrNull().orEmpty()
    "paid" -> "🔒 Платный пост"
    "game" -> "🎮 " + gameTitle(parseGameBody(m.body).first)
    "ggame" -> "🎮 " + ggTitle(parseGroupGameBody(m.body).first)
    "gift" -> "🎁 " + (giftById(parseGiftBody(m.body).first)?.let { it.emoji + " " + it.title } ?: "Подарок")
    else -> m.body
}

// ---------------------------------------------------------------- voice messages

fun voiceDuration(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: java.io.File? = null
    private var startMs = 0L

    val elapsedMs: Long get() = if (rec != null) SystemClock.elapsedRealtime() - startMs else 0L

    fun start(): Boolean {
        return try {
            val f = java.io.File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            val r = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(48000)
            r.setAudioSamplingRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r; file = f; startMs = SystemClock.elapsedRealtime()
            true
        } catch (_: Throwable) {
            cancel()
            false
        }
    }

    /** Finishes the recording. Returns the file and its length, or null if it was too short/failed. */
    fun stop(): Pair<java.io.File, Long>? {
        val r = rec ?: return null
        val f = file
        val ms = SystemClock.elapsedRealtime() - startMs
        rec = null; file = null
        return try {
            r.stop(); r.release()
            if (f != null && ms >= 600) f to ms else { f?.delete(); null }
        } catch (_: Throwable) {
            runCatching { r.release() }
            f?.delete()
            null
        }
    }

    fun cancel() {
        rec?.let { runCatching { it.stop() }; runCatching { it.release() } }
        file?.delete()
        rec = null; file = null
    }
}

object VoicePlaying { var activeUrl by mutableStateOf<String?>(null) }

@Composable
fun VoiceBubble(url: String, label: String, accent: Color, textColor: Color) {
    var playing by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var loading by remember { mutableStateOf(false) }
    var player by remember(url) { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(url) {
        onDispose {
            player?.let { runCatching { it.release() } }
            player = null
            if (VoicePlaying.activeUrl == url) VoicePlaying.activeUrl = null
        }
    }
    // Another voice message started: pause this one.
    LaunchedEffect(VoicePlaying.activeUrl) {
        if (VoicePlaying.activeUrl != url && playing) {
            runCatching { player?.pause() }
            playing = false
        }
    }
    LaunchedEffect(playing) {
        while (playing) {
            player?.let { p -> runCatching { if (p.duration > 0) progress = p.currentPosition.toFloat() / p.duration } }
            delay(150)
        }
    }
    fun toggle() {
        val p = player
        if (p != null && !loading) {
            if (playing) { runCatching { p.pause() }; playing = false }
            else { VoicePlaying.activeUrl = url; runCatching { p.start() }; playing = true }
            return
        }
        if (loading) return
        loading = true
        val np = MediaPlayer()
        try {
            np.setDataSource(url)
            np.setOnPreparedListener { mp -> loading = false; VoicePlaying.activeUrl = url; mp.start(); playing = true }
            np.setOnCompletionListener { mp -> playing = false; progress = 0f; runCatching { mp.seekTo(0) } }
            np.setOnErrorListener { _, _, _ -> loading = false; playing = false; true }
            np.prepareAsync()
            player = np
        } catch (_: Throwable) {
            loading = false
            runCatching { np.release() }
        }
    }
    Row(Modifier.width(210.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(accent).clickable { toggle() }, contentAlignment = Alignment.Center) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF08100B), modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = accent, trackColor = textColor.copy(alpha = 0.2f))
            Text(if (loading) "Загрузка…" else label, color = textColor.copy(alpha = 0.75f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

