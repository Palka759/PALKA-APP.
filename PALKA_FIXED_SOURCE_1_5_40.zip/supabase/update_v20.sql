-- PALKA 1.5.40: групповые игры (2-4 игрока) + сезонные подарки. Запусти целиком в SQL Editor.

-- ===== Групповые игры
create table if not exists public.palka_group_games (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  kind text not null check (kind in ('connect4', 'memory', 'dice21', 'hotcold')),
  host uuid not null references public.profiles(id) on delete cascade,
  players uuid[] not null default '{}',
  max_players int not null default 4 check (max_players between 2 and 4),
  state jsonb not null default '{}'::jsonb,
  turn uuid,
  status text not null default 'lobby',
  winner uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists palka_group_games_conv_idx on public.palka_group_games (conversation_id, created_at desc);
alter table public.palka_group_games enable row level security;
drop policy if exists "members read group games" on public.palka_group_games;
create policy "members read group games" on public.palka_group_games for select to authenticated
using (public.palka_is_member(conversation_id));
grant select on public.palka_group_games to authenticated;

create or replace function public.palka_ggame_create(p_conversation uuid, p_kind text, p_max int)
returns json language plpgsql security definer set search_path = '' as $$
declare v_me uuid := auth.uid(); v_id uuid;
begin
  if v_me is null then raise exception 'not signed in'; end if;
  if not public.palka_is_member(p_conversation) then raise exception 'Нет доступа к чату'; end if;
  if not exists (select 1 from public.conversations c where c.id = p_conversation and c.kind = 'group') then
    raise exception 'Групповые игры доступны только в группах';
  end if;
  if p_kind not in ('connect4', 'memory', 'dice21', 'hotcold') then raise exception 'Неизвестная игра'; end if;
  if p_max < 2 or p_max > 4 then raise exception 'Игроков от 2 до 4'; end if;
  insert into public.palka_group_games (conversation_id, kind, host, players, max_players)
    values (p_conversation, p_kind, v_me, array[v_me], p_max) returning id into v_id;
  insert into public.messages (conversation_id, sender_id, body, media_type)
    values (p_conversation, v_me, 'ggame:' || p_kind || '|' || v_id::text, 'ggame');
  return json_build_object('id', v_id);
end $$;

create or replace function public.palka_ggame_join(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_group_games;
begin
  select * into g from public.palka_group_games where id = p_id for update;
  if g.id is null or not public.palka_is_member(g.conversation_id) then raise exception 'Нет доступа к игре'; end if;
  if g.status <> 'lobby' then raise exception 'Игра уже началась'; end if;
  if auth.uid() = any(g.players) then return; end if;
  if coalesce(array_length(g.players, 1), 0) >= g.max_players then raise exception 'Мест нет'; end if;
  update public.palka_group_games set players = players || auth.uid(), updated_at = now() where id = p_id;
end $$;

create or replace function public.palka_ggame_start(p_id uuid, p_state jsonb)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_group_games;
begin
  select * into g from public.palka_group_games where id = p_id for update;
  if g.id is null or auth.uid() <> g.host then raise exception 'Начать может только создатель'; end if;
  if g.status <> 'lobby' then raise exception 'Игра уже началась'; end if;
  if coalesce(array_length(g.players, 1), 0) < 2 then raise exception 'Нужно минимум 2 игрока'; end if;
  update public.palka_group_games
     set state = coalesce(p_state, '{}'::jsonb), turn = g.players[1], status = 'active', updated_at = now()
   where id = p_id;
end $$;

create or replace function public.palka_ggame_cancel(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_group_games;
begin
  select * into g from public.palka_group_games where id = p_id for update;
  if g.id is null or auth.uid() <> g.host then raise exception 'Отменить может только создатель'; end if;
  update public.palka_group_games set status = 'done', turn = null, updated_at = now() where id = p_id;
end $$;

create or replace function public.palka_ggame_update(p_id uuid, p_state jsonb, p_turn uuid, p_status text, p_winner uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.palka_group_games;
begin
  select * into g from public.palka_group_games where id = p_id for update;
  if g.id is null or not (auth.uid() = any(g.players)) then raise exception 'Нет доступа к игре'; end if;
  if g.status <> 'active' then raise exception 'Игра недоступна'; end if;
  if g.turn is not null and g.turn <> auth.uid() then raise exception 'Сейчас не твой ход'; end if;
  update public.palka_group_games
     set state = g.state || coalesce(p_state, '{}'::jsonb), turn = p_turn,
         status = coalesce(p_status, g.status), winner = p_winner, updated_at = now()
   where id = p_id;
end $$;

revoke all on function public.palka_ggame_create(uuid, text, int) from public;
revoke all on function public.palka_ggame_join(uuid) from public;
revoke all on function public.palka_ggame_start(uuid, jsonb) from public;
revoke all on function public.palka_ggame_cancel(uuid) from public;
revoke all on function public.palka_ggame_update(uuid, jsonb, uuid, text, uuid) from public;
grant execute on function public.palka_ggame_create(uuid, text, int) to authenticated;
grant execute on function public.palka_ggame_join(uuid) to authenticated;
grant execute on function public.palka_ggame_start(uuid, jsonb) to authenticated;
grant execute on function public.palka_ggame_cancel(uuid) to authenticated;
grant execute on function public.palka_ggame_update(uuid, jsonb, uuid, text, uuid) to authenticated;

-- ===== Сезонные подарки (в магазине показываются только в свой сезон, это решает приложение)
insert into public.palka_gift_catalog (id, emoji, title, price, sort, active) values
  ('snowflake', '❄️', 'Снежинка',      60, 20, true),
  ('ornament',  '🔮', 'Ёлочный шар',  120, 21, true),
  ('pumpkin',   '🎃', 'Тыква',         90, 22, true),
  ('valentine', '💌', 'Валентинка',   110, 23, true)
on conflict (id) do update set emoji = excluded.emoji, title = excluded.title, price = excluded.price, sort = excluded.sort, active = true;
