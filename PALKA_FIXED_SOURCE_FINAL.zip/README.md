# PALKA — Android messenger

PALKA is a native Android app written in Kotlin + Jetpack Compose. It uses Supabase Auth (email/password), Postgres with RLS, and Supabase Realtime for direct-message updates.

## Included

- Email + password registration/login (no phone number)
- Username profile and username search
- One-to-one conversations and chat history
- Live message inserts through Supabase Realtime
- Stored reactions: ❤️ 😂 🪵 👍
- Profile avatar URL support
- Online label `🪵 Палка тут` based on `last_seen` heartbeat (30s heartbeat; considered online for 75s)
- SQL schema, RLS policies and Realtime publication setup

## 1. Create Supabase project

1. Create a project at https://supabase.com.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In **Project Settings → API**, copy the Project URL and the publishable key (or legacy anon key). Never put the `service_role` key in the Android app.
4. In **Authentication → Providers → Email**, keep Email enabled. Configure email confirmation as you prefer. If confirmation is enabled, users must confirm their email before logging in.
5. In **Database → Publications / Realtime**, make sure `messages` and `profiles` are enabled in `supabase_realtime` (the SQL attempts to add them automatically).

## 2. Configure Android project

1. Install Android Studio with Android SDK 36 and JDK 17.
2. Open this `PALKA` folder in Android Studio and wait for Gradle sync.
3. A local `secrets.properties` file is already prepared for the PALKA Supabase project used during setup. If it is missing, copy `secrets.properties.example` to `secrets.properties` and fill in the project URL and publishable key. Do not replace Android Studio’s `local.properties` (it contains the Android SDK path).
4. The `SUPABASE_ANON_KEY` setting accepts the Supabase publishable key (`sb_publishable_...`) or a legacy anon key:

```properties
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

5. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).

## 3. Build APK

In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build → Generate Signed Bundle / APK** and create your own signing key. Do not share the signing key or passwords.

## Notes / current scope

- `secrets.properties` contains the project URL and public publishable key for the PALKA project. Publishable keys are intended for client apps, but database safety still depends on correct RLS policies. Never add a secret/service-role key. The file is ignored by Git.
- Avatar images are currently set by an HTTPS image URL in Profile. Direct gallery upload to Supabase Storage is not implemented yet.
- Reactions are saved in the database; this initial UI provides the reaction controls but does not yet show aggregate reaction counts.
- Presence is a lightweight `last_seen` heartbeat, not push-based presence. The online label naturally expires if the app stops updating.
- There are intentionally no group chats or calls.
- RLS protects message and reaction rows by conversation membership. Keep RLS enabled and never add the service-role key to the client.

## Project layout

- `app/` — Android application source
- `supabase/schema.sql` — database schema, trigger, RLS and grants
- `secrets.properties.example` — local Supabase configuration template
