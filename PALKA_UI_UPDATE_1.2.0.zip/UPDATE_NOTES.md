# PALKA 1.2.0 — forest interface refresh

- Updated settings rows to the compact dark forest cards with green icon tiles and chevrons from the supplied reference.
- Refined the PALKA home header.
- Kept existing chat, profile, notes, reactions, message editing, pinning, wallpapers, and navigation behavior. No calls tab or push notifications were added.
- Kept the existing read-receipt logic: one check for sent messages, two green checks when `read_at` is set after the recipient opens the chat.

Build this source with the existing GitHub Actions workflow. The Android project was not compiled in this environment, so run the workflow before installing the APK.
