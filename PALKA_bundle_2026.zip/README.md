# PALKA

Early Android UI scaffold. Supabase authentication and private chats are not connected yet.
