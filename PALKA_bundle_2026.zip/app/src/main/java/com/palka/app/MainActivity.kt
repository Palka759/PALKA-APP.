package com.palka.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PalkaApp() } }
}
@Composable fun PalkaApp() {
 var register by remember { mutableStateOf(false) }
 var email by remember { mutableStateOf("") }
 var password by remember { mutableStateOf("") }
 val night = Color(0xFF101510); val green = Color(0xFF91C788); val cream = Color(0xFFF1E9D8)
 MaterialTheme(colorScheme = darkColorScheme(primary=green, background=night, surface=Color(0xFF1B251C), onSurface=cream, onBackground=cream)) {
  Surface(Modifier.fillMaxSize(), color=night) {
   Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
    Text("🪵", fontSize=58.sp); Text("PALKA", fontSize=38.sp, fontWeight=FontWeight.Black, color=green)
    Text("Твои люди. Твои разговоры.", color=cream.copy(alpha=.7f)); Spacer(Modifier.height(28.dp))
    Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(24.dp)) {
     Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
      Text(if(register) "Создать аккаунт" else "С возвращением", fontSize=22.sp, fontWeight=FontWeight.Bold)
      OutlinedTextField(email,{email=it},label={Text("Электронная почта")},singleLine=true,modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email))
      OutlinedTextField(password,{password=it},label={Text("Пароль")},singleLine=true,modifier=Modifier.fillMaxWidth(),visualTransformation=PasswordVisualTransformation())
      Button(onClick={}, modifier=Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(15.dp)) { Text(if(register) "Зарегистрироваться" else "Войти") }
      TextButton(onClick={register=!register},modifier=Modifier.align(Alignment.CenterHorizontally)) { Text(if(register) "Уже есть аккаунт? Войти" else "Создать аккаунт") }
     }
    }
    Spacer(Modifier.height(18.dp)); Text("Ранняя версия приложения", color=cream.copy(alpha=.45f), fontSize=12.sp)
   }
  }
 }
}
